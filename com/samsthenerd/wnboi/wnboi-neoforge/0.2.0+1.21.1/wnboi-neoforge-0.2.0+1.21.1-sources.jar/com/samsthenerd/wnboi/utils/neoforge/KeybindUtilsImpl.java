package com.samsthenerd.wnboi.utils.neoforge;

import com.samsthenerd.wnboi.utils.KeybindUtils;

import net.minecraft.client.KeyMapping;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.ModLoadingContext;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.common.NeoForge;

public class KeybindUtilsImpl {
    private static IEventBus fallbackBus;

    public static void setFallbackBus(IEventBus bus) {
        fallbackBus = bus;
    }

    public static void registerKeybindPlatform(KeyMapping keyBinding, KeybindUtils.KeybindHandler handler) {
        // key mappings must be registered on the mod bus of whichever mod is currently loading, so
        // that downstream mods calling this from their own constructor still get their event
        IEventBus bus = fallbackBus;
        ModContainer active = ModLoadingContext.get().getActiveContainer();
        if (active != null && active.getEventBus() != null) {
            bus = active.getEventBus();
        }
        bus.addListener(RegisterKeyMappingsEvent.class, event -> event.register(keyBinding));
        NeoForge.EVENT_BUS.addListener(ClientTickEvent.Post.class, event ->
            handler.run(keyBinding, net.minecraft.client.Minecraft.getInstance()));
    }
}
