package com.samsthenerd.wnboi.neoforge;

import com.samsthenerd.wnboi.WNBOI;
import com.samsthenerd.wnboi.items.WNBOIComponents;
import com.samsthenerd.wnboi.utils.KeybindUtils;
import com.samsthenerd.wnboi.utils.neoforge.KeybindUtilsImpl;

import net.minecraft.core.registries.Registries;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.registries.RegisterEvent;

@Mod(WNBOI.MOD_ID)
public class WNBOINeoForge {
    public WNBOINeoForge(IEventBus modBus) {
        modBus.addListener(RegisterEvent.class, event ->
            event.register(Registries.DATA_COMPONENT_TYPE,
                helper -> WNBOIComponents.registerAll(helper::register)));
        if (FMLEnvironment.dist == Dist.CLIENT) {
            KeybindUtilsImpl.setFallbackBus(modBus);
            KeybindUtils.registerKeybinds();
        }
    }
}
