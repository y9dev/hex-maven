package com.samsthenerd.wnboi.items;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;

import com.mojang.serialization.Codec;
import com.samsthenerd.wnboi.WNBOI;

import net.minecraft.core.component.DataComponentType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.resources.ResourceLocation;

/**
 * Data components used by {@link DynamicMultiItem} to store the items and the selected slot
 * without touching custom NBT.
 */
public final class WNBOIComponents {
    private WNBOIComponents() {}

    private static final Map<ResourceLocation, DataComponentType<?>> ALL = new LinkedHashMap<>();

    private static <T> DataComponentType<T> track(String name, DataComponentType<T> type) {
        ALL.put(ResourceLocation.fromNamespaceAndPath(WNBOI.MOD_ID, name), type);
        return type;
    }

    public static final DataComponentType<List<ItemStack>> MULTI_ITEMS = track("multi_items",
        DataComponentType.<List<ItemStack>>builder()
            .persistent(ItemStack.OPTIONAL_CODEC.listOf())
            .networkSynchronized(ItemStack.OPTIONAL_LIST_STREAM_CODEC)
            .build()
    );

    public static final DataComponentType<Integer> SELECTED_SLOT = track("selected_slot",
        DataComponentType.<Integer>builder()
            .persistent(Codec.INT)
            .networkSynchronized(ByteBufCodecs.VAR_INT)
            .build()
    );

    public static final DataComponentType<Integer> ITEM_COUNT = track("item_count",
        DataComponentType.<Integer>builder()
            .persistent(Codec.INT)
            .networkSynchronized(ByteBufCodecs.VAR_INT)
            .build()
    );

    /**
     * Hands every component type to the platform's registration hook. Fabric calls this directly
     * during init; NeoForge calls it from the registry event.
     */
    public static void registerAll(BiConsumer<ResourceLocation, DataComponentType<?>> registrar) {
        ALL.forEach(registrar);
    }
}
