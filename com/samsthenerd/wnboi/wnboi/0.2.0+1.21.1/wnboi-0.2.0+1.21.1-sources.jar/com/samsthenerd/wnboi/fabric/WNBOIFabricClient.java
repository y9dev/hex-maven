package com.samsthenerd.wnboi.fabric;

import com.samsthenerd.wnboi.utils.KeybindUtils;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class WNBOIFabricClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        KeybindUtils.registerKeybinds();
    }
}
