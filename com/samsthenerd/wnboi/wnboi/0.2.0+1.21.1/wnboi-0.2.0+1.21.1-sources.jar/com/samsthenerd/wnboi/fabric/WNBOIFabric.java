package com.samsthenerd.wnboi.fabric;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.samsthenerd.wnboi.items.WNBOIComponents;

import net.fabricmc.api.ModInitializer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

public class WNBOIFabric implements ModInitializer {
	public static final Logger LOGGER = LoggerFactory.getLogger("wnboi");

	@Override
	public void onInitialize() {
		WNBOIComponents.registerAll((id, type) -> Registry.register(BuiltInRegistries.DATA_COMPONENT_TYPE, id, type));
		LOGGER.info("Hello Fabric world!");
	}
}
