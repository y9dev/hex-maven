package com.samsthenerd.wnboi.items;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.tuple.ImmutableTriple;
import org.apache.commons.lang3.tuple.Triple;

import com.samsthenerd.wnboi.interfaces.KeyboundItem;

import net.minecraft.world.item.Item;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.InteractionResult;

// this is currently not the most polished code ever. use with caution
public abstract class DynamicMultiItem extends Item implements KeyboundItem {
    public int numItems;

    // meant so that stuff works like a bundle
    protected boolean actAsBag = false;
    protected int bagStackSize = -1;

    public DynamicMultiItem(Properties settings, int numItems) {
        super(settings);
        this.numItems = numItems;
    }

    // can override if you want more dynamic behavior
    public int getNumItems(ItemStack stack) {
        return this.numItems;
    }

    // baseStack is the multiItem and innerStack is the thing that is getting stacked
    public int getMaxStackSize(ItemStack baseStack, ItemStack innerStack) {
        int maxStackSize = innerStack.getMaxStackSize();
        if (actAsBag && bagStackSize > 0)
            maxStackSize = bagStackSize;
        return maxStackSize;
    }

    @Override
    public ItemStack getDefaultInstance() {
        ItemStack stack = super.getDefaultInstance();
        stack.set(WNBOIComponents.ITEM_COUNT, numItems);
        stack.set(WNBOIComponents.SELECTED_SLOT, 0);
        stack.set(WNBOIComponents.MULTI_ITEMS, emptyList(numItems));
        return stack;
    }

    public static List<ItemStack> emptyList(int size) {
        List<ItemStack> list = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            list.add(ItemStack.EMPTY);
        }
        return list;
    }

    // gets the stored item list, padded out to the right size
    public List<ItemStack> getStacks(ItemStack baseStack) {
        int size = getNumItems(baseStack);
        List<ItemStack> stored = baseStack.get(WNBOIComponents.MULTI_ITEMS);
        if (stored == null) {
            return emptyList(size);
        }
        if (stored.size() == size) {
            return new ArrayList<>(stored);
        }
        List<ItemStack> list = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            list.add(i < stored.size() ? stored.get(i) : ItemStack.EMPTY);
        }
        return list;
    }

    public void setStacks(ItemStack baseStack, List<ItemStack> stacks) {
        baseStack.set(WNBOIComponents.MULTI_ITEMS, List.copyOf(stacks));
    }

    public int getSelectedSlot(ItemStack baseStack) {
        return baseStack.getOrDefault(WNBOIComponents.SELECTED_SLOT, 0);
    }

    public void setSelectedSlot(ItemStack baseStack, int slot) {
        baseStack.set(WNBOIComponents.SELECTED_SLOT, slot);
    }

    // puts the addStack into the slot in the baseStack  - doesn't touch the addStack
    public ItemStack putStack(ItemStack baseStack, ItemStack addStack, int slotIndex) {
        if (!(baseStack.getItem() instanceof DynamicMultiItem) || slotIndex >= numItems || slotIndex < 0)
            return baseStack;
        List<ItemStack> itemList = getStacks(baseStack);
        itemList.set(slotIndex, addStack.copy());
        setStacks(baseStack, itemList);
        return baseStack;
    }

    // used to check if an itemstack can be added with the given slot stack of the basestack
    // returns <if you can put it, final count for slotStack, remaining count for addStack>
    public Triple<Boolean, Integer, Integer> canPutStack(ItemStack baseStack, ItemStack addStack, ItemStack slotStack) {
        int maxStackSize = getMaxStackSize(baseStack, addStack);
        if (slotStack.isEmpty()) {
            return new ImmutableTriple<Boolean, Integer, Integer>(true, addStack.getCount(), 0);
        } else if (ItemStack.isSameItemSameComponents(slotStack, addStack)
            && slotStack.getCount() + addStack.getCount() <= maxStackSize) {
            int amountLeftOver = Math.max(slotStack.getCount() + addStack.getCount() - maxStackSize, 0);
            int slotAmount = Math.min(maxStackSize, slotStack.getCount() + addStack.getCount());
            return new ImmutableTriple<Boolean, Integer, Integer>(true, slotAmount, amountLeftOver);
        }
        return new ImmutableTriple<Boolean, Integer, Integer>(false, slotStack.getCount(), addStack.getCount());
    }

    // puts this stack into the first non empty slot or where it can fit - sets the addStack count to proper leftover amount
    public ItemStack tryPutStack(ItemStack baseStack, ItemStack addStack) {
        if (!(baseStack.getItem() instanceof DynamicMultiItem))
            return baseStack;
        List<ItemStack> itemList = getStacks(baseStack);

        for (int i = 0; i < itemList.size() && !addStack.isEmpty(); i++) {
            ItemStack slotStack = itemList.get(i);
            Triple<Boolean, Integer, Integer> canPutResult = canPutStack(baseStack, addStack, slotStack);
            if (!canPutResult.getLeft())
                continue;
            ItemStack newSlot = addStack.copy();
            newSlot.setCount(canPutResult.getMiddle());
            itemList.set(i, newSlot);
            addStack.setCount(canPutResult.getRight());
            break;
        }
        setStacks(baseStack, itemList);
        return baseStack;
    }

    public static ItemStack getCurrentSlotStack(ItemStack baseStack) {
        if (!(baseStack.getItem() instanceof DynamicMultiItem item)) {
            return ItemStack.EMPTY;
        }
        List<ItemStack> itemList = item.getStacks(baseStack);
        int slot = item.getSelectedSlot(baseStack);
        if (slot < 0 || slot >= itemList.size()) {
            return ItemStack.EMPTY;
        }
        return itemList.get(slot);
    }

    // only overriding useOnBlock for now, since other uses likely require mixins with more fine tuning
    // see #Item for others that you can add

    @Override
    public InteractionResult useOn(UseOnContext context) {
        return context.getItemInHand().getItem().useOn(new MultiItemUsageContext(context));
    }

    // helper class so we can gaslight minecraft about what itemstack we're holding
    public class MultiItemUsageContext extends UseOnContext {
        public MultiItemUsageContext(UseOnContext ctx) {
            super(ctx.getPlayer(), ctx.getHand(), new BlockHitResult(ctx.getClickLocation(), ctx.getClickedFace(), ctx.getClickedPos(), ctx.isInside()));
        }

        @Override
        public ItemStack getItemInHand() {
            if (super.getItemInHand().getItem() instanceof DynamicMultiItem)
                return getCurrentSlotStack(super.getItemInHand());
            return super.getItemInHand();
        }
    }

}
