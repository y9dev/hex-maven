package com.samsthenerd.wnboi.testing;

import com.samsthenerd.wnboi.interfaces.KeyboundItem;
import com.samsthenerd.wnboi.screen.AbstractContextWheelScreen;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.level.Level;

public class TestWheelItem extends Item implements KeyboundItem{

    TestWheelScreen screen = null;
    public TestWheelItem(Properties settings) {
        super(settings);
        screen = new TestWheelScreen();
        screen.keyBinding = this.getKeyBinding();
        screen.requireKeydown = true;
    }

    public AbstractContextWheelScreen getScreen(){
        return screen;
    }


    @Override
    public InteractionResultHolder<ItemStack> use(Level world, Player user, InteractionHand hand) {
        if(world.isClientSide()){
            Minecraft.getInstance().setScreen(getScreen());
        }
        return InteractionResultHolder.sidedSuccess(user.getItemInHand(hand), world.isClientSide());
    }
}
