package com.samsthenerd.wnboi.items;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_9135;
import net.minecraft.class_9331;
import com.mojang.serialization.Codec;
import com.samsthenerd.wnboi.WNBOI;

/**
 * Data components used by {@link DynamicMultiItem} to store the items and the selected slot
 * without touching custom NBT.
 */
public final class WNBOIComponents {
    private WNBOIComponents() {}

    private static final Map<class_2960, class_9331<?>> ALL = new LinkedHashMap<>();

    private static <T> class_9331<T> track(String name, class_9331<T> type) {
        ALL.put(class_2960.method_60655(WNBOI.MOD_ID, name), type);
        return type;
    }

    public static final class_9331<List<class_1799>> MULTI_ITEMS = track("multi_items",
        class_9331.<List<class_1799>>method_57873()
            .method_57881(class_1799.field_49266.listOf())
            .method_57882(class_1799.field_49269)
            .method_57880()
    );

    public static final class_9331<Integer> SELECTED_SLOT = track("selected_slot",
        class_9331.<Integer>method_57873()
            .method_57881(Codec.INT)
            .method_57882(class_9135.field_48550)
            .method_57880()
    );

    public static final class_9331<Integer> ITEM_COUNT = track("item_count",
        class_9331.<Integer>method_57873()
            .method_57881(Codec.INT)
            .method_57882(class_9135.field_48550)
            .method_57880()
    );

    /**
     * Hands every component type to the platform's registration hook. Fabric calls this directly
     * during init; NeoForge calls it from the registry event.
     */
    public static void registerAll(BiConsumer<class_2960, class_9331<?>> registrar) {
        ALL.forEach(registrar);
    }
}
