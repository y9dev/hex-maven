package com.samsthenerd.wnboi.utils;

import org.lwjgl.glfw.GLFW;

import com.samsthenerd.wnboi.interfaces.KeyboundItem;

import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public class KeybindUtils {
    public static final class_304 DEFAULT_KEYBINDING = new class_304("key.wnboi.default_context",
        class_3675.class_307.field_1668, GLFW.GLFW_KEY_V, "key.categories.wnboi");

    public static final void handleKeyboundItems(class_304 keyBinding, class_310 client) {
        if (!keyBinding.method_1434()) return; // don't run if key isn't pressed
        class_1657 player = client.field_1724;
        if (player == null) {
            return;
        }
        class_1799 mainHand = player.method_6047();
        class_1799 offHand = player.method_6079();
        KeyboundItem mainItem = null;
        KeyboundItem offItem = null;

        if (mainHand.method_7909() instanceof KeyboundItem) {
            mainItem = (KeyboundItem) mainHand.method_7909();
        }
        if (offHand.method_7909() instanceof KeyboundItem) {
            offItem = (KeyboundItem) offHand.method_7909();
        }

        if (client.field_1755 != null) {
            // there's some other screen open, probably shouldn't open ours
            return;
        } else {
            // no screen open - check if we should open one
            if (mainItem != null && mainItem.getKeyBinding() == keyBinding) {
                mainItem.openScreen();
                return;
            }
            if (offItem != null && offItem.getKeyBinding() == keyBinding) {
                offItem.openScreen();
                return;
            }
        }
    }

    public static void registerKeybinds() {
        registerKeybind(DEFAULT_KEYBINDING, (keyBinding, client) -> handleKeyboundItems(keyBinding, client));
    }

    public static void registerKeybind(class_304 keyBinding, KeybindHandler handler) {
        registerKeybindPlatform(keyBinding, handler);
    }

    /** Registers the keybinding with the loader and runs the handler at the end of every client tick. */
    @ExpectPlatform
    public static void registerKeybindPlatform(class_304 keyBinding, KeybindHandler handler) {
        throw new AssertionError("ExpectPlatform implementation not found");
    }

    @FunctionalInterface
    public interface KeybindHandler {
        void run(class_304 keyBinding, class_310 client);
    }
}
