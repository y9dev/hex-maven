package com.samsthenerd.wnboi.items;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_3965;
import org.apache.commons.lang3.tuple.ImmutableTriple;
import org.apache.commons.lang3.tuple.Triple;

import com.samsthenerd.wnboi.interfaces.KeyboundItem;

// this is currently not the most polished code ever. use with caution
public abstract class DynamicMultiItem extends class_1792 implements KeyboundItem {
    public int numItems;

    // meant so that stuff works like a bundle
    protected boolean actAsBag = false;
    protected int bagStackSize = -1;

    public DynamicMultiItem(class_1793 settings, int numItems) {
        super(settings);
        this.numItems = numItems;
    }

    // can override if you want more dynamic behavior
    public int getNumItems(class_1799 stack) {
        return this.numItems;
    }

    // baseStack is the multiItem and innerStack is the thing that is getting stacked
    public int getMaxStackSize(class_1799 baseStack, class_1799 innerStack) {
        int maxStackSize = innerStack.method_7914();
        if (actAsBag && bagStackSize > 0)
            maxStackSize = bagStackSize;
        return maxStackSize;
    }

    @Override
    public class_1799 method_7854() {
        class_1799 stack = super.method_7854();
        stack.method_57379(WNBOIComponents.ITEM_COUNT, numItems);
        stack.method_57379(WNBOIComponents.SELECTED_SLOT, 0);
        stack.method_57379(WNBOIComponents.MULTI_ITEMS, emptyList(numItems));
        return stack;
    }

    public static List<class_1799> emptyList(int size) {
        List<class_1799> list = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            list.add(class_1799.field_8037);
        }
        return list;
    }

    // gets the stored item list, padded out to the right size
    public List<class_1799> getStacks(class_1799 baseStack) {
        int size = getNumItems(baseStack);
        List<class_1799> stored = baseStack.method_57824(WNBOIComponents.MULTI_ITEMS);
        if (stored == null) {
            return emptyList(size);
        }
        if (stored.size() == size) {
            return new ArrayList<>(stored);
        }
        List<class_1799> list = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            list.add(i < stored.size() ? stored.get(i) : class_1799.field_8037);
        }
        return list;
    }

    public void setStacks(class_1799 baseStack, List<class_1799> stacks) {
        baseStack.method_57379(WNBOIComponents.MULTI_ITEMS, List.copyOf(stacks));
    }

    public int getSelectedSlot(class_1799 baseStack) {
        return baseStack.method_57825(WNBOIComponents.SELECTED_SLOT, 0);
    }

    public void setSelectedSlot(class_1799 baseStack, int slot) {
        baseStack.method_57379(WNBOIComponents.SELECTED_SLOT, slot);
    }

    // puts the addStack into the slot in the baseStack  - doesn't touch the addStack
    public class_1799 putStack(class_1799 baseStack, class_1799 addStack, int slotIndex) {
        if (!(baseStack.method_7909() instanceof DynamicMultiItem) || slotIndex >= numItems || slotIndex < 0)
            return baseStack;
        List<class_1799> itemList = getStacks(baseStack);
        itemList.set(slotIndex, addStack.method_7972());
        setStacks(baseStack, itemList);
        return baseStack;
    }

    // used to check if an itemstack can be added with the given slot stack of the basestack
    // returns <if you can put it, final count for slotStack, remaining count for addStack>
    public Triple<Boolean, Integer, Integer> canPutStack(class_1799 baseStack, class_1799 addStack, class_1799 slotStack) {
        int maxStackSize = getMaxStackSize(baseStack, addStack);
        if (slotStack.method_7960()) {
            return new ImmutableTriple<Boolean, Integer, Integer>(true, addStack.method_7947(), 0);
        } else if (class_1799.method_31577(slotStack, addStack)
            && slotStack.method_7947() + addStack.method_7947() <= maxStackSize) {
            int amountLeftOver = Math.max(slotStack.method_7947() + addStack.method_7947() - maxStackSize, 0);
            int slotAmount = Math.min(maxStackSize, slotStack.method_7947() + addStack.method_7947());
            return new ImmutableTriple<Boolean, Integer, Integer>(true, slotAmount, amountLeftOver);
        }
        return new ImmutableTriple<Boolean, Integer, Integer>(false, slotStack.method_7947(), addStack.method_7947());
    }

    // puts this stack into the first non empty slot or where it can fit - sets the addStack count to proper leftover amount
    public class_1799 tryPutStack(class_1799 baseStack, class_1799 addStack) {
        if (!(baseStack.method_7909() instanceof DynamicMultiItem))
            return baseStack;
        List<class_1799> itemList = getStacks(baseStack);

        for (int i = 0; i < itemList.size() && !addStack.method_7960(); i++) {
            class_1799 slotStack = itemList.get(i);
            Triple<Boolean, Integer, Integer> canPutResult = canPutStack(baseStack, addStack, slotStack);
            if (!canPutResult.getLeft())
                continue;
            class_1799 newSlot = addStack.method_7972();
            newSlot.method_7939(canPutResult.getMiddle());
            itemList.set(i, newSlot);
            addStack.method_7939(canPutResult.getRight());
            break;
        }
        setStacks(baseStack, itemList);
        return baseStack;
    }

    public static class_1799 getCurrentSlotStack(class_1799 baseStack) {
        if (!(baseStack.method_7909() instanceof DynamicMultiItem item)) {
            return class_1799.field_8037;
        }
        List<class_1799> itemList = item.getStacks(baseStack);
        int slot = item.getSelectedSlot(baseStack);
        if (slot < 0 || slot >= itemList.size()) {
            return class_1799.field_8037;
        }
        return itemList.get(slot);
    }

    // only overriding useOnBlock for now, since other uses likely require mixins with more fine tuning
    // see #Item for others that you can add

    @Override
    public class_1269 method_7884(class_1838 context) {
        return context.method_8041().method_7909().method_7884(new MultiItemUsageContext(context));
    }

    // helper class so we can gaslight minecraft about what itemstack we're holding
    public class MultiItemUsageContext extends class_1838 {
        public MultiItemUsageContext(class_1838 ctx) {
            super(ctx.method_8036(), ctx.method_20287(), new class_3965(ctx.method_17698(), ctx.method_8038(), ctx.method_8037(), ctx.method_17699()));
        }

        @Override
        public class_1799 method_8041() {
            if (super.method_8041().method_7909() instanceof DynamicMultiItem)
                return getCurrentSlotStack(super.method_8041());
            return super.method_8041();
        }
    }

}
