package com.samsthenerd.wnboi.utils;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_287;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5253;
import net.minecraft.class_898;
import com.mojang.blaze3d.systems.RenderSystem;
import com.samsthenerd.wnboi.WNBOI;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/*
 * just some functions for rendering math.
 * mostly point calculations 
 */
public class RenderUtils {

    // returns points that make up the outline of an arc.
    // returns numDivisons+1 points
    // angle starts at 0 and goes counter clockwise to 2pi
    // invert will give you a concave arc that still goes counter clockwise
    public static List<class_243> calcArcPoints(int numDivisions, double radius, double startAngle, double endAngle, boolean invert) {
        List<class_243> points = new ArrayList<class_243>();
        double angle = startAngle;
        double angleStep = (endAngle - startAngle) / numDivisions;
        class_243 posCorrection = new class_243(0, 0, 0); // normally nothing, but if we're inverted we need to correct the position
        if (invert) { // need to start at other side and go clockwise
            angle = endAngle + Math.PI;
            angleStep *= -1;
            posCorrection = new class_243(radius * (Math.cos(startAngle) - Math.cos(endAngle + Math.PI)),
                radius * (Math.sin(startAngle) - Math.sin(endAngle + Math.PI)), 0);
        }
        for (int i = 0; i <= numDivisions; i++) {
            points.add(new class_243(radius * Math.cos(angle), radius * Math.sin(angle), 0).method_1019(posCorrection));
            angle += angleStep;
        }
        return points;
    }

    public static List<class_243> calcArcPoints(int numDivisions, double radius, double startAngle, double endAngle) {
        return calcArcPoints(numDivisions, radius, startAngle, endAngle, false);
    }

    // used for the polygon curve type described below
    public static List<class_243> calcPolyPoints(int numDivisions, double curveRadius, double startAngle, double endAngle, boolean invert) {
        class_243 pointA = new class_243(curveRadius * Math.cos(startAngle), curveRadius * Math.sin(startAngle), 0);
        class_243 pointB = new class_243(curveRadius * Math.cos(endAngle), curveRadius * Math.sin(endAngle), 0);
        class_243 center = pointB.method_1020(pointA).method_1021(0.5).method_1019(pointA);
        class_243 adjA = pointA.method_1020(center);
        double aAngle = Math.atan2(adjA.field_1351, adjA.field_1352);
        double bAngle = aAngle + Math.PI;
        double adjRad = adjA.method_1033();
        // gets points as if they're on a circle centered between our endpoints.
        List<class_243> polyPoints = calcArcPoints(numDivisions, adjRad, aAngle, bAngle, invert);
        // all are relative to center so add it back
        for (int i = 0; i < polyPoints.size(); i++) {
            polyPoints.set(i, polyPoints.get(i).method_1019(center));
        }
        return polyPoints;

    }

    public static class_243 calcNormal(class_243 point) {
        return new class_243(-point.field_1351, point.field_1352, 0);
    }

    public static List<class_243> calcStroke(List<class_243> points, double outerStrokeWidth, double innerStrokeWidth) {
        List<class_243> stroke = new ArrayList<class_243>();
        if (points.size() <= 1) {
            return points; // figure this out when we figure out caps
        }
        // store values as we go so that we don't have to recalculate as much
        class_243 del1 = points.get(1).method_1020(points.get(0));
        class_243 del2 = del1;
        // vars are parts that get multiplied by stroke width
        double AValVar;
        double AValConst;
        double BValVar = Math.sqrt(del2.field_1352 * del2.field_1352 + del2.field_1351 * del2.field_1351);
        double BValConst = del1.field_1351 * points.get(0).field_1352 - del1.field_1352 * points.get(1).field_1351;
        class_243 p1;
        class_243 p2 = points.get(0);
        class_243 p3 = p2;
        boolean isClosed = false;
        for (int i = 0; i < points.size(); i++) {
            del1 = del2;
            AValVar = BValVar;
            AValConst = BValConst;
            p1 = p2;
            p2 = p3;
            if (i == points.size() - 1) { // last point 
                if (points.get(0).equals(p3)) { //closed path, get first point
                    p3 = points.get(1);
                    isClosed = true;
                }
            } else { // not last point
                p3 = points.get(i + 1);
            }
            del2 = p3.method_1020(p2);
            BValVar = Math.sqrt(del2.field_1352 * del2.field_1352 + del2.field_1351 * del2.field_1351);
            BValConst = del2.field_1351 * p2.field_1352 - del2.field_1352 * p2.field_1351;

            double det = del1.field_1352 * del2.field_1351 - del1.field_1351 * del2.field_1352;
            if (det == 0) { // straight line, add halfway points to avoid messing up color somehow
                class_243 norm;
                if (i == 0) {
                    norm = (new class_243(del2.field_1351, -del2.field_1352, 0)).method_1029();
                } else {
                    norm = (new class_243(del1.field_1351, -del1.field_1352, 0)).method_1029();
                }
                stroke.add(p2.method_1019(norm.method_1021(outerStrokeWidth)));
                stroke.add(p2.method_1019(norm.method_1021(-innerStrokeWidth)));
            } else {
                double AValOuter = AValConst + innerStrokeWidth * AValVar;
                double AValInner = AValConst - outerStrokeWidth * AValVar;
                double BValOuter = BValConst + innerStrokeWidth * BValVar;
                double BValInner = BValConst - outerStrokeWidth * BValVar;
                // get raw values, then we'll scale with stroke width to get the actual points
                double outerX = (BValOuter * del1.field_1352 - AValOuter * del2.field_1352) / det;
                double outerY = (BValOuter * del1.field_1351 - AValOuter * del2.field_1351) / det;
                stroke.add(new class_243(outerX, outerY, 0));

                double innerX = (BValInner * del1.field_1352 - AValInner * del2.field_1352) / det;
                double innerY = (BValInner * del1.field_1351 - AValInner * del2.field_1351) / det;
                stroke.add(new class_243(innerX, innerY, 0));

                if (isClosed) { // add first point again
                    stroke.set(0, (new class_243(outerX, outerY, 0)));
                    stroke.set(1, new class_243(innerX, innerY, 0));
                }
            }
        }
        return stroke;
    }

    public static List<class_243> drawStroke(class_287 buffer, List<class_243> points, double outerStrokeWidth, double innerStrokeWidth) {
        List<class_243> stroke = calcStroke(points, outerStrokeWidth, innerStrokeWidth);
        for (int i = 0; i < stroke.size(); i++) {
            buffer.method_22912((float) stroke.get(i).field_1352, (float) stroke.get(i).field_1351, 0).method_1336(128, 128, 128, 255);
        }
        return stroke; // pass it up just in case
    }

    public static void testCalcStroke() {
        List<class_243> points1 = new ArrayList<class_243>();
        points1.add(new class_243(0, 0, 0));
        points1.add(new class_243(0.5, 1, 0));
        points1.add(new class_243(1, 1, 0));
        points1.add(new class_243(1, 0, 0));
        points1.add(new class_243(0, 0, 0));
        List<class_243> stroke1 = calcStroke(points1, 0.1, 0.1);
        WNBOI.logPrint("test 1:");
        for (int s = 0; s < stroke1.size(); s++) {
            WNBOI.logPrint("stroke point: " + stroke1.get(s).field_1352 + ", " + stroke1.get(s).field_1351);
        }
    }

    // renders the item icon with a color tint
    public static void renderItemIcon(class_332 context, class_1799 stack, int x, int y, int argb) {
        context.method_51448().method_22903();
        context.method_51422(class_5253.class_5254.method_27765(argb) / 255f, class_5253.class_5254.method_27766(argb) / 255f,
            class_5253.class_5254.method_27767(argb) / 255f, class_5253.class_5254.method_27762(argb) / 255f);
        context.method_51427(stack, x, y);
        context.method_51422(1, 1, 1, 1);
        context.method_51448().method_22909();
    }

    // copied from InventoryScreen - expanded to be not just LivingEntity
    public static void drawEntity(class_332 context, int x, int y, int size, class_1297 entity) {
        float scale = size / Math.max(1.0f, Math.max(entity.method_17681(), entity.method_17682()));
        drawEntity(context, x, y, scale, new Vector3f(0, 0, 0), new Quaternionf().rotateZ((float) Math.PI), null, entity);
    }

    public static void drawEntity(class_332 context, float x, float y, float size, Vector3f translation,
                                  Quaternionf rotation, Quaternionf rotation2, class_1297 entity) {
        context.method_51448().method_22903();
        context.method_51448().method_22904(x, y, 50.0);
        context.method_51448().method_22905(size, size, -size);
        context.method_51448().method_46416(translation.x, translation.y, translation.z);
        context.method_51448().method_22907(rotation);
        class_308.method_34742();
        class_898 dispatcher = class_310.method_1551().method_1561();
        if (rotation2 != null) {
            dispatcher.method_24196(rotation2.conjugate(new Quaternionf()).rotateY((float) Math.PI));
        }
        dispatcher.method_3948(false);
        RenderSystem.runAsFancy(() -> dispatcher.method_3954(entity, 0.0, 0.0, 0.0, 0.0F, 1.0F,
            context.method_51448(), context.method_51450(), 15728880));
        context.method_51452();
        dispatcher.method_3948(true);
        context.method_51448().method_22909();
        class_308.method_24211();
    }

    public static void renderText(class_332 context, class_2561 text, int x, int y, int color) {
        context.method_51439(class_310.method_1551().field_1772, text, x, y, color, false);
    }

    // different types of built-in curves. can support up to 16 different types.
    // if you want to use your own curve it's probably best to ignore this and just override the getCurve methods directly

    /* pass curve options without having a whole other class for it
        curve types are just 4 bit values that map to default curve types:
            -arc, default, approximates a circle
            -polygon, approximates half of a polygon based on number of divisions, so 1 is flat, 
                2 is a triangle (half of a square), 3 is a trapezoid (half of a hexagon),
                 .., n divisons is half of a 2n sided polygon
        invert options are just booleans that invert the curves
    */
    public static int buildCurveOptions(int outerCurve, int innerCurve, boolean invertOuter, boolean invertInner) {
        int options = 0;
        options += outerCurve;
        options += outerCurve << 4;
        options += (invertOuter ? 1 : 0) << 8;
        options += (invertInner ? 1 : 0) << 9;

        return options;
    }

    public static int getOuterCurve(int options) {
        return options & 0xF;
    }

    public static int getInnerCurve(int options) {
        return (options >>> 4) & 0xF;
    }

    public static boolean getInvertOuter(int options) {
        return (options >>> 8) % 2 == 1;
    }

    public static boolean getInvertInner(int options) {
        return (options >>> 9) % 2 == 1;
    }

    public static int setOuterCurve(int options, int curve) {
        return (options & 0xFFF0) + curve;
    }

    public static int setInnerCurve(int options, int curve) {
        return (options & 0xFF0F) + (curve << 4);
    }

    public static int setInvertOuter(int options, boolean invert) {
        return (options & 0xFEFF) + ((invert ? 1 : 0) << 8);
    }

    public static int setInvertInner(int options, boolean invert) {
        return (options & 0xFDFF) + ((invert ? 1 : 0) << 9);
    }
}
