package com.samsthenerd.wnboi.screen;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.glfw.GLFW;

import com.samsthenerd.wnboi.WNBOI;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

/*
 * Any wheel context screen should be extended from here and customized to fit yours needs.
 * 
 * Defaults to an 8 sectioned wheel with standard minecraft-ish colors.
 * 
 */
@Environment(value = EnvType.CLIENT)
public class AbstractContextWheelScreen extends class_437 {
    protected int numSections;

    // these are passed to the spoke renderers by default.
    protected double centerX;
    protected double centerY;
    protected double outerRadius;
    protected double innerRadius = 0;
    protected double gap = 10;
    protected double angleOffset = Math.PI * 0.5; // measured in radians off of x axis. default puts first section at 12 o'clock and goes clockwise

    protected int selectedSection = -1; // -1 means none selected
    // these determine when the mouse is considered to be in the section
    protected double lowerBoundRadius = 0;
    protected double upperBoundRadius = 0;

    protected double currentTime = 0; // updated on each render call
    protected double lastStateChange = 0; // set when selected or deselected
    protected int tooltipTickDelay = 30; // how many ticks to wait before showing the tooltip

    // use these to have the screen close when the key is released
    public class_304 keyBinding = null;
    public boolean requireKeydown = false;

    protected List<SpokeRenderer> spokeRenderers; // list so that we can reference them. 

    public AbstractContextWheelScreen(class_2561 title, int numSecs) {
        super(title);
        this.numSections = numSecs;
        spokeRenderers = new ArrayList<SpokeRenderer>();
    }

    public AbstractContextWheelScreen() {
        this(class_2561.method_43470("Abstract Context Wheel"), 8);
    }

    public AbstractContextWheelScreen(class_2561 title) {
        this(title, 8);
    }

    @Override
    protected void method_25426() {
        addAllSections();
    }

    protected void initConsts() {
        this.centerX = this.field_22789 / 2.0;
        this.centerY = this.field_22790 / 2.0;

        this.outerRadius = this.field_22790 / 4.0;
        upperBoundRadius = outerRadius * 1.1;
        lowerBoundRadius = outerRadius * 0.1 > innerRadius ? outerRadius * 0.1 : innerRadius;

        angleOffset = Math.PI * 0.5 + Math.PI / this.numSections; // so that the first spoke is centered at the top
    }

    @Override
    public void method_25432() {
        if (selectedSection != -1) {
            triggerSpoke(selectedSection);
        }
        super.method_25432();
    }

    public boolean closeWheel(boolean requireSelection) {
        WNBOI.logPrint("closing wheel with closeWheel()");
        if (selectedSection != -1) {
            triggerSpoke(selectedSection);
            if (this != null) {
                WNBOI.logPrint("actually closing");
                this.method_25419();
            }
            return true;
        }
        if (!requireSelection && this != null) {
            WNBOI.logPrint("actually closing");
            this.method_25419();
            return true;
        }
        return false;
    }

    // something thinks that this screen shouldn't be open, but it could be wrong so override this if it needs to ignore that close request.
    // e.g. if this wheel is handled by something other than a KeyboundItem it should override this to return false with reason == 0
    // reason:
    //   0: there is no KeyboundItem in the player's hands
    public void askToClose(int reason) {
        this.closeWheel(true);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0) {
            return closeWheel(true);
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        WNBOI.logPrint("pressed key " + keyCode);
        if (keyCode >= GLFW.GLFW_KEY_0 && keyCode <= GLFW.GLFW_KEY_9) {
            int index = keyCode - GLFW.GLFW_KEY_0 - 1; // -1 so that 1 key triggers 0th index
            if (index == -1) index = 9;
            if (index < this.numSections) {
                triggerSpoke(index);
                if (this != null) {
                    this.method_25419();
                }
                return true;
            }
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        if (keyBinding != null && keyBinding.method_1417(keyCode, scanCode) && requireKeydown) {
            WNBOI.logPrint("closing wheel with keyReleased()");
            this.closeWheel(false);
            return true;
        }
        return super.method_16803(keyCode, scanCode, modifiers);
    }

    // do whatever logic you want it to do
    public void triggerSpoke(int index) {
        selectedSection = -1; // so that we don't recurse ourselves
        class_310.method_1551().field_1705.method_1743().method_1812(class_2561.method_43470("triggered spoke " + index));
    }

    protected void addAllSections() {
        initConsts();
        spokeRenderers = new ArrayList<SpokeRenderer>(); // just to clear it
        for (int i = 0; i < this.numSections; i++) {
            spokeRenderers.add(genSpokeRenderer(centerX, centerY, outerRadius, this.numSections, i));
            if (i == 0) {
                spokeRenderers.get(0).labelItemStack = class_1802.field_8477.method_7854();
                spokeRenderers.get(0).labelEntity = class_310.method_1551().field_1724;
            } else {
                spokeRenderers.get(i).labelItemStack = class_1802.field_8831.method_7854();
                class_1542 ie = class_1299.field_6052.method_5883(class_310.method_1551().field_1687);
                if (ie != null) {
                    ie.method_6979(class_1802.field_8831.method_7854());
                }
                spokeRenderers.get(i).labelEntity = ie;
            }
            spokeRenderers.get(i).labelText = class_2561.method_43470(Integer.toString(i));
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        currentTime = class_310.method_1551().field_1687.method_8510() + delta;
        updateSelectedSection(mouseX, mouseY);
        super.method_25394(context, mouseX, mouseY, delta);
        for (SpokeRenderer sr : spokeRenderers) {
            sr.method_25394(context, mouseX, mouseY, delta);
        }
        tryRenderTooltip(context, mouseX, mouseY);
    }

    public void tryRenderTooltip(class_332 context, int mouseX, int mouseY) {
        if (selectedSection != -1 && (currentTime - lastStateChange) >= tooltipTickDelay) {
            doRenderTooltip(context, mouseX, mouseY);
        }
    }

    // override this to change the tooltip
    protected void doRenderTooltip(class_332 context, int mouseX, int mouseY) {
        context.method_51438(class_310.method_1551().field_1772, class_2561.method_43470("tooltip for section " + selectedSection), mouseX, mouseY);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    protected SpokeRenderer genSpokeRenderer(double orX, double orY, double rad, int numSecs, int secIndex) {
        return new SpokeRenderer(orX, orY, rad, numSecs, secIndex).setGap(gap).setInnerRadius(innerRadius).setAngleOffset(angleOffset);
    }

    // called on generated spoke renderers. override if you want to modify it.
    protected SpokeRenderer modifySpokeRenderer(SpokeRenderer sr) {
        return sr;
    }

    protected void updateSelectedSection(int mouseX, int mouseY) {
        int oldSelected = selectedSection;
        selectedSection = getSectionIndexFromMouse(mouseX, mouseY);
        if (oldSelected == selectedSection) {
            return;
        }
        if (oldSelected != -1) {
            spokeRenderers.get(oldSelected).unselect();
        }
        if (selectedSection != -1) {
            spokeRenderers.get(selectedSection).select();
        }
        lastStateChange = currentTime;
    }

    protected int getSectionIndexFromMouse(int mouseX, int mouseY) {
        double diffX = mouseX - centerX;
        double diffY = mouseY - centerY;
        if (diffX == 0 && diffY == 0) {
            // center
            return -1;
        }
        double dist = Math.sqrt(diffX * diffX + diffY * diffY);
        if (dist < lowerBoundRadius || dist > upperBoundRadius) {
            // outside of the wheel
            return -1;
        }
        // otherwise inside the wheel
        double theta;
        if (diffX == 0) {
            if (diffY > 0) {
                theta = Math.PI * 0.5;
            } else {
                theta = Math.PI * 1.5;
            }
        } else {
            theta = Math.atan(diffY / diffX);
            if (diffX < 0) {
                theta += Math.PI;
            }
        }
        return getSectionIndexFromAngle(theta);
    }

    protected int getSectionIndexFromAngle(double theta) {
        theta += angleOffset;
        theta += Math.PI * 8; // make sure it's positive
        theta %= Math.PI * 2; // make sure it's less than 2pi
        return (int) Math.floor(theta / (2 * Math.PI) * numSections);
    }
}
