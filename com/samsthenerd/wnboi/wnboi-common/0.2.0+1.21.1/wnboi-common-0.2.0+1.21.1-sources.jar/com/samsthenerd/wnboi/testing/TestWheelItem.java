package com.samsthenerd.wnboi.testing;

import com.samsthenerd.wnboi.interfaces.KeyboundItem;
import com.samsthenerd.wnboi.screen.AbstractContextWheelScreen;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_310;

public class TestWheelItem extends class_1792 implements KeyboundItem{

    TestWheelScreen screen = null;
    public TestWheelItem(class_1793 settings) {
        super(settings);
        screen = new TestWheelScreen();
        screen.keyBinding = this.getKeyBinding();
        screen.requireKeydown = true;
    }

    public AbstractContextWheelScreen getScreen(){
        return screen;
    }


    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        if(world.method_8608()){
            class_310.method_1551().method_1507(getScreen());
        }
        return class_1271.method_29237(user.method_5998(hand), world.method_8608());
    }
}
