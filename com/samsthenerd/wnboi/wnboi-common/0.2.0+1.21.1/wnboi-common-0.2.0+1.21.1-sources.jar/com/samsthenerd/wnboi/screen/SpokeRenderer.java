package com.samsthenerd.wnboi.screen;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.samsthenerd.wnboi.utils.RenderUtils;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4068;
import net.minecraft.class_4588;
import net.minecraft.class_5253.class_5254;
import org.joml.Matrix4f;

/*
 * A modular renderer for a single spoke of a wheel.
 * Can extend and override to customize.
 */
@Environment(value = EnvType.CLIENT)
public class SpokeRenderer implements class_4068 {
    protected double outerRadius; // radius of the wheel
    protected double innerRadius = 0; // distance from center to the inner edge of the spoke
    protected double gap = 10; // distance between adjacent spokes before adding outline. fine to edit for changing on select but otherwise should probably change with the ContextWheelScreen
    protected double angleOffset = Math.PI * 0.5; // should edit this from 

    protected double outerOutlineWeight = 0; // how thick the outline should be
    protected double innerOutlineWeight = 0; // how thick the outline should be

    protected double originX; // center of the wheel
    protected double originY;

    protected int sections; // number of sections, so we know arc radius
    protected int sectionIndex; // so we know which one we're actually trying to render

    protected int numDivisions = 4; // how many triangles to use to render the arc

    public double pullOutDistance = 0; // if you want to expand it like a pie chart kinda

    // these just get calculated once and then stored
    protected double startAngle;
    protected double endAngle;
    protected double midAngle;
    double gapHypot; // distance from center needed to make the gaps
    protected double offsetX; // based on gap
    protected double offsetY;

    protected boolean isSelected;

    public int curveOptions = RenderUtils.buildCurveOptions(0, 0, false, false); // controls some options about how the curves are rendered see RenderUtils#buildCurveOptions()

    protected double currentTime = 0; // updated on each render call

    protected double lastStateChange = 0; // set when selected or deselected
    protected double percentThroughAtLastChange = 1; // 0-1 used while animating to smooth out interrupted transitions. 1 is fully selected, 0 is fully deselected

    protected double selectTransitionDuration = 10; // how many ticks to take to transition to selected state (for the animation)
    protected double deselectTransitionDuration = 10; // how many ticks to take to transition to deselected state (for the animation)

    public class_1799 labelItemStack = class_1799.field_8037;
    public class_1297 labelEntity = null;
    public int labelEntitySize = 16; // how big to render the entity - probably pixels
    public class_2561 labelText = null;
    public Integer labelDist = null; // if null it will default to half the outer radius

    public SpokeRenderer(double orX, double orY, double rad, int numSecs, int secIndex) {
        this.originX = orX;
        this.originY = orY;
        this.outerRadius = rad;
        this.sections = numSecs;
        this.sectionIndex = secIndex;

        initConsts();
    }

    // make sure this gets called at some point before rendering and after changing any relevant values
    public void initConsts() {
        if (sections <= 0) {
            sections = 1;
        }
        startAngle = 2 * Math.PI * sectionIndex / sections - angleOffset;
        endAngle = 2 * Math.PI * (sectionIndex + 1) / sections - angleOffset;
        midAngle = 2 * Math.PI * (sectionIndex + 0.5) / sections - angleOffset;

        gapHypot = (gap / 2) * Math.sin(Math.PI / sections);

        offsetX = (gapHypot + pullOutDistance) * Math.cos(midAngle) / 2;
        offsetY = (gapHypot + pullOutDistance) * Math.sin(midAngle) / 2;
    }

    public SpokeRenderer setGap(double gap) {
        this.gap = gap;
        initConsts();
        return this;
    }

    public SpokeRenderer setInnerRadius(double rad) {
        this.innerRadius = rad;
        return this;
    }

    public SpokeRenderer setAngleOffset(double theta) {
        this.angleOffset = theta;
        initConsts();
        return this;
    }

    public void select() {
        isSelected = true;
        updateTimeStates();
        innerOutlineWeight = 0.5;
        pullOutDistance = 10;

        initConsts();
    }

    public void unselect() {
        isSelected = false;
        updateTimeStates();
        innerOutlineWeight = 0;
        pullOutDistance = 0;

        initConsts();
    }

    private void updateTimeStates() {
        // relying on currentTime being up to date. should be since render gets called so often
        if (isSelected) { // now selecting, see how far deselecting got
            if (deselectTransitionDuration <= 0) {
                percentThroughAtLastChange = 0;
            } else {
                percentThroughAtLastChange = Math.max(-(currentTime - lastStateChange) / deselectTransitionDuration + percentThroughAtLastChange, 0);
            }
        } else { // now deselecting, see how far selecting got
            if (selectTransitionDuration <= 0) {
                percentThroughAtLastChange = 1;
            } else {
                percentThroughAtLastChange = Math.min((currentTime - lastStateChange) / selectTransitionDuration + percentThroughAtLastChange, 1);
            }
        }
        lastStateChange = currentTime;
    }

    public List<class_243> getOuterCurvePoints() {
        List<class_243> curvePointsRaw;
        if (outerRadius <= 0) {
            curvePointsRaw = new ArrayList<class_243>();
            curvePointsRaw.add(new class_243(0, 0, 0));
        } else {
            int curveType = RenderUtils.getOuterCurve(curveOptions);
            if (curveType == 1) { // polygon
                curvePointsRaw = RenderUtils.calcPolyPoints(numDivisions, outerRadius - gapHypot, startAngle, endAngle, RenderUtils.getInvertOuter(curveOptions));
            } else { // arc / default
                curvePointsRaw = RenderUtils.calcArcPoints(numDivisions, outerRadius - gapHypot, startAngle, endAngle, RenderUtils.getInvertOuter(curveOptions));
            }
        }
        ArrayList<class_243> curvePoints = new ArrayList<class_243>();
        for (class_243 point : curvePointsRaw) {
            curvePoints.add(point.method_1019(new class_243(originX + offsetX, originY + offsetY, 0)));
        }
        return curvePoints;
    }

    public List<class_243> getInnerCurvePoints() {
        List<class_243> curvePointsRaw;
        if (innerRadius <= 0) {
            curvePointsRaw = new ArrayList<class_243>();
            curvePointsRaw.add(new class_243(0, 0, 0));
        } else {
            int curveType = RenderUtils.getInnerCurve(curveOptions);
            if (curveType == 1) { // polygon
                curvePointsRaw = RenderUtils.calcPolyPoints(numDivisions, innerRadius - gapHypot, startAngle, endAngle, RenderUtils.getInvertInner(curveOptions));
            } else { // arc / default
                curvePointsRaw = RenderUtils.calcArcPoints(numDivisions, innerRadius - gapHypot, startAngle, endAngle, RenderUtils.getInvertInner(curveOptions));
            }
        }
        ArrayList<class_243> curvePoints = new ArrayList<class_243>();
        for (class_243 point : curvePointsRaw) {
            curvePoints.add(point.method_1019(new class_243(originX + offsetX, originY + offsetY, 0)));
        }
        return curvePoints;
    }

    public void drawFill(class_332 context, int mouseX, int mouseY, float delta) {
        List<class_243> outerCurvePoints = getOuterCurvePoints();
        List<class_243> innerCurvePoints = getInnerCurvePoints();

        Matrix4f mat = context.method_51448().method_23760().method_23761();
        class_4588 buffer = context.method_51450().getBuffer(class_1921.method_51784());

        int numPoints = Math.max(outerCurvePoints.size(), innerCurvePoints.size());
        if (numPoints < 2) {
            return;
        }

        double inMult = (innerCurvePoints.size() - 1) / (double) (numPoints - 1);
        double outMult = (outerCurvePoints.size() - 1) / (double) (numPoints - 1);

        // emit quads between each pair of consecutive ring points
        for (int i = 0; i < numPoints - 1; i++) {
            int inI0 = (int) Math.floor(i * inMult);
            int outI0 = (int) Math.floor(i * outMult);
            int inI1 = (int) Math.floor((i + 1) * inMult);
            int outI1 = (int) Math.floor((i + 1) * outMult);

            class_243 inner0 = innerCurvePoints.get(Math.min(inI0, innerCurvePoints.size() - 1));
            class_243 outer0 = outerCurvePoints.get(Math.min(outI0, outerCurvePoints.size() - 1));
            class_243 inner1 = innerCurvePoints.get(Math.min(inI1, innerCurvePoints.size() - 1));
            class_243 outer1 = outerCurvePoints.get(Math.min(outI1, outerCurvePoints.size() - 1));

            int inARGB = getColorFill(i, outerCurvePoints.size(), innerCurvePoints.size(), true);
            int outARGB = getColorFill(i, outerCurvePoints.size(), innerCurvePoints.size(), false);

            buffer.method_22918(mat, (float) inner0.field_1352, (float) inner0.field_1351, 0).method_39415(inARGB);
            buffer.method_22918(mat, (float) outer0.field_1352, (float) outer0.field_1351, 0).method_39415(outARGB);
            buffer.method_22918(mat, (float) outer1.field_1352, (float) outer1.field_1351, 0).method_39415(outARGB);
            buffer.method_22918(mat, (float) inner1.field_1352, (float) inner1.field_1351, 0).method_39415(inARGB);
        }
        context.method_51452();
    }

    public List<class_243> getOutlinePoints() {
        List<class_243> outerCurvePoints = getOuterCurvePoints();
        List<class_243> innerCurvePoints = getInnerCurvePoints();
        Collections.reverse(outerCurvePoints); // so that we go backwards around the arc
        List<class_243> rawOutline = new ArrayList<class_243>();
        rawOutline.addAll(innerCurvePoints);
        rawOutline.addAll(outerCurvePoints);
        rawOutline.add(innerCurvePoints.get(0)); // so that we end up back at the start
        return rawOutline;
    }

    // need to clean this up
    public void drawOutline(class_332 context, int mouseX, int mouseY, float delta) {
        List<class_243> rawOutline = getOutlinePoints();
        List<class_243> outlineStroke = RenderUtils.calcStroke(rawOutline, outerOutlineWeight, innerOutlineWeight);
        if (outlineStroke.size() < 2) {
            return;
        }

        Matrix4f mat = context.method_51448().method_23760().method_23761();
        class_4588 buffer = context.method_51450().getBuffer(class_1921.method_51784());

        for (int v = 0; v < outlineStroke.size() - 1; v += 2) {
            class_243 outer0 = outlineStroke.get(v);
            class_243 inner0 = outlineStroke.get(v + 1);
            int color0 = getColorOutline(v);

            class_243 outer1;
            class_243 inner1;
            int color1;
            if (v + 3 < outlineStroke.size()) {
                outer1 = outlineStroke.get(v + 2);
                inner1 = outlineStroke.get(v + 3);
                color1 = getColorOutline(v + 2);
            } else {
                outer1 = outer0;
                inner1 = inner0;
                color1 = color0;
            }

            buffer.method_22918(mat, (float) inner0.field_1352, (float) inner0.field_1351, 0).method_39415(color0);
            buffer.method_22918(mat, (float) outer0.field_1352, (float) outer0.field_1351, 0).method_39415(color0);
            buffer.method_22918(mat, (float) outer1.field_1352, (float) outer1.field_1351, 0).method_39415(color1);
            buffer.method_22918(mat, (float) inner1.field_1352, (float) inner1.field_1351, 0).method_39415(color1);
        }
        context.method_51452();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        currentTime = class_310.method_1551().field_1687.method_8510() + delta;

        drawFill(context, mouseX, mouseY, delta);

        drawOutline(context, mouseX, mouseY, delta);
        renderLabel(context, mouseX, mouseY, delta);
    }

    // general call to render the label - override to call whichever you'd like
    public void renderLabel(class_332 context, int mouseX, int mouseY, float delta) {
        // renderItemLabel(context, mouseX, mouseY, delta);
        // renderEntityLabel(context, mouseX, mouseY, delta);
        // renderTextLabel(context, mouseX, mouseY, delta);
    }

    // some basic label renderers. feel free to override and do your own thing.
    // you may need to make new render functions like I have in RenderUtils to suit your needs

    protected void renderItemLabel(class_332 context, int mouseX, int mouseY, float delta) {
        if (labelItemStack == null || labelItemStack.method_7960()) {
            return;
        }
        int labelDistToUse = (labelDist == null) ? (int) (outerRadius / 2) : labelDist;
        context.method_51427(labelItemStack,
            (int) (-8 + originX + offsetX + Math.cos(midAngle) * labelDistToUse),
            (int) (-8 + originY + offsetY + Math.sin(midAngle) * labelDistToUse));
    }

    public void renderEntityLabel(class_332 context, int mouseX, int mouseY, float delta) {
        if (labelEntity == null) {
            return;
        }
        float largerDim = (Math.max(labelEntity.method_17681(), labelEntity.method_17682()));
        int sizeToUse = (int) (labelEntitySize / largerDim);
        int labelDistToUse = (labelDist == null) ? (int) (outerRadius / 2) : labelDist;
        RenderUtils.drawEntity(context,
            (int) (originX + offsetX + Math.cos(midAngle) * labelDistToUse),
            (int) (originY + offsetY + Math.sin(midAngle) * labelDistToUse), sizeToUse, labelEntity);
    }

    public void renderTextLabel(class_332 context, int mouseX, int mouseY, float delta) {
        if (labelText == null) {
            return;
        }
        int labelDistToUse = (labelDist == null) ? (int) (outerRadius / 2) : labelDist;
        int width = class_310.method_1551().field_1772.method_27525(labelText);
        RenderUtils.renderText(context, labelText,
            (int) (-(width / 2) + originX + offsetX + Math.cos(midAngle) * labelDistToUse),
            (int) (-(width / 2) + originY + offsetY + Math.sin(midAngle) * labelDistToUse), 0xFFFFFFFF);
    }

    // gets the color for a specific vertex. returns argb value
    public int getColorFill(int vI, int numOuter, int numInner, boolean isInner) {
        return class_5254.method_27764(150, 150, 150, 150); // solid gray
    }

    // gets the color for a specific point on the outline. returns argb value
    public int getColorOutline(int vI) {
        return class_5254.method_27764(128, 255, 255, 255);
    }
}
