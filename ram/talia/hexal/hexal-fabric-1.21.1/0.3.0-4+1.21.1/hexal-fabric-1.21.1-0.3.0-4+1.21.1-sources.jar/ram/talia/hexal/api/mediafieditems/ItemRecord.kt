package ram.talia.hexal.api.mediafieditems

import com.mojang.serialization.Codec
import com.mojang.serialization.codecs.RecordCodecBuilder
import net.minecraft.core.HolderLookup
import net.minecraft.core.component.DataComponents
import net.minecraft.core.registries.BuiltInRegistries
import net.minecraft.nbt.CompoundTag
import net.minecraft.nbt.NbtOps
import net.minecraft.network.chat.Component
import net.minecraft.resources.ResourceLocation
import net.minecraft.world.item.Item
import net.minecraft.world.item.ItemStack
import net.minecraft.world.item.component.CustomData
import ram.talia.hexal.api.HexalAPI
import ram.talia.hexal.api.addBounded
import ram.talia.hexal.api.config.HexalConfig
import kotlin.math.max
import kotlin.math.min

/**
 * Much of the structure of this class comes from AE2's [AEItemKey](https://github.com/AppliedEnergistics/Applied-Energistics-2/blob/9ff272a869508125daf5727746c9d9b8b00248bd/src/main/java/appeng/api/stacks/AEItemKey.java).
 *
 * 1.21.1 stores item data in components rather than a free-form `tag`, so the type of a record is held as a
 * single-count template [ItemStack] and compared with [ItemStack.isSameItemSameComponents]. `tag` is kept as a
 * compatibility accessor for the custom-data component.
 */
data class ItemRecord(var template: ItemStack, var count: Long) {
    constructor(stack: ItemStack) : this(stack.copyWithCount(1), stack.count.toLong())

    constructor(item: Item, tag: CompoundTag?, count: Long) : this(makeTemplate(item, tag), count)

    val item: Item get() = template.item

    val maxStackSize: Int get() = template.maxStackSize

    var tag: CompoundTag?
        get() = template.get(DataComponents.CUSTOM_DATA)?.copyTag()
        set(value) {
            if (value == null) template.remove(DataComponents.CUSTOM_DATA)
            else template.set(DataComponents.CUSTOM_DATA, CustomData.of(value.copy()))
        }

    val components: net.minecraft.core.component.DataComponentMap get() = template.components

    fun typeMatches(other: ItemRecord): Boolean {
        return ItemStack.isSameItemSameComponents(template, other.template)
    }

    fun typeMatches(other: ItemStack): Boolean {
        return ItemStack.isSameItemSameComponents(template, other)
    }

    fun addCount(toAdd: Long) {
        count = count.addBounded(toAdd)
    }

    /**
     * Absorb the contents of another [ItemRecord] that matches this one,
     * increasing this record's count by the other's.
     */
    fun absorb(other: ItemRecord): Boolean {
        if (!typeMatches(other))
            return false

        // protection against overflow errors (really shouldn't happen but ya know why not
        val oldCount = count
        addCount(other.count)
        other.addCount(oldCount - count) // reduce the other's count by the amount moved to this' count.

        return true
    }

    fun absorb(other: ItemStack): Int {
        if (!typeMatches(other))
            return other.count

        // protection against overflow errors (really shouldn't happen but ya know why not)
        val oldCount = count
        addCount(other.count.toLong())
        return other.count - (count - oldCount).toInt()
    }

    fun split(amount: Long): ItemRecord {
        val splittee = ItemRecord(template.copy(), min(count, amount))
        count -= splittee.count
        return splittee
    }

    fun getDisplayName(): Component {
        return template.hoverName
    }

    fun toStack(): ItemStack = toStack(1)

    fun toStack(count: Int): ItemStack {
        if (count <= 0) {
            return ItemStack.EMPTY
        }

        return template.copyWithCount(count)
    }

    fun addDrops(amount: Long, drops: MutableList<ItemStack>) {
        var leftToTake = min(amount, count)

        while (leftToTake > 0) {
            if (drops.size > HexalConfig.server.maxItemsReturned/64) {
                HexalAPI.LOGGER.warn("Tried dropping an excessive amount of items, ignoring $leftToTake $item")
                break
            }
            val taken = min(leftToTake, template.maxStackSize.toLong())
            leftToTake -= taken
            drops.add(toStack(taken.toInt()))
        }

        // subtracts the amount taken from the remaining.
        // unless it attempted to make more than 1000 stacks,
        // this should simplify to count - amount
        // the max(..., 0) is to make sure that if the original
        // amount was greater than count it doesn't result in
        // count being less than 0.
        count = max(count - amount + leftToTake, 0)
    }

    /**
     * Identity is the item + components of the template plus the count, not [ItemStack] object identity.
     */
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is ItemRecord) return false
        return count == other.count && ItemStack.isSameItemSameComponents(template, other.template)
    }

    override fun hashCode(): Int = 31 * ItemStack.hashItemAndComponents(template) + count.hashCode()

    /**
     * Writes the full template stack (all data components) via [CODEC], using registry-aware ops.
     */
    fun writeToTag(tag: CompoundTag, registries: HolderLookup.Provider) {
        val ops = registries.createSerializationContext(NbtOps.INSTANCE)
        val encoded = CODEC.encodeStart(ops, this).getOrThrow { IllegalStateException("Could not encode item record: $it") }
        tag.merge(encoded as CompoundTag)
    }

    companion object {
        const val TAG_ITEM_ID = "id"
        const val TAG_NBT = "nbt"
        const val TAG_COUNT = "count"
        const val TAG_STACK = "stack"

        val CODEC: Codec<ItemRecord> = RecordCodecBuilder.create { inst ->
            inst.group(
                ItemStack.CODEC.fieldOf(TAG_STACK).forGetter { it.template },
                Codec.LONG.fieldOf(TAG_COUNT).forGetter { it.count }
            ).apply(inst) { stack, count -> ItemRecord(stack, count) }
        }

        private fun makeTemplate(item: Item, tag: CompoundTag?): ItemStack {
            val stack = ItemStack(item)
            if (tag != null)
                stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag.copy()))
            return stack
        }

        /**
         * Taken from https://github.com/AppliedEnergistics/Applied-Energistics-2/blob/9ff272a869508125daf5727746c9d9b8b00248bd/src/main/java/appeng/api/stacks/AEItemKey.java#L130
         */
        fun readFromTag(tag: CompoundTag, registries: HolderLookup.Provider): ItemRecord? {
            if (tag.contains(TAG_STACK)) {
                val ops = registries.createSerializationContext(NbtOps.INSTANCE)
                return CODEC.parse(ops, tag).resultOrPartial { HexalAPI.LOGGER.error("Tried to load an invalid item record from NBT: $tag, $it") }.orElse(null)
            }
            // legacy shape: id + custom_data "nbt" + count
            return try {
                val item = BuiltInRegistries.ITEM.getOptional(ResourceLocation.parse(tag.getString(TAG_ITEM_ID))).orElseThrow { IllegalArgumentException("Unknown item id.") }
                val extraTag = if (tag.contains(TAG_NBT)) tag.getCompound(TAG_NBT) else null
                val count = tag.getLong(TAG_COUNT)
                ItemRecord(item, extraTag, count)
            } catch (e: Exception) {
                HexalAPI.LOGGER.error("Tried to load an invalid item key from NBT: $tag, $e")
                null
            }
        }
    }
}
