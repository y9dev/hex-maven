package ram.talia.hexal.datagen

import net.minecraft.core.HolderLookup
import net.minecraft.core.registries.BuiltInRegistries
import net.minecraft.core.registries.Registries
import net.minecraft.data.PackOutput
import net.minecraft.data.tags.TagsProvider
import net.minecraft.tags.BlockTags
import net.minecraft.world.level.block.Block
import ram.talia.hexal.common.lib.HexalBlocks
import java.util.concurrent.CompletableFuture

class HexalBlockTagProvider(output: PackOutput, lookup: CompletableFuture<HolderLookup.Provider>) :
	TagsProvider<Block>(output, Registries.BLOCK, lookup) {
	override fun addTags(lookup: HolderLookup.Provider) {
		add(tag(BlockTags.MINEABLE_WITH_PICKAXE),
			HexalBlocks.MEDIAFIED_STORAGE)
	}

	private fun add(appender: TagsProvider.TagAppender<Block>, vararg blocks: Block) {
		for (block in blocks) {
			appender.add(BuiltInRegistries.BLOCK.getResourceKey(block).orElseThrow())
		}
	}
}
