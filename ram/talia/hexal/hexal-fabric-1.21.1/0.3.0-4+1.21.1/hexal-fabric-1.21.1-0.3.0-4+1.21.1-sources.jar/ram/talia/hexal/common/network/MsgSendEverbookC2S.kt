package ram.talia.hexal.common.network

import at.petrak.hexcasting.common.msgs.IMessage
import io.netty.buffer.ByteBuf
import net.minecraft.nbt.CompoundTag
import net.minecraft.nbt.NbtAccounter
import net.minecraft.network.FriendlyByteBuf
import net.minecraft.resources.ResourceLocation
import net.minecraft.server.MinecraftServer
import net.minecraft.server.level.ServerPlayer
import ram.talia.hexal.api.HexalAPI
import ram.talia.hexal.api.everbook.Everbook
import ram.talia.hexal.xplat.IXplatAbstractions
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

data class MsgSendEverbookC2S @JvmOverloads constructor(val everbook: Everbook, val rejected: Boolean = false) : IMessage, net.minecraft.network.protocol.common.custom.CustomPacketPayload {
	override fun serialize(buf: FriendlyByteBuf) {
		buf.writeNbt(everbook.serialiseToNBT())
	}

	override fun getFabricId() = ID

	override fun type(): net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<out net.minecraft.network.protocol.common.custom.CustomPacketPayload> = TYPE

	fun handle(server: MinecraftServer, sender: ServerPlayer) {
		if (rejected) {
			HexalAPI.LOGGER.warn("Rejected malformed everbook upload from {}", sender.gameProfile.name)
			return
		}
		if (everbook.uuid != sender.uuid) {
			HexalAPI.LOGGER.warn("Rejected everbook upload from {} with a foreign uuid", sender.gameProfile.name)
			return
		}
		if (!allowUpload(sender.uuid)) {
			HexalAPI.LOGGER.warn("Rate limited everbook upload from {}", sender.gameProfile.name)
			return
		}
		server.execute {
			try {
				IXplatAbstractions.INSTANCE.setFullEverbook(sender, everbook.filterIotasIllegalInterworld(server.overworld()))
			} catch (e: Exception) {
				HexalAPI.LOGGER.warn("Could not apply everbook upload from {}", sender.gameProfile.name, e)
			}
		}
	}

	companion object {
		@JvmField
		val ID: ResourceLocation = HexalAPI.modLoc("sendever")

		@JvmField
		val TYPE: net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<MsgSendEverbookC2S> = net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type(ID)

		@JvmField
		val STREAM_CODEC: net.minecraft.network.codec.StreamCodec<net.minecraft.network.RegistryFriendlyByteBuf, MsgSendEverbookC2S> =
			net.minecraft.network.codec.StreamCodec.of({ buf, msg -> msg.serialize(buf) }, { buf -> deserialise(buf) })



		/** Maximum number of bytes of NBT a single upload may decode to. */
		const val MAX_TOTAL_BYTES = 8L * 1024 * 1024

		/** Maximum number of everbook entries (and of macros) in an upload. */
		const val MAX_ENTRIES = 4096

		/** Maximum encoded size of a single entry (pattern plus iota). */
		const val MAX_ENTRY_BYTES = 64 * 1024

		/** Minimum time between two accepted uploads from the same player. */
		const val MIN_UPLOAD_INTERVAL_MS = 5_000L

		private val lastUpload = ConcurrentHashMap<UUID, Long>()

		/** Returns true (and records the upload) if the player has not uploaded within [MIN_UPLOAD_INTERVAL_MS]. */
		@JvmStatic
		fun allowUpload(player: UUID): Boolean {
			val now = System.currentTimeMillis()
			if (lastUpload.size > 1024)
				lastUpload.values.removeIf { now - it > MIN_UPLOAD_INTERVAL_MS }
			val last = lastUpload[player]
			if (last != null && now - last < MIN_UPLOAD_INTERVAL_MS)
				return false
			lastUpload[player] = now
			return true
		}

		/** Checks the size limits of an uploaded everbook tag without decoding any iota. */
		@JvmStatic
		fun isWithinLimits(tag: CompoundTag): Boolean {
			if (tag.size() > MAX_ENTRIES + 2) return false // entries + uuid + macros
			if (!tag.hasUUID(Everbook.TAG_UUID)) return false
			val macros = tag.get(Everbook.TAG_MACROS)
			if (macros is net.minecraft.nbt.ListTag && macros.size > MAX_ENTRIES) return false
			for (key in tag.allKeys) {
				if (key == Everbook.TAG_UUID || key == Everbook.TAG_MACROS) continue
				if (tag.get(key)!!.sizeInBytes() > MAX_ENTRY_BYTES) return false
			}
			return true
		}

		/** Never throws for bad payload contents: an invalid upload becomes a [rejected] message. */
		@JvmStatic
		fun deserialise(buffer: ByteBuf): MsgSendEverbookC2S {
			val buf = FriendlyByteBuf(buffer)
			return try {
				val tag = buf.readNbt(NbtAccounter.create(MAX_TOTAL_BYTES)) as? CompoundTag
				if (tag != null && isWithinLimits(tag))
					MsgSendEverbookC2S(Everbook.fromNbt(tag))
				else
					rejectedMessage()
			} catch (e: Exception) {
				rejectedMessage()
			}
		}

		private fun rejectedMessage() = MsgSendEverbookC2S(Everbook(UUID(0, 0)), true)
	}
}
