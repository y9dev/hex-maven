package ram.talia.hexal.datagen.recipes

import at.petrak.hexcasting.api.advancements.HexAdvancementTriggers
import at.petrak.hexcasting.api.advancements.OvercastTrigger
import at.petrak.hexcasting.api.misc.MediaConstants
import at.petrak.hexcasting.api.mod.HexTags
import at.petrak.hexcasting.common.lib.HexBlocks
import at.petrak.hexcasting.common.lib.HexItems
import at.petrak.hexcasting.common.lib.HexStateIngredients
import at.petrak.hexcasting.common.recipe.ingredient.brainsweep.VillagerIngredient
import at.petrak.hexcasting.datagen.recipe.builders.BrainsweepRecipeBuilder
import net.minecraft.advancements.Criterion
import net.minecraft.advancements.critereon.MinMaxBounds
import net.minecraft.core.HolderLookup
import net.minecraft.data.PackOutput
import net.minecraft.data.recipes.RecipeCategory
import net.minecraft.data.recipes.RecipeOutput
import net.minecraft.data.recipes.RecipeProvider
import net.minecraft.data.recipes.ShapedRecipeBuilder
import net.minecraft.world.entity.npc.VillagerProfession
import net.minecraft.world.item.Items
import net.minecraft.world.level.block.Blocks
import ram.talia.hexal.api.HexalAPI
import ram.talia.hexal.common.lib.HexalBlocks
import ram.talia.hexal.common.lib.HexalItems
import ram.talia.hexal.datagen.recipes.builders.FreezeRecipeBuilder
import java.util.Optional
import java.util.concurrent.CompletableFuture

class HexalplatRecipes(output: PackOutput, registries: CompletableFuture<HolderLookup.Provider>) :
	RecipeProvider(output, registries) {


	override fun buildRecipes(recipes: RecipeOutput) {
		ShapedRecipeBuilder.shaped(RecipeCategory.REDSTONE, HexalItems.RELAY)
			.define('C', HexItems.CHARGED_AMETHYST.get())
			.define('S', HexBlocks.SLATE_BLOCK.get())
			.define('A', Items.AMETHYST_BLOCK)
			.pattern(" C ")
			.pattern("SSS")
			.pattern("SAS")
			.unlockedBy("has_item", has(HexTags.Items.STAVES))
			.save(recipes)

		FreezeRecipeBuilder(HexStateIngredients.of(Blocks.ICE), Blocks.PACKED_ICE.defaultBlockState())
			.unlockedBy("has_item", has(HexTags.Items.STAVES))
			.save(recipes, HexalAPI.modLoc("freeze/packed_ice"))
		FreezeRecipeBuilder(HexStateIngredients.of(Blocks.PACKED_ICE), Blocks.BLUE_ICE.defaultBlockState())
			.unlockedBy("has_item", has(HexTags.Items.STAVES))
			.save(recipes, HexalAPI.modLoc("freeze/blue_ice"))
		FreezeRecipeBuilder(HexStateIngredients.of(Blocks.WATER_CAULDRON), Blocks.POWDER_SNOW_CAULDRON.defaultBlockState())
			.unlockedBy("has_item", has(HexTags.Items.STAVES))
			.save(recipes, HexalAPI.modLoc("freeze/powder_snow_cauldron"))

		val enlightenment = OvercastTrigger.Instance(
			Optional.empty(),
			MinMaxBounds.Ints.ANY,  // add a little bit of slop here
			MinMaxBounds.Doubles.atLeast(0.8),
			MinMaxBounds.Doubles.between(0.1, 2.05)
		)

		BrainsweepRecipeBuilder(HexStateIngredients.of(Blocks.SHULKER_BOX),
			VillagerIngredient(VillagerProfession.CARTOGRAPHER, null, 2),
			HexalBlocks.MEDIAFIED_STORAGE.defaultBlockState(),
			MediaConstants.CRYSTAL_UNIT * 10)
			.unlockedBy("enlightenment", Criterion(HexAdvancementTriggers.OVERCAST_TRIGGER.get(), enlightenment))
			.save(recipes, HexalAPI.modLoc("mediafied_storage"))
	}
}
