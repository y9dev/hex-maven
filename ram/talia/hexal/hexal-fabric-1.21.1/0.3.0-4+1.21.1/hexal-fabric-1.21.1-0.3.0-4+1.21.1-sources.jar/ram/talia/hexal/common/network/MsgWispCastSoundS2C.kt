package ram.talia.hexal.common.network

import at.petrak.hexcasting.common.msgs.IMessage
import io.netty.buffer.ByteBuf
import net.minecraft.client.Minecraft
import net.minecraft.network.FriendlyByteBuf
import net.minecraft.resources.ResourceLocation
import ram.talia.hexal.api.HexalAPI.modLoc
import ram.talia.hexal.common.entities.BaseCastingWisp

data class MsgWispCastSoundS2C private constructor(val wispId: Int) : IMessage, net.minecraft.network.protocol.common.custom.CustomPacketPayload {
	constructor(wisp: BaseCastingWisp) : this(wisp.id)

	override fun serialize(buf: FriendlyByteBuf) {
		buf.writeInt(wispId)
	}

	override fun getFabricId() = ID

	override fun type(): net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<out net.minecraft.network.protocol.common.custom.CustomPacketPayload> = TYPE

	companion object {
		@JvmField
		val ID: ResourceLocation = modLoc("wcstsnd")

		@JvmField
		val TYPE: net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<MsgWispCastSoundS2C> = net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type(ID)

		@JvmField
		val STREAM_CODEC: net.minecraft.network.codec.StreamCodec<net.minecraft.network.RegistryFriendlyByteBuf, MsgWispCastSoundS2C> =
			net.minecraft.network.codec.StreamCodec.of({ buf, msg -> msg.serialize(buf) }, { buf -> deserialise(buf) })



		@JvmStatic
		fun deserialise(buffer: ByteBuf) = MsgWispCastSoundS2C(buffer.readInt())

		@JvmStatic
		fun handle(self: MsgWispCastSoundS2C) {
			Minecraft.getInstance().execute {
				val mc = Minecraft.getInstance()
				val level = mc.level ?: return@execute

				(level.getEntity(self.wispId) as? BaseCastingWisp)?.playCastSoundClient()
			}
		}
	}
}
