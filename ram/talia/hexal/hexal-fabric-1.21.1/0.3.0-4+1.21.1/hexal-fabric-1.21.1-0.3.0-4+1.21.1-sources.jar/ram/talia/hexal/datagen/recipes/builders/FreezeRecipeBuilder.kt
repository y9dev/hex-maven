package ram.talia.hexal.datagen.recipes.builders

import at.petrak.hexcasting.common.recipe.ingredient.state.StateIngredient
import net.minecraft.advancements.AdvancementRequirements
import net.minecraft.advancements.AdvancementRewards
import net.minecraft.advancements.Criterion
import net.minecraft.advancements.critereon.RecipeUnlockedTrigger
import net.minecraft.data.recipes.RecipeBuilder
import net.minecraft.data.recipes.RecipeOutput
import net.minecraft.resources.ResourceLocation
import net.minecraft.world.item.Item
import net.minecraft.world.level.block.state.BlockState
import ram.talia.hexal.common.recipe.FreezeRecipe

class FreezeRecipeBuilder(private val blockIn: StateIngredient, private val result: BlockState) : RecipeBuilder {

	private val advancement = LinkedHashMap<String, Criterion<*>>()

	override fun unlockedBy(pCriterionName: String, pCriterionTrigger: Criterion<*>): RecipeBuilder {
		advancement[pCriterionName] = pCriterionTrigger
		return this
	}

	override fun group(pGroupName: String?) = this

	override fun getResult(): Item = result.block.asItem()

	override fun save(recipeOutput: RecipeOutput, id: ResourceLocation) {
		val advancement = recipeOutput.advancement()
			.addCriterion("has_the_recipe", RecipeUnlockedTrigger.unlocked(id))
			.rewards(AdvancementRewards.Builder.recipe(id))
			.requirements(AdvancementRequirements.Strategy.OR)
		this.advancement.forEach(advancement::addCriterion)

		recipeOutput.accept(id, FreezeRecipe(blockIn, result), advancement.build(id.withPrefix("recipes/")))
	}
}
