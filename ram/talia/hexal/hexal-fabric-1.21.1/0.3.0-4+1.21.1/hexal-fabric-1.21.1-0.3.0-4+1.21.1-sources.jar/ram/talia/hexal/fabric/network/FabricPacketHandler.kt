﻿package ram.talia.hexal.fabric.network

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking
import net.minecraft.server.MinecraftServer
import net.minecraft.server.level.ServerPlayer
import ram.talia.hexal.common.network.MsgAddRenderLinkS2C
import ram.talia.hexal.common.network.MsgParticleLinesAck
import ram.talia.hexal.common.network.MsgRemoveEverbookS2C
import ram.talia.hexal.common.network.MsgRemoveRenderLinkS2C
import ram.talia.hexal.common.network.MsgSendEverbookC2S
import ram.talia.hexal.common.network.MsgSetEverbookS2C
import ram.talia.hexal.common.network.MsgSetRenderLinksAck
import ram.talia.hexal.common.network.MsgSingleParticleAck
import ram.talia.hexal.common.network.MsgToggleMacroS2C
import ram.talia.hexal.common.network.MsgWispCastSoundS2C

object FabricPacketHandler {
    /** Registers the payload codecs used by Hexal's custom packets. Must run on both sides. */
    fun registerPayloads() {
        PayloadTypeRegistry.playC2S().register(MsgSendEverbookC2S.TYPE, MsgSendEverbookC2S.STREAM_CODEC)

        PayloadTypeRegistry.playS2C().register(MsgSetEverbookS2C.TYPE, MsgSetEverbookS2C.STREAM_CODEC)
        PayloadTypeRegistry.playS2C().register(MsgRemoveEverbookS2C.TYPE, MsgRemoveEverbookS2C.STREAM_CODEC)
        PayloadTypeRegistry.playS2C().register(MsgToggleMacroS2C.TYPE, MsgToggleMacroS2C.STREAM_CODEC)
        PayloadTypeRegistry.playS2C().register(MsgWispCastSoundS2C.TYPE, MsgWispCastSoundS2C.STREAM_CODEC)
        PayloadTypeRegistry.playS2C().register(MsgAddRenderLinkS2C.TYPE, MsgAddRenderLinkS2C.STREAM_CODEC)
        PayloadTypeRegistry.playS2C().register(MsgRemoveRenderLinkS2C.TYPE, MsgRemoveRenderLinkS2C.STREAM_CODEC)
        PayloadTypeRegistry.playS2C().register(MsgSetRenderLinksAck.TYPE, MsgSetRenderLinksAck.STREAM_CODEC)
        PayloadTypeRegistry.playS2C().register(MsgSingleParticleAck.TYPE, MsgSingleParticleAck.STREAM_CODEC)
        PayloadTypeRegistry.playS2C().register(MsgParticleLinesAck.TYPE, MsgParticleLinesAck.STREAM_CODEC)
        PayloadTypeRegistry.playS2C().register(MsgPhaseBlockS2C.TYPE, MsgPhaseBlockS2C.STREAM_CODEC)
    }

    /** For registering packets that are client -> server (handled on the server) */
    fun initServerBound() {
        ServerPlayNetworking.registerGlobalReceiver(MsgSendEverbookC2S.TYPE) { msg, ctx ->
            msg.handle(ctx.server(), ctx.player())
        }
    }

    /** For registering packets that are server -> client (handled on the client) */
    fun initClientBound() {
        ClientPlayNetworking.registerGlobalReceiver(MsgSetEverbookS2C.TYPE) { msg, _ -> MsgSetEverbookS2C.handle(msg) }
        ClientPlayNetworking.registerGlobalReceiver(MsgRemoveEverbookS2C.TYPE) { msg, _ -> MsgRemoveEverbookS2C.handle(msg) }
        ClientPlayNetworking.registerGlobalReceiver(MsgToggleMacroS2C.TYPE) { msg, _ -> MsgToggleMacroS2C.handle(msg) }
        ClientPlayNetworking.registerGlobalReceiver(MsgWispCastSoundS2C.TYPE) { msg, _ -> MsgWispCastSoundS2C.handle(msg) }
        ClientPlayNetworking.registerGlobalReceiver(MsgAddRenderLinkS2C.TYPE) { msg, _ -> MsgAddRenderLinkS2C.handle(msg) }
        ClientPlayNetworking.registerGlobalReceiver(MsgRemoveRenderLinkS2C.TYPE) { msg, _ -> MsgRemoveRenderLinkS2C.handle(msg) }
        ClientPlayNetworking.registerGlobalReceiver(MsgSetRenderLinksAck.TYPE) { msg, _ -> MsgSetRenderLinksAck.handle(msg) }
        ClientPlayNetworking.registerGlobalReceiver(MsgSingleParticleAck.TYPE) { msg, _ -> MsgSingleParticleAck.handle(msg) }
        ClientPlayNetworking.registerGlobalReceiver(MsgParticleLinesAck.TYPE) { msg, _ -> MsgParticleLinesAck.handle(msg) }
        ClientPlayNetworking.registerGlobalReceiver(MsgPhaseBlockS2C.TYPE) { msg, _ -> MsgPhaseBlockS2C.handle(msg) }
    }
}
