package ram.talia.hexal.fabric.xplat

import ram.talia.hexal.common.items.ItemRelay
import ram.talia.hexal.xplat.IXplatAbstractions
import software.bernie.geckolib.animatable.client.GeoRenderProvider
import java.util.function.Consumer

class FabricItemRelay(properties: Properties) : ItemRelay(properties), software.bernie.geckolib.animatable.GeoItem {
    override fun createGeoRenderer(consumer: Consumer<GeoRenderProvider>) {
        consumer.accept(IXplatAbstractions.INSTANCE.itemRelayRenderProvider as GeoRenderProvider)
    }
}
