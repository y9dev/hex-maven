package ram.talia.hexal.common.network

import ram.talia.hexal.api.nbt.*

import at.petrak.hexcasting.api.HexAPI.modLoc
import at.petrak.hexcasting.api.pigment.FrozenPigment
import at.petrak.hexcasting.common.msgs.IMessage
import at.petrak.hexcasting.common.particles.ConjureParticleOptions
import io.netty.buffer.ByteBuf
import net.minecraft.client.Minecraft
import net.minecraft.network.FriendlyByteBuf
import net.minecraft.resources.ResourceLocation
import net.minecraft.world.phys.Vec3
import ram.talia.hexal.api.minus
import ram.talia.hexal.api.nextColour
import ram.talia.hexal.api.plus
import ram.talia.hexal.api.times

class MsgParticleLinesAck(val locs: List<Vec3>, val colouriser: FrozenPigment): IMessage, net.minecraft.network.protocol.common.custom.CustomPacketPayload {
    override fun serialize(buf: FriendlyByteBuf) {
        buf.writeInt(locs.size)
        for (loc in locs) {
            buf.writeDouble(loc.x)
            buf.writeDouble(loc.y)
            buf.writeDouble(loc.z)
        }
        buf.writeNbt(colouriser.toNbtTag())
    }

    override fun getFabricId() = ID

	override fun type(): net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<out net.minecraft.network.protocol.common.custom.CustomPacketPayload> = TYPE

    companion object {
        @JvmField
        val ID: ResourceLocation = modLoc("prtlns")
        @JvmField
        val TYPE: net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<MsgParticleLinesAck> = net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type(ID)

        @JvmField
        val STREAM_CODEC: net.minecraft.network.codec.StreamCodec<net.minecraft.network.RegistryFriendlyByteBuf, MsgParticleLinesAck> =
            net.minecraft.network.codec.StreamCodec.of({ buf, msg -> msg.serialize(buf) }, { buf -> deserialise(buf) })


        @JvmStatic
        fun deserialise(buffer: ByteBuf): MsgParticleLinesAck {
            val buf = FriendlyByteBuf(buffer)
            val numLocs = buf.readInt()
            val locs = mutableListOf<Vec3>()

            for (i in 1 .. numLocs) {
                locs.add(Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble()))
            }

            return MsgParticleLinesAck(locs, buf.readNbt()!!.toFrozenPigment())
        }

        @JvmStatic
        fun handle(self: MsgParticleLinesAck) {
            Minecraft.getInstance().execute {
                val level = Minecraft.getInstance().level ?: return@execute

                self.locs.zipWithNext { start, end ->
                    val steps = ((end - start).length() * 10).toInt()
                    for (i in 0 .. steps) {
                        val pos = start + (i.toDouble() / steps) * (end - start)
                        val colour = self.colouriser.nextColour(level.random)
                        level.addParticle(ConjureParticleOptions(colour),
                                pos.x, pos.y, pos.z, 0.0, 0.0, 0.0)
                    }
                }
            }
        }
    }
}