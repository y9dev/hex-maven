package ram.talia.hexal.common.recipe

import at.petrak.hexcasting.common.lib.HexStateIngredients
import at.petrak.hexcasting.common.recipe.ingredient.state.StateIngredient
import com.mojang.serialization.MapCodec
import com.mojang.serialization.codecs.RecordCodecBuilder
import net.minecraft.core.HolderLookup
import net.minecraft.network.RegistryFriendlyByteBuf
import net.minecraft.network.codec.ByteBufCodecs
import net.minecraft.network.codec.StreamCodec
import net.minecraft.world.item.ItemStack
import net.minecraft.world.item.crafting.Recipe
import net.minecraft.world.item.crafting.RecipeInput
import net.minecraft.world.item.crafting.RecipeSerializer
import net.minecraft.world.level.Level
import net.minecraft.world.level.block.Block
import net.minecraft.world.level.block.state.BlockState

data class FreezeRecipe(val blockIn: StateIngredient, val result: BlockState) : Recipe<RecipeInput> {
	override fun matches(input: RecipeInput, level: Level) = false

	fun matches(blockIn: BlockState) = this.blockIn.test(blockIn)

	override fun assemble(input: RecipeInput, registries: HolderLookup.Provider): ItemStack = ItemStack.EMPTY

	override fun canCraftInDimensions(width: Int, height: Int) = false

	override fun getResultItem(registries: HolderLookup.Provider): ItemStack = ItemStack.EMPTY.copy()

	override fun getSerializer(): RecipeSerializer<*> = HexalRecipeSerializers.FREEZE

	override fun getType() = HexalRecipeTypes.FREEZE_TYPE

	class Serializer : RecipeSerializer<FreezeRecipe> {
		companion object {
			@JvmField
			val CODEC: MapCodec<FreezeRecipe> = RecordCodecBuilder.mapCodec { inst ->
				inst.group(
					HexStateIngredients.TYPED_CODEC.fieldOf("blockIn").forGetter(FreezeRecipe::blockIn),
					BlockState.CODEC.fieldOf("result").forGetter(FreezeRecipe::result)
				).apply(inst, ::FreezeRecipe)
			}

			@JvmField
			val STREAM_CODEC: StreamCodec<RegistryFriendlyByteBuf, FreezeRecipe> = StreamCodec.composite(
				HexStateIngredients.TYPED_STREAM_CODEC, FreezeRecipe::blockIn,
				ByteBufCodecs.VAR_INT, { recipe -> Block.getId(recipe.result) },
				{ state, stateId -> FreezeRecipe(state, Block.stateById(stateId)) }
			)
		}

		override fun codec(): MapCodec<FreezeRecipe> = CODEC

		override fun streamCodec(): StreamCodec<RegistryFriendlyByteBuf, FreezeRecipe> = STREAM_CODEC
	}
}
