package ram.talia.hexal.api.nbt

import at.petrak.hexcasting.api.casting.iota.EntityIota
import at.petrak.hexcasting.api.casting.iota.Iota
import at.petrak.hexcasting.api.casting.iota.ListIota
import at.petrak.hexcasting.api.casting.iota.NullIota
import at.petrak.hexcasting.api.utils.asCompound
import net.minecraft.nbt.CompoundTag
import net.minecraft.nbt.ListTag
import net.minecraft.server.level.ServerLevel
import net.minecraft.world.entity.Entity

/**
 * A lazily (de)serialised list of iotas. Hex 0.12's [EntityIota] only stores a UUID, so the old "force serialisation
 * when a referenced entity is removed" dance is no longer necessary: serialisation can just happen on demand.
 */
class SerialisedIotaList(private var tag: ListTag?, private var iotas: MutableList<Iota>?) {

    constructor(iotas: MutableList<Iota>?) : this(null, iotas)
    constructor(tag: ListTag?) : this(tag, null)
    constructor() : this(null, null)

    fun clear() {
        iotas = null
        tag = null
    }

    fun set(iotas: MutableList<Iota>) {
        this.iotas = iotas
        this.tag = null
    }

    fun set(tag: ListTag) {
        this.tag = tag
        this.iotas = null
    }

    fun refreshIotas(level: ServerLevel) {
        // no-op: kept for API compatibility
    }

    fun getIotas(level: ServerLevel): List<Iota> {
        if (iotas == null) {
            iotas = tag?.toIotaList(level) ?: mutableListOf()
        }
        return iotas ?: mutableListOf()
    }

    fun getTag(level: ServerLevel): ListTag {
        if (tag == null && iotas != null) {
            tag = iotas!!.toNbtList()
        }
        return tag ?: ListTag()
    }

    fun getTag(): ListTag {
        return tag ?: (iotas?.toNbtList() ?: ListTag())
    }

    fun add(iota: Iota) {
        if (tag != null) {
            tag!!.add(iota.toNbtTag())
            iotas = null
        } else if (iotas != null) {
            iotas!!.add(iota)
        } else {
            iotas = mutableListOf(iota)
        }
    }

    fun add(tag: CompoundTag) {
        if (this.tag != null) {
            this.tag!!.add(tag)
            iotas = null
        } else if (iotas != null) {
            this.tag = iotas!!.toNbtList()
            this.tag!!.add(tag)
            iotas = null
        } else {
            this.tag = ListTag()
            this.tag!!.add(tag)
        }
    }

    fun pop(level: ServerLevel): Iota? {
        if (iotas != null) {
            if (iotas!!.isEmpty())
                return null
            return iotas!!.removeAt(0)
        }

        if (tag != null) {
            if (tag!!.isEmpty())
                return null

            val poppedTag = tag!!.removeAt(0)
            if (tag!!.isEmpty())
                this.tag = null

            return poppedTag.asCompound.toIota(level)
        }

        return null
    }

    fun size(): Int {
        return tag?.size ?: iotas?.size ?: 0
    }

    fun getReferencedEntities(level: ServerLevel): List<Entity> {
        val out = mutableListOf<Entity>()
        collectEntities(getIotas(level), out, level)
        return out
    }

    private fun collectEntities(iotas: List<Iota>, out: MutableList<Entity>, level: ServerLevel) {
        for (iota in iotas) {
            when (iota) {
                is EntityIota -> iota.getEntity(level)?.let { if (!out.contains(it)) out.add(it) }
                is ListIota -> collectEntities(iota.list, out, level)
                else -> {}
            }
        }
    }
}

// Wrapper for SerializedIotaList (only ever used for ravenmind)
class SerialisedIota(private val iotaList: SerialisedIotaList = SerialisedIotaList(null, null)) {

    constructor(iota: Iota?) : this(SerialisedIotaList(if (iota == null) null else mutableListOf(iota)))
    constructor(tag: CompoundTag?) : this(SerialisedIotaList())
    {
        if (tag != null)
        {
            iotaList.add(tag)
        }
    }

    constructor() : this(SerialisedIotaList())

    fun getTag() : CompoundTag {
        val listTag = iotaList.getTag()
        return if (listTag.size == 0)
        {
            NullIota().toNbtTag()
        }
        else
        {
            listTag[0].asCompound
        }
    }

    fun getIota(level: ServerLevel) : Iota {
        val iotas = iotaList.getIotas(level)
        return if (iotas.isEmpty())
        {
            NullIota()
        }
        else
        {
            iotas[0]
        }
    }

    fun set(iota: Iota) {
        iotaList.set(mutableListOf(iota))
    }

    fun set(tag: CompoundTag) {
        val listTag = ListTag()
        listTag.add(tag)
        iotaList.set(listTag)
    }

    fun getReferencedEntities(level: ServerLevel) : List<Entity> {
        return iotaList.getReferencedEntities(level)
    }

    fun refreshIota(level: ServerLevel)
    {
        iotaList.refreshIotas(level)
    }
}
