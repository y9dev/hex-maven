package ram.talia.hexal.api.casting.iota;

import at.petrak.hexcasting.api.casting.eval.CastingEnvironment;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import kotlin.Pair;
import net.minecraft.ChatFormatting;
import net.minecraft.core.UUIDUtil;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import ram.talia.hexal.api.gates.GateManager;
import ram.talia.hexal.common.lib.hex.HexalIotaTypes;

import java.util.HashSet;
import java.util.function.Function;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.FriendlyByteBuf;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

public class GateIota extends Iota {

    public static String TAG_INDEX = "index";
    public static String TAG_TARGET = "target";
    public static String TAG_ANCHOR = "anchor";
    // legacy 1.20 tag names, kept so old world data can still be read by hand if needed
    public static String TAG_TARGET_TYPE = "target_type";
    public static String TAG_TARGET_X = "target_x";
    public static String TAG_TARGET_Y = "target_y";
    public static String TAG_TARGET_Z = "target_z";
    public static String TAG_TARGET_UUID = "target_uuid";
    public static String TAG_TARGET_NAME = "target_name";

    public static final StreamCodec<FriendlyByteBuf, Vec3> VEC3_STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.DOUBLE, v -> v.x,
            ByteBufCodecs.DOUBLE, v -> v.y,
            ByteBufCodecs.DOUBLE, v -> v.z,
            Vec3::new);

    public record EntityAnchor(UUID uuid, String name, Vec3 offset) {
        public static final Codec<EntityAnchor> CODEC = RecordCodecBuilder.create(inst -> inst.group(
                UUIDUtil.CODEC.fieldOf("uuid").forGetter(EntityAnchor::uuid),
                Codec.STRING.fieldOf("name").forGetter(EntityAnchor::name),
                Vec3.CODEC.fieldOf("offset").forGetter(EntityAnchor::offset)
        ).apply(inst, EntityAnchor::new));

        public static final StreamCodec<RegistryFriendlyByteBuf, EntityAnchor> STREAM_CODEC = StreamCodec.composite(
                UUIDUtil.STREAM_CODEC, EntityAnchor::uuid,
                ByteBufCodecs.STRING_UTF8, EntityAnchor::name,
                VEC3_STREAM_CODEC, EntityAnchor::offset,
                EntityAnchor::new
        );
    }

    private final int index;
    @Nullable
    private final Either<Vec3, EntityAnchor> target;

    public GateIota(int index, @Nullable Either<Vec3, Pair<Entity, Vec3>> target) {
        this(index, target == null ? null : target.mapRight(pair ->
                new EntityAnchor(pair.getFirst().getUUID(), pair.getFirst().getName().getString(), pair.getSecond())), true);
    }

    private GateIota(int index, @Nullable Either<Vec3, EntityAnchor> target, boolean raw) {
        super(() -> HexalIotaTypes.GATE);
        this.index = index;
        this.target = target;
    }

    public int getGateIndex() {
        return this.index;
    }

    public @Nullable Either<Vec3, EntityAnchor> getTarget() {
        return this.target;
    }

    public @Nullable Vec3 getTargetPos(ServerLevel level) {
        var target = this.getTarget();

        if (target == null)
            return null;

        return target.map(vec3 -> vec3, entityAnchor -> {
            var entity = level.getEntity(entityAnchor.uuid());

            if (entity == null)
                return null;

            return entity.position().add(entityAnchor.offset());
        });
    }

    public boolean isDrifting() {
        return this.getTarget() == null;
    }

    public boolean isLocationAnchored() {
        var target = this.getTarget();
        return (target != null) && (target.left().isPresent());
    }

    public boolean isEntityAnchored() {
        var target = this.getTarget();
        return (target != null) && (target.right().isPresent());
    }

    public Set<Entity> getMarked(ServerLevel level) {
        var marked = GateManager.allMarked.getOrDefault(this.getGateIndex(), new HashSet<>());

        var out = new HashSet<Entity>();
        for (var mark : marked) {
            var markEntity = level.getEntity(mark);
            if (markEntity != null)
                out.add(markEntity);
        }
        return out;
    }

    public boolean isMarked(Entity entity) {
        var marked = GateManager.allMarked.getOrDefault(this.getGateIndex(), new HashSet<>());
        return marked.contains(entity.getUUID());
    }

    public int getNumMarked() {
        return GateManager.allMarked.getOrDefault(this.getGateIndex(), new HashSet<>()).size();
    }

    public void mark(Entity entity) {
        GateManager.mark(this.getGateIndex(), entity);
    }

    public void unmark(@NotNull Entity entity) {
        GateManager.unmark(this.getGateIndex(), entity);
    }

    public void clearMarked() {
        GateManager.clearMarked(this.getGateIndex());
    }

    @Override
    protected boolean toleratesOther(Iota that) {
        return typesMatch(this, that) &&
                that instanceof GateIota gthat &&
                this.getGateIndex() == gthat.getGateIndex();
    }

    @Override
    public boolean isTruthy(@Nullable CastingEnvironment env) {
        return true;
    }

    @Override
    public @NotNull Component display() {
        if (this.isDrifting()) {
            return Component.translatable("hexal.spelldata.gate", this.getGateIndex()).withStyle(ChatFormatting.LIGHT_PURPLE);
        }
        // if we get here then getTarget can't be null.
        //noinspection DataFlowIssue
        return this.getTarget().map(
                vec3 -> Component.translatable("hexal.spelldata.gate", this.getGateIndex()).append(String.format(" (%.2f, %.2f, %.2f)", vec3.x, vec3.y, vec3.z)).withStyle(ChatFormatting.LIGHT_PURPLE),
                entityAnchor -> {
                    var offsetStr = String.format("%.2f, %.2f, %.2f", entityAnchor.offset().x, entityAnchor.offset().y, entityAnchor.offset().z);
                    var anchorStr = String.format(" (%s, %s)", entityAnchor.name(), offsetStr);

                    return Component.translatable("hexal.spelldata.gate", this.getGateIndex()).append(anchorStr).withStyle(ChatFormatting.LIGHT_PURPLE);
                });
    }

    @Override
    public int hashCode() {
        return this.index;
    }

    public static IotaType<GateIota> TYPE = new IotaType<>() {
        public static final MapCodec<GateIota> CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
                Codec.INT.fieldOf(TAG_INDEX).forGetter(GateIota::getGateIndex),
                Vec3.CODEC.optionalFieldOf(TAG_TARGET).forGetter(g -> Optional.ofNullable(g.target).flatMap(t -> t.left())),
                EntityAnchor.CODEC.optionalFieldOf(TAG_ANCHOR).forGetter(g -> Optional.ofNullable(g.target).flatMap(t -> t.right()))
        ).apply(inst, (index, target, anchor) -> {
            if (target.isPresent())
                return new GateIota(index, Either.left(target.get()), true);
            if (anchor.isPresent())
                return new GateIota(index, Either.right(anchor.get()), true);
            return new GateIota(index, null, true);
        }));

        public static final StreamCodec<RegistryFriendlyByteBuf, GateIota> STREAM_CODEC = StreamCodec.composite(
                ByteBufCodecs.VAR_INT, GateIota::getGateIndex,
                ByteBufCodecs.optional(VEC3_STREAM_CODEC), g -> Optional.ofNullable(g.target).flatMap(t -> t.left()),
                ByteBufCodecs.optional(EntityAnchor.STREAM_CODEC), g -> Optional.ofNullable(g.target).flatMap(t -> t.right()),
                (index, target, anchor) -> {
                    if (target.isPresent())
                        return new GateIota(index, Either.left(target.get()), true);
                    if (anchor.isPresent())
                        return new GateIota(index, Either.right(anchor.get()), true);
                    return new GateIota(index, null, true);
                }
        );

        @Override
        public MapCodec<GateIota> codec() {
            return CODEC;
        }

        @Override
        public StreamCodec<RegistryFriendlyByteBuf, GateIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xff_ff55ff;
        }
    };
}
