package ram.talia.hexal.common.network

import ram.talia.hexal.api.nbt.*

import at.petrak.hexcasting.api.casting.math.HexPattern
import at.petrak.hexcasting.common.msgs.IMessage
import io.netty.buffer.ByteBuf
import net.minecraft.client.Minecraft
import net.minecraft.nbt.CompoundTag
import net.minecraft.network.FriendlyByteBuf
import net.minecraft.resources.ResourceLocation
import ram.talia.hexal.api.HexalAPI
import ram.talia.hexal.xplat.IClientXplatAbstractions

data class MsgSetEverbookS2C(val key: HexPattern, val iota: CompoundTag) : IMessage, net.minecraft.network.protocol.common.custom.CustomPacketPayload {
	override fun serialize(buf: FriendlyByteBuf) {
		buf.writeNbt(key.toNbtTag())
		buf.writeNbt(iota)
	}

	override fun getFabricId() = ID

	override fun type(): net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<out net.minecraft.network.protocol.common.custom.CustomPacketPayload> = TYPE

	companion object {
		@JvmField
		val ID: ResourceLocation = HexalAPI.modLoc("setever")

		@JvmField
		val TYPE: net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<MsgSetEverbookS2C> = net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type(ID)

		@JvmField
		val STREAM_CODEC: net.minecraft.network.codec.StreamCodec<net.minecraft.network.RegistryFriendlyByteBuf, MsgSetEverbookS2C> =
			net.minecraft.network.codec.StreamCodec.of({ buf, msg -> msg.serialize(buf) }, { buf -> deserialise(buf) })



		@JvmStatic
		fun deserialise(buffer: ByteBuf): MsgSetEverbookS2C {
			val buf = FriendlyByteBuf(buffer)
			return MsgSetEverbookS2C(buf.readNbt()!!.toHexPattern(), buf.readNbt()!!)
		}

		@JvmStatic
		fun handle(self: MsgSetEverbookS2C) {
			Minecraft.getInstance().execute {
				IClientXplatAbstractions.INSTANCE.setClientEverbookIota(self.key, self.iota)
			}
		}
	}
}