package ram.talia.hexal.common.network

import ram.talia.hexal.api.nbt.*

import at.petrak.hexcasting.api.casting.math.HexPattern
import at.petrak.hexcasting.common.msgs.IMessage
import io.netty.buffer.ByteBuf
import net.minecraft.client.Minecraft
import net.minecraft.network.FriendlyByteBuf
import net.minecraft.resources.ResourceLocation
import ram.talia.hexal.api.HexalAPI
import ram.talia.hexal.xplat.IClientXplatAbstractions

/**
 * Remove a pattern from the player's Everbook - should only be sent server to client.
 */
data class MsgRemoveEverbookS2C(val key: HexPattern) : IMessage, net.minecraft.network.protocol.common.custom.CustomPacketPayload {
	override fun serialize(buf: FriendlyByteBuf) {
		buf.writeNbt(key.toNbtTag())
	}

	override fun getFabricId() = ID

	override fun type(): net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<out net.minecraft.network.protocol.common.custom.CustomPacketPayload> = TYPE

	companion object {
		@JvmField
		val ID: ResourceLocation = HexalAPI.modLoc("remever")

		@JvmField
		val TYPE: net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<MsgRemoveEverbookS2C> = net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type(ID)

		@JvmField
		val STREAM_CODEC: net.minecraft.network.codec.StreamCodec<net.minecraft.network.RegistryFriendlyByteBuf, MsgRemoveEverbookS2C> =
			net.minecraft.network.codec.StreamCodec.of({ buf, msg -> msg.serialize(buf) }, { buf -> deserialise(buf) })



		@JvmStatic
		fun deserialise(buffer: ByteBuf): MsgRemoveEverbookS2C {
			val buf = FriendlyByteBuf(buffer)
			return MsgRemoveEverbookS2C(buf.readNbt()!!.toHexPattern())
		}

		@JvmStatic
		fun handle(self: MsgRemoveEverbookS2C) {
			Minecraft.getInstance().execute {
				IClientXplatAbstractions.INSTANCE.removeClientEverbookIota(self.key)
			}
		}
	}
}