package ram.talia.hexal.fabric.cc

import org.ladysnake.cca.api.v3.component.ComponentKey
import org.ladysnake.cca.api.v3.component.ComponentRegistry
import org.ladysnake.cca.api.v3.entity.EntityComponentFactoryRegistry
import org.ladysnake.cca.api.v3.entity.EntityComponentInitializer
import org.ladysnake.cca.api.v3.entity.RespawnCopyStrategy
import ram.talia.hexal.api.HexalAPI.modLoc

class HexalCardinalComponents : EntityComponentInitializer {
	override fun registerEntityComponentFactories(registry: EntityComponentFactoryRegistry) {
		registry.registerForPlayers(BOUND_STORAGE, ::CCBoundStorage, RespawnCopyStrategy.ALWAYS_COPY)
		registry.registerForPlayers(EVERBOOK, ::CCEverbook, RespawnCopyStrategy.ALWAYS_COPY)
		registry.registerForPlayers(PLAYER_LINKSTORE, ::CCPlayerLinkstore, RespawnCopyStrategy.NEVER_COPY)
		registry.registerForPlayers(WISP_CASTING_MANAGER, ::CCWispCastingManager, RespawnCopyStrategy.ALWAYS_COPY)
	}

	companion object {
		@JvmField
		val BOUND_STORAGE: ComponentKey<CCBoundStorage> = ComponentRegistry.getOrCreate(
				modLoc("bound_storage"),
				CCBoundStorage::class.java
		)
		@JvmField
		val EVERBOOK: ComponentKey<CCEverbook> = ComponentRegistry.getOrCreate(
				modLoc("everbook"),
				CCEverbook::class.java
		)
		@JvmField
		val PLAYER_LINKSTORE: ComponentKey<CCPlayerLinkstore> = ComponentRegistry.getOrCreate(
				modLoc("player_linkstore"),
				CCPlayerLinkstore::class.java
		)
		@JvmField
		val WISP_CASTING_MANAGER: ComponentKey<CCWispCastingManager> = ComponentRegistry.getOrCreate(
			modLoc("wisp_casting_manager"),
			CCWispCastingManager::class.java
		)
	}
}
