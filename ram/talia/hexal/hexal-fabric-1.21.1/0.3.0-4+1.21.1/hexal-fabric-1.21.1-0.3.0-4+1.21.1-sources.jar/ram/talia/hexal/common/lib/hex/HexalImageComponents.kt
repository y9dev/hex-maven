package ram.talia.hexal.common.lib.hex

import ram.talia.hexal.common.lib.hex.HexalImageComponents
import at.petrak.hexcasting.api.casting.eval.vm.CastingImage
import at.petrak.hexcasting.api.casting.eval.vm.ImageComponentType
import at.petrak.hexcasting.xplat.IXplatAbstractions
import net.minecraft.core.Registry
import net.minecraft.nbt.CompoundTag
import net.minecraft.network.codec.ByteBufCodecs
import ram.talia.hexal.api.HexalAPI.modLoc

/**
 * Hex 0.12 replaced the free-form `CastingImage.userData` tag with typed image components. Hexal's patterns use a
 * single opaque tag component for their cross-pattern state (temporary mote storage, per-cast tick counters, consumed
 * media), which keeps the original 0.11 logic intact while going through the new component API.
 */
object HexalImageComponents {
    @JvmField
    val USERDATA: ImageComponentType<CompoundTag> = ImageComponentType(
        CompoundTag.CODEC,
        ByteBufCodecs.COMPOUND_TAG
    )

    @JvmStatic
    fun register() {
        Registry.register(IXplatAbstractions.INSTANCE.imageComponentRegistry, modLoc("userdata"), USERDATA)
    }

    @JvmStatic
    fun userData(image: CastingImage): CompoundTag =
        image.getComponent(USERDATA)?.copy() ?: CompoundTag()

    @JvmStatic
    fun withUserData(image: CastingImage, tag: CompoundTag): CastingImage =
        if (tag.isEmpty) image.withoutComponent(USERDATA) else image.withComponent(USERDATA, tag)
}
