package ram.talia.hexal.fabric.datagen;

import at.petrak.hexcasting.api.HexAPI;
import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.minecraft.data.loot.LootTableProvider;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import ram.talia.hexal.datagen.HexalBlockTagProvider;
import ram.talia.hexal.datagen.HexalLootTables;
import ram.talia.hexal.datagen.recipes.HexalplatRecipes;
import ram.talia.hexal.datagen.tag.HexalActionTagProvider;

import java.util.List;
import java.util.Set;

public class HexalFabricDataGenerators implements DataGeneratorEntrypoint {
	@Override
	public void onInitializeDataGenerator(FabricDataGenerator gen) {
		HexAPI.LOGGER.info("Starting Hexal Fabric datagen");

		var pack = gen.createPack();

		pack.addProvider(HexalplatRecipes::new);
		pack.addProvider(HexalBlockTagProvider::new);
		pack.addProvider(HexalActionTagProvider::new);

		pack.addProvider((FabricDataGenerator.Pack.RegistryDependentFactory<LootTableProvider>) (output, registries) ->
			new LootTableProvider(
				output, Set.of(),
				List.of(new LootTableProvider.SubProviderEntry(provider -> new HexalLootTables(), LootContextParamSets.ALL_PARAMS)),
				registries
			));
	}
}
