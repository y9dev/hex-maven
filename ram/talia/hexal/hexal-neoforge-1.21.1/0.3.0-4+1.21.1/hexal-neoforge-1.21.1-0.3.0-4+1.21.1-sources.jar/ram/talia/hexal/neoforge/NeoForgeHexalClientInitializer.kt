package ram.talia.hexal.neoforge

import net.minecraft.client.Minecraft
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider
import net.minecraft.world.level.block.entity.BlockEntity
import net.minecraft.world.level.block.entity.BlockEntityType
import net.neoforged.bus.api.IEventBus
import net.neoforged.fml.ModContainer
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent
import net.neoforged.neoforge.client.event.ClientTickEvent
import net.neoforged.neoforge.client.event.EntityRenderersEvent
import net.neoforged.neoforge.client.gui.ConfigurationScreen
import net.neoforged.neoforge.client.gui.IConfigScreenFactory
import net.neoforged.neoforge.common.NeoForge
import net.neoforged.neoforge.event.tick.PlayerTickEvent
import ram.talia.hexal.api.HexalAPI
import ram.talia.hexal.client.LinkablePacketHolder
import ram.talia.hexal.client.RegisterClientStuff
import ram.talia.hexal.common.lib.HexalBlockEntities
import ram.talia.hexal.neoforge.client.blocks.BlockEntityRelayRenderer
import ram.talia.hexal.neoforge.data.HexalAttachments

/** Only ever loaded on the physical client. */
object NeoForgeHexalClientInitializer {
    @JvmStatic
    fun init(modBus: IEventBus, modContainer: ModContainer) {
        modContainer.registerExtensionPoint(IConfigScreenFactory::class.java,
            IConfigScreenFactory { container, parent -> ConfigurationScreen(container, parent) })

        modBus.addListener { event: FMLClientSetupEvent ->
            event.enqueueWork { RegisterClientStuff.init() }
        }

        modBus.addListener { event: EntityRenderersEvent.RegisterRenderers ->
            RegisterClientStuff.registerBlockEntityRenderers(object : RegisterClientStuff.BlockEntityRendererRegisterer {
                override fun <T : BlockEntity> registerBlockEntityRenderer(type: BlockEntityType<T>, berp: BlockEntityRendererProvider<in T>) {
                    event.registerBlockEntityRenderer(type, berp)
                }
            })
            event.registerBlockEntityRenderer(HexalBlockEntities.RELAY) { BlockEntityRelayRenderer() }
        }

        val evBus = NeoForge.EVENT_BUS

        // reattempt link render packets that failed to apply properly once every 20 ticks.
        evBus.addListener { _: ClientTickEvent.Pre -> LinkablePacketHolder.maybeRetry() }

        // Cardinal Components ticked these on Fabric (for every player the client knows about).
        evBus.addListener { event: PlayerTickEvent.Post ->
            val player = event.entity
            if (player.level().isClientSide) {
                player.getData(HexalAttachments.PLAYER_LINKSTORE).tick()
                if (player === Minecraft.getInstance().player)
                    player.getData(HexalAttachments.EVERBOOK).clientTick()
            }
        }

        evBus.addListener { event: ClientPlayerNetworkEvent.LoggingOut ->
            val player = event.player ?: return@addListener
            HexalAPI.LOGGER.info("EverbookData saveToDisk")
            player.getData(HexalAttachments.EVERBOOK).saveToDisk()
        }
    }
}
