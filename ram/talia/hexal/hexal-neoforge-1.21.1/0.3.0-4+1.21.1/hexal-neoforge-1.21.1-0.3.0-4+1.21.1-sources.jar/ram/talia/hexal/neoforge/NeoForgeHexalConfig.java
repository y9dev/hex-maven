package ram.talia.hexal.neoforge;

import at.petrak.hexcasting.api.misc.MediaConstants;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.common.ModConfigSpec;
import org.jetbrains.annotations.NotNull;
import ram.talia.hexal.api.config.HexalConfig;

import java.util.List;

import static ram.talia.hexal.api.config.HexalConfig.noneMatch;

public class NeoForgeHexalConfig implements HexalConfig.CommonConfigAccess {
    public NeoForgeHexalConfig(ModConfigSpec.Builder builder) {
    }

    public static class Client implements HexalConfig.ClientConfigAccess {
        public Client(ModConfigSpec.Builder builder) {
        }
    }

    public static class Server implements HexalConfig.ServerConfigAccess {
        private final ModConfigSpec.BooleanValue generateSlipwayGeodes;

        // misc spells
        private final ModConfigSpec.DoubleValue fallingBlockCost;
        private final ModConfigSpec.DoubleValue freezeCost;
        private final ModConfigSpec.DoubleValue particlesCost;
        private final ModConfigSpec.DoubleValue placeTypeCost;
        private final ModConfigSpec.DoubleValue smeltCost;

        // fabric only spells (kept so both loaders share one config interface)
        private final ModConfigSpec.DoubleValue phaseBlockCostFactor;

        // wisp spells
        private final ModConfigSpec.DoubleValue moveSpeedSetCost;
        private final ModConfigSpec.DoubleValue summonTickingWispCost;
        private final ModConfigSpec.DoubleValue summonProjectileWispCost;
        private final ModConfigSpec.DoubleValue summonProjectileWispMinCost;

        // wisp upkeep
        private final ModConfigSpec.DoubleValue tickingWispUpkeepPerTick;
        private final ModConfigSpec.DoubleValue projectileWispUpkeepPerTick;
        private final ModConfigSpec.DoubleValue untriggeredWispUpkeepDiscount;
        private final ModConfigSpec.DoubleValue linkUpkeepPerTick;
        private final ModConfigSpec.DoubleValue seonDiscountFactor;
        private final ModConfigSpec.DoubleValue storingPlayerCostScaleFactor;
        private final ModConfigSpec.DoubleValue mediaFlowRateOverLink;

        // link spells
        private final ModConfigSpec.DoubleValue linkCost;
        private final ModConfigSpec.DoubleValue sendIotaCost;
        private final ModConfigSpec.DoubleValue unlinkCost;

        // gate spells
        private final ModConfigSpec.DoubleValue makeGateCost;
        private final ModConfigSpec.DoubleValue markGateCost;
        private final ModConfigSpec.DoubleValue closeGateCost;
        private final ModConfigSpec.DoubleValue closeGateDistanceCostFactor;
        private final ModConfigSpec.DoubleValue maxGateOffset;

        // item spells
        private final ModConfigSpec.DoubleValue bindStorageCost;
        private final ModConfigSpec.DoubleValue bindTemporaryStorageCost;
        private final ModConfigSpec.DoubleValue makeItemCost;
        private final ModConfigSpec.DoubleValue returnItemCost;
        private final ModConfigSpec.DoubleValue craftItemCost;
        private final ModConfigSpec.DoubleValue tradeItemCost;
        private final ModConfigSpec.DoubleValue useItemOnCost;
        private final ModConfigSpec.IntValue maxItemsReturned;
        private final ModConfigSpec.IntValue maxRecordsInMediafiedStorage;

        // great spells
        private final ModConfigSpec.DoubleValue consumeWispOwnCost;
        private final ModConfigSpec.DoubleValue consumeWispOthersCostPerMedia;
        private final ModConfigSpec.DoubleValue seonWispSetCost;
        private final ModConfigSpec.DoubleValue tickConstantCost;
        private final ModConfigSpec.DoubleValue tickCostPerTicked;
        private final ModConfigSpec.IntValue tickRandomTickIProb;
        private final ModConfigSpec.ConfigValue<List<? extends String>> accelerateDenyList;

        public Server(ModConfigSpec.Builder builder) {
            generateSlipwayGeodes = builder.comment("Whether slipway geodes generate in the world.")
                    .define("generateSlipwayGeodes", DEFAULT_GENERATE_SLIPWAY_GEODES);

            builder.push("miscSpells");
            fallingBlockCost = cost(builder, "fallingBlockCost", DEFAULT_FALLING_BLOCK_COST);
            freezeCost = cost(builder, "freezeCost", DEFAULT_FREEZE_COST);
            particlesCost = cost(builder, "particlesCost", DEFAULT_PARTICLES_COST);
            placeTypeCost = cost(builder, "placeTypeCost", DEFAULT_PLACE_TYPE_COST);
            smeltCost = cost(builder, "smeltCost", DEFAULT_SMELT_COST);
            builder.pop();

            builder.push("fabricOnlySpells");
            phaseBlockCostFactor = builder.comment("Only used by the Fabric version of Hexal (the phase block spell needs Phantom).")
                    .defineInRange("phaseBlockCostFactor", DEFAULT_PHASE_BLOCK_COST_FACTOR,
                            MIN_PHASE_BLOCK_COST_FACTOR, MAX_PHASE_BLOCK_COST_FACTOR);
            builder.pop();

            builder.push("wispSpells");
            moveSpeedSetCost = cost(builder, "moveSpeedSetCost", DEFAULT_MOVE_SPEED_SET_COST);
            summonTickingWispCost = cost(builder, "summonTickingWispCost", DEFAULT_SUMMON_TICKING_WISP_COST);
            summonProjectileWispCost = cost(builder, "summonProjectileWispCost", DEFAULT_SUMMON_PROJECTILE_WISP_COST);
            summonProjectileWispMinCost = cost(builder, "summonProjectileWispMinCost", DEFAULT_SUMMON_PROJECTILE_WISP_MIN_COST);
            builder.pop();

            builder.push("wispUpkeep");
            tickingWispUpkeepPerTick = cost(builder, "tickingWispUpkeepPerTick", DEFAULT_TICKING_WISP_UPKEEP_PER_TICK);
            projectileWispUpkeepPerTick = cost(builder, "projectileWispUpkeepPerTick", DEFAULT_PROJECTILE_WISP_UPKEEP_PER_TICK);
            untriggeredWispUpkeepDiscount = builder.comment("Multiplier applied to the upkeep of wisps that have not been triggered.")
                    .defineInRange("untriggeredWispUpkeepDiscount", DEFAULT_UNTRIGGERED_WISP_UPKEEP_DISCOUNT,
                            MIN_UNTRIGGERED_WISP_UPKEEP_DISCOUNT, MAX_UNTRIGGERED_WISP_UPKEEP_DISCOUNT);
            linkUpkeepPerTick = cost(builder, "linkUpkeepPerTick", DEFAULT_LINK_UPKEEP_PER_TICK);
            seonDiscountFactor = builder.comment("How much cheaper a seon wisp is to maintain.")
                    .defineInRange("seonDiscountFactor", DEFAULT_SEON_DISCOUNT_FACTOR,
                            MIN_SEON_DISCOUNT_FACTOR, MAX_SEON_DISCOUNT_FACTOR);
            storingPlayerCostScaleFactor = builder.comment("Cost scale factor for wisps that store a player.")
                    .defineInRange("storingPlayerCostScaleFactor", DEFAULT_STORING_PLAYER_COST_SCALE_FACTOR,
                            MIN_STORING_PLAYER_COST_SCALE_FACTOR, MAX_STORING_PLAYER_COST_SCALE_FACTOR);
            mediaFlowRateOverLink = builder.comment("Fraction of media that flows over a link each tick.")
                    .defineInRange("mediaFlowRateOverLink", DEFAULT_MEDIA_FLOW_RATE_OVER_LINK,
                            MIN_MEDIA_FLOW_RATE_OVER_LINK, MAX_MEDIA_FLOW_RATE_OVER_LINK);
            builder.pop();

            builder.push("linkSpells");
            linkCost = cost(builder, "linkCost", DEFAULT_LINK_COST);
            sendIotaCost = cost(builder, "sendIotaCost", DEFAULT_SEND_IOTA_COST);
            unlinkCost = cost(builder, "unlinkCost", DEFAULT_UNLINK_COST);
            builder.pop();

            builder.push("gateSpells");
            makeGateCost = cost(builder, "makeGateCost", DEFAULT_MAKE_GATE_COST);
            markGateCost = cost(builder, "markGateCost", DEFAULT_MARK_GATE_COST);
            closeGateCost = cost(builder, "closeGateCost", DEFAULT_CLOSE_GATE_COST);
            closeGateDistanceCostFactor = cost(builder, "closeGateDistanceCostFactor", DEFAULT_CLOSE_GATE_DISTANCE_COST_SCALE_FACTOR);
            maxGateOffset = builder.defineInRange("maxGateOffset", DEFAULT_MAX_GATE_OFFSET,
                    MIN_MAX_GATE_OFFSET, MAX_MAX_GATE_OFFSET);
            builder.pop();

            builder.push("itemSpells");
            bindStorageCost = cost(builder, "bindStorageCost", DEFAULT_BIND_STORAGE_COST);
            bindTemporaryStorageCost = cost(builder, "bindTemporaryStorageCost", DEFAULT_BIND_TEMPORARY_STORAGE_COST);
            makeItemCost = cost(builder, "makeItemCost", DEFAULT_MAKE_ITEM_COST);
            returnItemCost = cost(builder, "returnItemCost", DEFAULT_RETURN_ITEM_COST);
            craftItemCost = cost(builder, "craftItemCost", DEFAULT_CRAFT_ITEM_COST);
            tradeItemCost = cost(builder, "tradeItemCost", DEFAULT_TRADE_ITEM_COST);
            useItemOnCost = cost(builder, "useItemOnCost", DEFAULT_USE_ITEM_ON_COST);
            maxItemsReturned = builder.comment("The maximum number of items that can be returned from mediafied storage at once.")
                    .defineInRange("maxItemsReturned", DEFAULT_MAX_ITEMS_RETURNED,
                            MIN_MAX_ITEMS_RETURNED, MAX_MAX_ITEMS_RETURNED);
            maxRecordsInMediafiedStorage = builder.comment("The maximum number of distinct records in a mediafied storage.")
                    .defineInRange("maxRecordsInMediafiedStorage", DEFAULT_MAX_RECORDS_IN_MEDIAFIED_STORAGE,
                            MIN_MAX_RECORDS_IN_MEDIAFIED_STORAGE, MAX_MAX_RECORDS_IN_MEDIAFIED_STORAGE);
            builder.pop();

            builder.push("greatSpells");
            consumeWispOwnCost = cost(builder, "consumeWispOwnCost", DEFAULT_CONSUME_WISP_OWN_COST);
            consumeWispOthersCostPerMedia = builder.defineInRange("consumeWispOthersCostPerMedia",
                    DEFAULT_CONSUME_WISP_OTHERS_COST_PER_MEDIA,
                    MIN_CONSUME_WISP_OTHERS_COST_PER_MEDIA, MAX_CONSUME_WISP_OTHERS_COST_PER_MEDIA);
            seonWispSetCost = cost(builder, "seonWispSetCost", DEFAULT_SEON_WISP_SET_COST);
            tickConstantCost = cost(builder, "tickConstantCost", DEFAULT_TICK_CONSTANT_COST);
            tickCostPerTicked = cost(builder, "tickCostPerTicked", DEFAULT_TICK_COST_PER_TICKED);
            tickRandomTickIProb = builder.comment("Inverse probability of the tick spell random ticking a block.")
                    .defineInRange("tickRandomTickIProb", DEFAULT_TICK_RANDOM_TICK_I_PROB,
                            MIN_TICK_RANDOM_TICK_I_PROB, MAX_TICK_RANDOM_TICK_I_PROB);
            accelerateDenyList = builder.comment("Blocks that the accelerate spell may not tick, as resource locations.")
                    .defineListAllowEmpty("accelerateDenyList", HexalConfig.ServerConfigAccess.Companion.getDEFAULT_ACCELERATE_DENY_LIST(),
                            () -> "minecraft:air", Server::isValidReslocArg);
            builder.pop();
        }

        private static ModConfigSpec.DoubleValue cost(ModConfigSpec.Builder builder, String name, double def) {
            return builder.defineInRange(name, def, DEF_MIN_COST, DEF_MAX_COST);
        }

        private static boolean isValidReslocArg(Object o) {
            return o instanceof String s && ResourceLocation.tryParse(s) != null;
        }

        private static long dust(double amount) {
            return (long) (amount * MediaConstants.DUST_UNIT);
        }

        //region getters
        @Override
        public boolean getGenerateSlipwayGeodes() {
            return generateSlipwayGeodes.get();
        }

        @Override
        public long getFallingBlockCost() {
            return dust(fallingBlockCost.get());
        }

        @Override
        public long getFreezeCost() {
            return dust(freezeCost.get());
        }

        @Override
        public long getParticlesCost() {
            return dust(particlesCost.get());
        }

        @Override
        public long getPlaceTypeCost() {
            return dust(placeTypeCost.get());
        }

        @Override
        public long getSmeltCost() {
            return dust(smeltCost.get());
        }

        @Override
        public double getPhaseBlockCostFactor() {
            return phaseBlockCostFactor.get() * MediaConstants.DUST_UNIT;
        }

        @Override
        public long getMoveSpeedSetCost() {
            return dust(moveSpeedSetCost.get());
        }

        @Override
        public long getSummonTickingWispCost() {
            return dust(summonTickingWispCost.get());
        }

        @Override
        public long getSummonProjectileWispCost() {
            return dust(summonProjectileWispCost.get());
        }

        @Override
        public long getSummonProjectileWispMinCost() {
            return dust(summonProjectileWispMinCost.get());
        }

        @Override
        public long getTickingWispUpkeepPerTick() {
            return dust(tickingWispUpkeepPerTick.get());
        }

        @Override
        public long getProjectileWispUpkeepPerTick() {
            return dust(projectileWispUpkeepPerTick.get());
        }

        @Override
        public double getUntriggeredWispUpkeepDiscount() {
            return untriggeredWispUpkeepDiscount.get();
        }

        @Override
        public long getLinkUpkeepPerTick() {
            return dust(linkUpkeepPerTick.get());
        }

        @Override
        public double getSeonDiscountFactor() {
            return seonDiscountFactor.get();
        }

        @Override
        public double getStoringPlayerCostScaleFactor() {
            return storingPlayerCostScaleFactor.get();
        }

        @Override
        public double getMediaFlowRateOverLink() {
            return mediaFlowRateOverLink.get();
        }

        @Override
        public long getLinkCost() {
            return dust(linkCost.get());
        }

        @Override
        public long getSendIotaCost() {
            return dust(sendIotaCost.get());
        }

        @Override
        public long getUnlinkCost() {
            return dust(unlinkCost.get());
        }

        @Override
        public long getMakeGateCost() {
            return dust(makeGateCost.get());
        }

        @Override
        public long getMarkGateCost() {
            return dust(markGateCost.get());
        }

        @Override
        public long getCloseGateCost() {
            return dust(closeGateCost.get());
        }

        @Override
        public long getCloseGateDistanceCostFactor() {
            return dust(closeGateDistanceCostFactor.get());
        }

        @Override
        public double getMaxGateOffset() {
            return maxGateOffset.get();
        }

        @Override
        public long getBindStorageCost() {
            return dust(bindStorageCost.get());
        }

        @Override
        public long getBindTemporaryStorageCost() {
            return dust(bindTemporaryStorageCost.get());
        }

        @Override
        public long getMakeItemCost() {
            return dust(makeItemCost.get());
        }

        @Override
        public long getReturnItemCost() {
            return dust(returnItemCost.get());
        }

        @Override
        public long getCraftItemCost() {
            return dust(craftItemCost.get());
        }

        @Override
        public long getTradeItemCost() {
            return dust(tradeItemCost.get());
        }

        @Override
        public long getUseItemOnCost() {
            return dust(useItemOnCost.get());
        }

        @Override
        public int getMaxItemsReturned() {
            return maxItemsReturned.get();
        }

        @Override
        public int getMaxRecordsInMediafiedStorage() {
            return maxRecordsInMediafiedStorage.get();
        }

        @Override
        public long getConsumeWispOwnCost() {
            return dust(consumeWispOwnCost.get());
        }

        @Override
        public double getConsumeWispOthersCostPerMedia() {
            return consumeWispOthersCostPerMedia.get();
        }

        @Override
        public long getSeonWispSetCost() {
            return dust(seonWispSetCost.get());
        }

        @Override
        public long getTickConstantCost() {
            return dust(tickConstantCost.get());
        }

        @Override
        public long getTickCostPerTicked() {
            return dust(tickCostPerTicked.get());
        }

        @Override
        public int getTickRandomTickIProb() {
            return tickRandomTickIProb.get();
        }

        @Override
        public boolean isAccelerateAllowed(@NotNull ResourceLocation blockId) {
            return noneMatch(new java.util.ArrayList<>(accelerateDenyList.get()), blockId);
        }
        //endregion
    }
}
