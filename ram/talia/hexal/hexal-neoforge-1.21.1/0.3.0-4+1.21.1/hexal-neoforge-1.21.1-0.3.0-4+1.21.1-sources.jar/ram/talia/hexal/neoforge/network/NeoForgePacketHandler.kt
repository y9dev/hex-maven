package ram.talia.hexal.neoforge.network

import net.neoforged.bus.api.IEventBus
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent
import net.neoforged.neoforge.network.handling.IPayloadContext
import ram.talia.hexal.common.network.MsgAddRenderLinkS2C
import ram.talia.hexal.common.network.MsgParticleLinesAck
import ram.talia.hexal.common.network.MsgRemoveEverbookS2C
import ram.talia.hexal.common.network.MsgRemoveRenderLinkS2C
import ram.talia.hexal.common.network.MsgSendEverbookC2S
import ram.talia.hexal.common.network.MsgSetEverbookS2C
import ram.talia.hexal.common.network.MsgSetRenderLinksAck
import ram.talia.hexal.common.network.MsgSingleParticleAck
import ram.talia.hexal.common.network.MsgToggleMacroS2C
import ram.talia.hexal.common.network.MsgWispCastSoundS2C

object NeoForgePacketHandler {
    private const val PROTOCOL_VERSION = "1"

    /**
     * Registers the payload codecs and handlers of all of Hexal's packets. Client-bound handlers are plain
     * references to common code; NeoForge only invokes them on the physical client.
     */
    @JvmStatic
    fun init(modBus: IEventBus) {
        modBus.addListener { event: RegisterPayloadHandlersEvent ->
            val registrar = event.registrar(PROTOCOL_VERSION)

            // Client -> server
            registrar.playToServer(MsgSendEverbookC2S.TYPE, MsgSendEverbookC2S.STREAM_CODEC) { msg, ctx: IPayloadContext ->
                msg.handle(ctx.player().server!!, ctx.player() as net.minecraft.server.level.ServerPlayer)
            }

            // Server -> client
            registrar.playToClient(MsgSetEverbookS2C.TYPE, MsgSetEverbookS2C.STREAM_CODEC) { msg, _ -> MsgSetEverbookS2C.handle(msg) }
            registrar.playToClient(MsgRemoveEverbookS2C.TYPE, MsgRemoveEverbookS2C.STREAM_CODEC) { msg, _ -> MsgRemoveEverbookS2C.handle(msg) }
            registrar.playToClient(MsgToggleMacroS2C.TYPE, MsgToggleMacroS2C.STREAM_CODEC) { msg, _ -> MsgToggleMacroS2C.handle(msg) }
            registrar.playToClient(MsgWispCastSoundS2C.TYPE, MsgWispCastSoundS2C.STREAM_CODEC) { msg, _ -> MsgWispCastSoundS2C.handle(msg) }
            registrar.playToClient(MsgAddRenderLinkS2C.TYPE, MsgAddRenderLinkS2C.STREAM_CODEC) { msg, _ -> MsgAddRenderLinkS2C.handle(msg) }
            registrar.playToClient(MsgRemoveRenderLinkS2C.TYPE, MsgRemoveRenderLinkS2C.STREAM_CODEC) { msg, _ -> MsgRemoveRenderLinkS2C.handle(msg) }
            registrar.playToClient(MsgSetRenderLinksAck.TYPE, MsgSetRenderLinksAck.STREAM_CODEC) { msg, _ -> MsgSetRenderLinksAck.handle(msg) }
            registrar.playToClient(MsgSingleParticleAck.TYPE, MsgSingleParticleAck.STREAM_CODEC) { msg, _ -> MsgSingleParticleAck.handle(msg) }
            registrar.playToClient(MsgParticleLinesAck.TYPE, MsgParticleLinesAck.STREAM_CODEC) { msg, _ -> MsgParticleLinesAck.handle(msg) }
        }
    }
}
