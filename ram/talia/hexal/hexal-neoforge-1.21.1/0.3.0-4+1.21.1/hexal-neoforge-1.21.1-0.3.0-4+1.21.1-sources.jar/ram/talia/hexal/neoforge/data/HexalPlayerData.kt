package ram.talia.hexal.neoforge.data

import at.petrak.hexcasting.api.casting.iota.Iota
import at.petrak.hexcasting.api.casting.iota.NullIota
import at.petrak.hexcasting.api.casting.math.HexPattern
import at.petrak.hexcasting.api.utils.hasCompound
import at.petrak.hexcasting.api.utils.putCompound
import net.minecraft.nbt.CompoundTag
import net.minecraft.server.level.ServerLevel
import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.entity.player.Player
import ram.talia.hexal.api.casting.wisp.WispCastingManager
import ram.talia.hexal.api.everbook.Everbook
import ram.talia.hexal.api.linkable.PlayerLinkstore
import ram.talia.hexal.api.nbt.toNbtTag
import ram.talia.hexal.common.entities.BaseCastingWisp
import ram.talia.hexal.common.network.MsgRemoveEverbookS2C
import ram.talia.hexal.common.network.MsgSendEverbookC2S
import ram.talia.hexal.common.network.MsgSetEverbookS2C
import ram.talia.hexal.xplat.IClientXplatAbstractions
import ram.talia.hexal.xplat.IXplatAbstractions
import java.util.UUID

/*
 * Plain holder objects stored in NeoForge data attachments. They mirror the Cardinal Components used on Fabric
 * (`ram.talia.hexal.fabric.cc`), so the xplat layer can hide the difference.
 */

/** The mote storage a player has bound with the `bind_storage` spell. */
class BoundStorageData {
    var storage: UUID? = null

    fun read(tag: CompoundTag) {
        if (tag.contains(TAG_BOUND_STORAGE))
            storage = tag.getUUID(TAG_BOUND_STORAGE)
    }

    fun write(): CompoundTag? {
        val id = storage ?: return null
        return CompoundTag().also { it.putUUID(TAG_BOUND_STORAGE, id) }
    }

    companion object {
        const val TAG_BOUND_STORAGE = "hexal:bound_storage"
    }
}

/** The link store of a player (server side) plus the link render centre (client side). */
class PlayerLinkstoreData(player: Player) {
    val linkstore: PlayerLinkstore? = (player as? ServerPlayer)?.let { PlayerLinkstore(it) }
    val renderCentre: PlayerLinkstore.RenderCentre? = if (player.level().isClientSide) PlayerLinkstore.RenderCentre(player) else null

    fun tick() {
        linkstore?.checkLinks()
        renderCentre?.renderLinks()
    }

    fun read(tag: CompoundTag) {
        linkstore?.loadAdditionalData(tag)
    }

    fun write(): CompoundTag? {
        val ls = linkstore ?: return null
        return CompoundTag().also { ls.saveAdditionalData(it) }
    }
}

/** The wisp cast queue and seon of a player. */
class WispCastingManagerData(private val player: Player) {
    val manager: WispCastingManager? = (player as? ServerPlayer)?.let { WispCastingManager(it) }
    var seonUUID: UUID? = null

    var seon: BaseCastingWisp? = null
        get() {
            if (seonUUID == null)
                return null
            if (field?.isRemoved != false)
                return (player as? ServerPlayer)?.let { it.serverLevel().getEntity(seonUUID!!) as? BaseCastingWisp }
            return field
        }
        set(value) {
            seonUUID = value?.uuid
            field = value
        }

    fun tick() {
        manager?.executeCasts()
    }

    fun read(tag: CompoundTag) {
        if (player is ServerPlayer) {
            if (tag.hasCompound(TAG_MANAGER))
                manager?.readFromNbt(tag.getCompound(TAG_MANAGER), player.level() as ServerLevel)
            if (tag.hasUUID(TAG_SEON))
                seonUUID = tag.getUUID(TAG_SEON)
        }
    }

    fun write(): CompoundTag? {
        if (manager == null && seonUUID == null) return null
        val tag = CompoundTag()
        if (manager != null) {
            val manTag = CompoundTag()
            manager.writeToNbt(manTag)
            tag.putCompound(TAG_MANAGER, manTag)
        }
        seonUUID?.let { tag.putUUID(TAG_SEON, it) }
        return tag
    }

    companion object {
        const val TAG_MANAGER = "hexal:manager"
        const val TAG_SEON = "hexal:seon"
    }
}

/**
 * The Everbook of a player. Like on Fabric it is not persisted with the player: the client owns the book on disk
 * and uploads it to the server once it joins.
 */
class EverbookData(private val player: Player) {
    var everbook: Everbook? = null
        set(value) {
            if (field == null)
                field = value
        }

    var syncedLocalToServer = false

    /** Client tick of the local player: loads the book from disk and uploads it to the server once. */
    fun clientTick() {
        if (syncedLocalToServer)
            return
        syncedLocalToServer = true

        everbook = Everbook.fromDisk(player.uuid)

        IClientXplatAbstractions.INSTANCE.sendPacketToServer(MsgSendEverbookC2S(everbook!!))
    }

    fun getIota(key: HexPattern, level: ServerLevel): Iota = everbook?.getIota(key, level) ?: NullIota()

    fun setIota(key: HexPattern, iota: Iota) {
        if (player.level().isClientSide) throw Exception("EverbookData.setIota can only be called on the server")

        if (everbook != null) {
            everbook!!.setIota(key, iota)
            IXplatAbstractions.INSTANCE.sendPacketToPlayer(player as ServerPlayer, MsgSetEverbookS2C(key, iota.toNbtTag()))
        }
    }

    fun setFullEverbook(everbook: Everbook) {
        if (player.level().isClientSide) throw Exception("EverbookData.setFullEverbook can only be called on the server")
        this.everbook = everbook
    }

    fun removeIota(key: HexPattern) {
        if (player.level().isClientSide) throw Exception("EverbookData.removeIota can only be called on the server")
        everbook?.removeIota(key)

        IXplatAbstractions.INSTANCE.sendPacketToPlayer(player as ServerPlayer, MsgRemoveEverbookS2C(key))
    }

    fun getMacro(key: HexPattern, level: ServerLevel) = everbook?.getMacro(key, level)

    fun toggleMacro(key: HexPattern) = everbook?.toggleMacro(key)

    fun isMacro(key: HexPattern) = everbook?.isMacro(key)

    fun getClientIota(key: HexPattern): CompoundTag? = everbook?.getClientIota(key)
    fun setClientIota(key: HexPattern, iota: CompoundTag) = everbook!!.setIota(key, iota)
    fun removeClientIota(key: HexPattern) = everbook!!.removeIota(key)

    fun getClientPattern(index: Int) = everbook?.getKey(index)

    fun saveToDisk() {
        everbook?.saveToDisk()
    }
}
