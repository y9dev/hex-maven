package ram.talia.hexal.neoforge.xplat;

import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.common.msgs.IMessage;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.loading.FMLLoader;
import net.neoforged.neoforge.common.CommonHooks;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.util.FakePlayerFactory;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import ram.talia.hexal.api.casting.wisp.WispCastingManager;
import ram.talia.hexal.api.everbook.Everbook;
import ram.talia.hexal.api.linkable.ILinkable;
import ram.talia.hexal.api.linkable.PlayerLinkstore;
import ram.talia.hexal.common.entities.BaseCastingWisp;
import ram.talia.hexal.common.items.ItemRelay;
import ram.talia.hexal.common.network.MsgAddRenderLinkS2C;
import ram.talia.hexal.common.network.MsgRemoveRenderLinkS2C;
import ram.talia.hexal.common.network.MsgSetRenderLinksAck;
import ram.talia.hexal.common.network.MsgToggleMacroS2C;
import ram.talia.hexal.neoforge.client.items.ItemRelayRenderer;
import ram.talia.hexal.neoforge.data.HexalAttachments;
import ram.talia.hexal.xplat.IXplatAbstractions;
import software.bernie.geckolib.animatable.client.GeoRenderProvider;

import java.util.List;
import java.util.UUID;

import static at.petrak.hexcasting.xplat.IXplatAbstractions.HEXCASTING;

public class NeoForgeXplatImpl implements IXplatAbstractions {
    @Override
    public boolean isPhysicalClient() {
        return FMLLoader.getDist() == Dist.CLIENT;
    }

    private static CustomPacketPayload payload(IMessage message) {
        return (CustomPacketPayload) message;
    }

    @Override
    public void sendPacketToPlayer(ServerPlayer target, IMessage packet) {
        PacketDistributor.sendToPlayer(target, payload(packet));
    }

    @Override
    public void sendPacketNear(Vec3 pos, double radius, ServerLevel dimension, IMessage packet) {
        PacketDistributor.sendToPlayersNear(dimension, null, pos.x, pos.y, pos.z, radius, payload(packet));
    }

    @Override
    public void sendPacketTracking(Entity entity, IMessage packet) {
        PacketDistributor.sendToPlayersTrackingEntity(entity, payload(packet));
    }

    @Override
    public void sendPacketTracking(BlockEntity blockEntity, IMessage packet) {
        if (blockEntity.getLevel() instanceof ServerLevel level) {
            sendPacketTracking(blockEntity.getBlockPos(), level, packet);
        }
    }

    @Override
    public void sendPacketTracking(BlockPos pos, ServerLevel dimension, IMessage packet) {
        sendPacketTracking(new ChunkPos(pos), dimension, packet);
    }

    @Override
    public void sendPacketTracking(ChunkPos pos, ServerLevel dimension, IMessage packet) {
        PacketDistributor.sendToPlayersTrackingChunk(dimension, pos, payload(packet));
    }

    @Override
    public Packet<?> toVanillaClientboundPacket(IMessage message) {
        return payload(message).toVanillaClientbound();
    }

    @Override
    public boolean isInteractingAllowed(Level level, BlockPos pos, Direction direction, InteractionHand hand, Player player) {
        var evt = CommonHooks.onRightClickBlock(player, hand, pos,
                new BlockHitResult(Vec3.atCenterOf(pos), direction, pos, true));
        return !evt.isCanceled();
    }

    @Override
    public WispCastingManager getWispCastingManager(ServerPlayer caster) {
        return caster.getData(HexalAttachments.WISP_CASTING_MANAGER).getManager();
    }

    @Override
    public void setSeon(ServerPlayer caster, @Nullable BaseCastingWisp wisp) {
        var data = caster.getData(HexalAttachments.WISP_CASTING_MANAGER);
        BaseCastingWisp old = data.getSeon();
        if (old != null)
            old.setSeon(false);
        if (wisp != null)
            wisp.setSeon(true);
        data.setSeon(wisp);
    }

    @Override
    public @Nullable BaseCastingWisp getSeon(ServerPlayer caster) {
        return caster.getData(HexalAttachments.WISP_CASTING_MANAGER).getSeon();
    }

    @Override
    public PlayerLinkstore getLinkstore(ServerPlayer player) {
        return player.getData(HexalAttachments.PLAYER_LINKSTORE).getLinkstore();
    }

    @Override
    public PlayerLinkstore.RenderCentre getPlayerRenderCentre(Player player) {
        return player.getData(HexalAttachments.PLAYER_LINKSTORE).getRenderCentre();
    }

    @Override
    public void syncAddRenderLink(ILinkable sourceLink, ILinkable sinkLink, ServerLevel level) {
        sendPacketTracking(BlockPos.containing(sourceLink.getPosition()), level, new MsgAddRenderLinkS2C(sourceLink, sinkLink));
    }

    @Override
    public void syncRemoveRenderLink(ILinkable sourceLink, ILinkable sinkLink, ServerLevel level) {
        sendPacketTracking(BlockPos.containing(sourceLink.getPosition()), level, new MsgRemoveRenderLinkS2C(sourceLink, sinkLink));
    }

    @Override
    public void syncSetRenderLinks(ILinkable sourceLink, List<ILinkable> sinks, ServerLevel level) {
        sendPacketTracking(BlockPos.containing(sourceLink.getPosition()), level, new MsgSetRenderLinksAck(sourceLink, sinks));
    }

    //region Transmitting
    @Override
    public ILinkable getPlayerTransmittingTo(ServerPlayer player) {
        return player.getData(HexalAttachments.PLAYER_LINKSTORE).getLinkstore().getTransmittingTo();
    }

    @Override
    public void setPlayerTransmittingTo(ServerPlayer player, int to) {
        player.getData(HexalAttachments.PLAYER_LINKSTORE).getLinkstore().setTransmittingTo(to);
    }

    @Override
    public void resetPlayerTransmittingTo(ServerPlayer player) {
        player.getData(HexalAttachments.PLAYER_LINKSTORE).getLinkstore().resetTransmittingTo();
    }
    //endregion

    //region Everbook
    @Override
    public Iota getEverbookIota(ServerPlayer player, HexPattern key) {
        return player.getData(HexalAttachments.EVERBOOK).getIota(key, player.serverLevel());
    }

    @Override
    public void setEverbookIota(ServerPlayer player, HexPattern key, Iota iota) {
        player.getData(HexalAttachments.EVERBOOK).setIota(key, iota);
    }

    @Override
    public void removeEverbookIota(ServerPlayer player, HexPattern key) {
        player.getData(HexalAttachments.EVERBOOK).removeIota(key);
    }

    @Override
    public void setFullEverbook(ServerPlayer player, Everbook everbook) {
        player.getData(HexalAttachments.EVERBOOK).setFullEverbook(everbook);
    }

    @Override
    public List<Iota> getEverbookMacro(ServerPlayer player, HexPattern key) {
        return player.getData(HexalAttachments.EVERBOOK).getMacro(key, player.serverLevel());
    }

    @Override
    public void toggleEverbookMacro(ServerPlayer player, HexPattern key) {
        player.getData(HexalAttachments.EVERBOOK).toggleMacro(key);
        IXplatAbstractions.INSTANCE.sendPacketToPlayer(player, new MsgToggleMacroS2C(key));
    }

    @Override
    public @Nullable UUID getBoundStorage(ServerPlayer player) {
        return player.getData(HexalAttachments.BOUND_STORAGE).getStorage();
    }

    @Override
    public void setBoundStorage(ServerPlayer player, @Nullable UUID storage) {
        player.getData(HexalAttachments.BOUND_STORAGE).setStorage(storage);
    }
    //endregion

    @Override
    public @NotNull ItemRelay getItemRelay(Item.Properties properties) {
        return new NeoForgeItemRelay(properties);
    }

    @Override
    public @NotNull Object getItemRelayRenderProvider() {
        return new GeoRenderProvider() {
            private ItemRelayRenderer renderer;

            @Override
            public BlockEntityWithoutLevelRenderer getGeoItemRenderer() {
                if (this.renderer == null)
                    this.renderer = new ItemRelayRenderer();

                return this.renderer;
            }
        };
    }

    @Override
    public ServerPlayer getFakePlayer(ServerLevel level, UUID uuid) {
        return getFakePlayer(level, new GameProfile(uuid, "[Hexal]"));
    }

    @Override
    public ServerPlayer getFakePlayer(ServerLevel level, GameProfile profile) {
        return FakePlayerFactory.get(level, profile);
    }

    @Override
    public boolean isBreakingAllowed(ServerLevel level, BlockPos pos, BlockState state, @Nullable Player player) {
        if (player == null)
            player = FakePlayerFactory.get(level, HEXCASTING);
        return !NeoForge.EVENT_BUS.post(new BlockEvent.BreakEvent(level, pos, state, player)).isCanceled();
    }

    @Override
    public boolean isPlacingAllowed(ServerLevel level, BlockPos pos, ItemStack stack, @Nullable Player player) {
        if (player == null)
            player = FakePlayerFactory.get(level, HEXCASTING);
        ItemStack cached = player.getMainHandItem();
        player.setItemInHand(InteractionHand.MAIN_HAND, stack.copy());
        var evt = CommonHooks.onRightClickBlock(player, InteractionHand.MAIN_HAND, pos,
                new BlockHitResult(Vec3.atCenterOf(pos), Direction.DOWN, pos, true));
        player.setItemInHand(InteractionHand.MAIN_HAND, cached);
        return !evt.isCanceled();
    }
}
