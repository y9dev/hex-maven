package ram.talia.hexal.neoforge.xplat;

import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.common.msgs.IMessage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.client.renderer.item.ItemPropertyFunction;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.network.PacketDistributor;
import ram.talia.hexal.neoforge.data.EverbookData;
import ram.talia.hexal.neoforge.data.HexalAttachments;
import ram.talia.hexal.xplat.IClientXplatAbstractions;

import java.util.function.Function;

public class NeoForgeClientXplatImpl implements IClientXplatAbstractions {
    private static EverbookData everbook() {
        assert Minecraft.getInstance().player != null;
        return Minecraft.getInstance().player.getData(HexalAttachments.EVERBOOK);
    }

    @Override
    public void sendPacketToServer(IMessage packet) {
        PacketDistributor.sendToServer((CustomPacketPayload) packet);
    }

    @Override
    public void initPlatformSpecific() {
        // NO-OP
    }

    @Override
    public <T extends Entity> void registerEntityRenderer(EntityType<? extends T> type, EntityRendererProvider<T> renderer) {
        EntityRenderers.register(type, renderer);
    }

    @Override
    public <T extends ParticleOptions> void registerParticleType(ParticleType<T> type,
                                                                 Function<SpriteSet, ParticleProvider<T>> factory) {
        // Hexal registers no particles of its own; NeoForge would need RegisterParticleProvidersEvent.
        throw new UnsupportedOperationException("Hexal does not register particle types");
    }

    @Override
    public void registerItemProperty(Item item, ResourceLocation id, ItemPropertyFunction func) {
        ItemProperties.register(item, id, func);
    }

    @Override
    public CompoundTag getClientEverbookIota(HexPattern key) {
        return everbook().getClientIota(key);
    }

    @Override
    public void setClientEverbookIota(HexPattern key, CompoundTag iota) {
        everbook().setClientIota(key, iota);
    }

    @Override
    public void removeClientEverbookIota(HexPattern key) {
        everbook().removeClientIota(key);
    }

    @Override
    public HexPattern getClientEverbookPattern(int index) {
        return everbook().getClientPattern(index);
    }

    @Override
    public void toggleClientEverbookMacro(HexPattern key) {
        everbook().toggleMacro(key);
    }

    @Override
    public boolean isClientEverbookMacro(HexPattern key) {
        return Boolean.TRUE.equals(everbook().isMacro(key));
    }

    @Override
    public void setFilterSave(AbstractTexture texture, boolean filter, boolean mipmap) {
        texture.setBlurMipmap(filter, mipmap);
    }

    @Override
    public void restoreLastFilter(AbstractTexture texture) {
        texture.restoreLastBlurMipmap();
    }
}
