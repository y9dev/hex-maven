package ram.talia.hexal.neoforge.client.items

import ram.talia.hexal.common.items.ItemRelay
import software.bernie.geckolib.renderer.GeoItemRenderer

class ItemRelayRenderer : GeoItemRenderer<ItemRelay>(ItemRelayModel())