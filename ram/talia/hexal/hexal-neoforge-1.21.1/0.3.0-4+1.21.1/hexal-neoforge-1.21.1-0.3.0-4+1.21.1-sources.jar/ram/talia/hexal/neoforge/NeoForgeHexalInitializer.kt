package ram.talia.hexal.neoforge

import at.petrak.hexcasting.common.lib.HexCreativeTabs
import at.petrak.hexcasting.common.lib.hex.HexActions
import at.petrak.hexcasting.common.lib.hex.HexIotaTypes
import net.minecraft.core.Registry
import net.minecraft.core.registries.BuiltInRegistries
import net.minecraft.resources.ResourceLocation
import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.level.saveddata.SavedData
import net.neoforged.api.distmarker.Dist
import net.neoforged.bus.api.IEventBus
import net.neoforged.fml.ModContainer
import net.neoforged.fml.common.Mod
import net.neoforged.fml.config.ModConfig
import net.neoforged.fml.loading.FMLEnvironment
import net.neoforged.neoforge.common.ModConfigSpec
import net.neoforged.neoforge.common.NeoForge
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent
import net.neoforged.neoforge.event.server.ServerStartedEvent
import net.neoforged.neoforge.event.server.ServerStoppingEvent
import net.neoforged.neoforge.event.tick.PlayerTickEvent
import net.neoforged.neoforge.registries.RegisterEvent
import ram.talia.hexal.api.HexalAPI
import ram.talia.hexal.api.config.HexalConfig
import ram.talia.hexal.api.gates.GateManager
import ram.talia.hexal.api.gates.GateSavedData
import ram.talia.hexal.common.lib.HexalBlockEntities
import ram.talia.hexal.common.lib.HexalBlocks
import ram.talia.hexal.common.lib.HexalEntities
import ram.talia.hexal.common.lib.HexalFeatures
import ram.talia.hexal.common.lib.HexalItems
import ram.talia.hexal.common.lib.HexalSounds
import ram.talia.hexal.common.lib.hex.HexalActions
import ram.talia.hexal.common.lib.hex.HexalArithmetics
import ram.talia.hexal.common.lib.hex.HexalImageComponents
import ram.talia.hexal.common.lib.hex.HexalIotaTypes
import ram.talia.hexal.common.recipe.HexalRecipeSerializers
import ram.talia.hexal.common.recipe.HexalRecipeTypes
import ram.talia.hexal.neoforge.data.HexalAttachments
import ram.talia.hexal.neoforge.network.NeoForgePacketHandler
import java.util.function.BiConsumer
import at.petrak.hexcasting.xplat.IXplatAbstractions as HexXplat

@Mod(HexalAPI.MOD_ID)
class NeoForgeHexalInitializer(modBus: IEventBus, modContainer: ModContainer) {
    init {
        HexalAPI.LOGGER.info("Hello NeoForge World!")

        initConfig(modContainer)
        HexalAttachments.register(modBus)
        NeoForgePacketHandler.init(modBus)
        initRegistries(modBus)
        initListeners(modBus)

        if (FMLEnvironment.dist == Dist.CLIENT) {
            NeoForgeHexalClientInitializer.init(modBus, modContainer)
        }
    }

    private fun initConfig(modContainer: ModContainer) {
        val common = ModConfigSpec.Builder().configure { NeoForgeHexalConfig(it) }
        val client = ModConfigSpec.Builder().configure { NeoForgeHexalConfig.Client(it) }
        val server = ModConfigSpec.Builder().configure { NeoForgeHexalConfig.Server(it) }
        HexalConfig.common = common.left
        HexalConfig.client = client.left
        HexalConfig.server = server.left
        modContainer.registerConfig(ModConfig.Type.COMMON, common.right)
        modContainer.registerConfig(ModConfig.Type.CLIENT, client.right)
        modContainer.registerConfig(ModConfig.Type.SERVER, server.right)
    }

    private fun initRegistries(modBus: IEventBus) {
        bind(modBus, BuiltInRegistries.FEATURE) { HexalFeatures.registerFeatures(it) }

        bind(modBus, BuiltInRegistries.SOUND_EVENT) { HexalSounds.registerSounds(it) }
        bind(modBus, BuiltInRegistries.BLOCK) { HexalBlocks.registerBlocks(it) }
        bind(modBus, BuiltInRegistries.ITEM) { HexalBlocks.registerBlockItems(it) }
        bind(modBus, BuiltInRegistries.ITEM) { HexalItems.registerItems(it) }
        bind(modBus, BuiltInRegistries.BLOCK_ENTITY_TYPE) { HexalBlockEntities.registerBlockEntities(it) }
        bind(modBus, BuiltInRegistries.ENTITY_TYPE) { HexalEntities.registerEntities(it) }

        bind(modBus, BuiltInRegistries.RECIPE_SERIALIZER) { HexalRecipeSerializers.registerSerializers(it) }
        bind(modBus, BuiltInRegistries.RECIPE_TYPE) { HexalRecipeTypes.registerTypes(it) }

        // Hex Casting's own registries. Phase block is Fabric-only (it needs Phantom), so there is no
        // fabricOnlyRegistration() here.
        bind(modBus, HexIotaTypes.REGISTRY) { HexalIotaTypes.registerTypes(it) }
        bind(modBus, HexActions.REGISTRY) { HexalActions.register(it) }
        bind(modBus, HexXplat.INSTANCE.arithmeticRegistry) { HexalArithmetics.register(it) }
        bind(modBus, HexXplat.INSTANCE.imageComponentRegistry) {
            it.accept(HexalImageComponents.USERDATA, HexalAPI.modLoc("userdata"))
        }
    }

    private fun initListeners(modBus: IEventBus) {
        val evBus = NeoForge.EVENT_BUS

        // Hexal has no creative tab of its own; put its items in Hex Casting's.
        modBus.addListener { event: BuildCreativeModeTabContentsEvent ->
            if (event.tabKey == HexCreativeTabs.HEX_KEY) {
                BuiltInRegistries.ITEM.entrySet()
                    .filter { it.key.location().namespace == HexalAPI.MOD_ID }
                    .forEach { event.accept(it.value) }
            }
        }

        evBus.addListener { event: ServerStartedEvent ->
            val savedData = event.server.overworld().dataStorage.computeIfAbsent(GATE_SAVED_DATA_FACTORY, FILE_GATE_MANAGER)
            savedData.setDirty()
        }
        evBus.addListener { event: ServerStoppingEvent ->
            // overworld() is null when the server failed to initialise; without this guard the
            // handler throws an NPE that replaces the original startup error.
            val overworld = event.server.overworld() ?: return@addListener
            val savedData = overworld.dataStorage.computeIfAbsent(GATE_SAVED_DATA_FACTORY, FILE_GATE_MANAGER)
            GateManager.shouldClearOnWrite = true
            savedData.setDirty()
        }

        // Cardinal Components ticked these on Fabric.
        evBus.addListener { event: PlayerTickEvent.Post ->
            val player = event.entity
            if (player is ServerPlayer) {
                player.getData(HexalAttachments.PLAYER_LINKSTORE).tick()
                player.getData(HexalAttachments.WISP_CASTING_MANAGER).tick()
            }
        }
    }

    // https://github.com/VazkiiMods/Botania/blob/1.18.x/Forge/src/main/java/vazkii/botania/forge/ForgeCommonInitializer.java
    private fun <T : Any> bind(modBus: IEventBus, registry: Registry<T>, source: (BiConsumer<T, ResourceLocation>) -> Unit) {
        modBus.addListener { event: RegisterEvent ->
            if (registry.key() == event.registryKey) {
                source(BiConsumer { t, id -> event.register(registry.key(), id) { t } })
            }
        }
    }

    companion object {
        const val FILE_GATE_MANAGER = "hexal_gate_manager"

        @JvmField
        val GATE_SAVED_DATA_FACTORY: SavedData.Factory<GateSavedData> =
            SavedData.Factory(
                { GateSavedData() },
                { tag, _ -> GateSavedData(tag) },
                null
            )
    }
}
