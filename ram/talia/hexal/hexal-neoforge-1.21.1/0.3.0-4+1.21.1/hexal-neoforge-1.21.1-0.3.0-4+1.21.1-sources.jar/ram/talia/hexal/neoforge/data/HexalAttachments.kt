package ram.talia.hexal.neoforge.data

import net.minecraft.core.HolderLookup
import net.minecraft.nbt.CompoundTag
import net.minecraft.world.entity.player.Player
import net.neoforged.bus.api.IEventBus
import net.neoforged.neoforge.attachment.AttachmentType
import net.neoforged.neoforge.attachment.IAttachmentHolder
import net.neoforged.neoforge.attachment.IAttachmentSerializer
import net.neoforged.neoforge.registries.DeferredRegister
import net.neoforged.neoforge.registries.NeoForgeRegistries
import ram.talia.hexal.api.HexalAPI
import java.util.function.Function
import java.util.function.Supplier

/** Player data formerly kept in Cardinal Components components; NeoForge data attachments cover it. */
object HexalAttachments {
    private val ATTACHMENT_TYPES: DeferredRegister<AttachmentType<*>> =
        DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, HexalAPI.MOD_ID)

    private class TagSerializer<T : Any>(
        private val create: (Player) -> T,
        private val readInto: (T, CompoundTag) -> Unit,
        private val writeOut: (T) -> CompoundTag?,
    ) : IAttachmentSerializer<CompoundTag, T> {
        override fun read(holder: IAttachmentHolder, tag: CompoundTag, provider: HolderLookup.Provider): T =
            create(holder as Player).also { readInto(it, tag) }

        override fun write(attachment: T, provider: HolderLookup.Provider): CompoundTag? = writeOut(attachment)
    }

    private fun <T : Any> serialised(
        copyOnDeath: Boolean,
        create: (Player) -> T,
        readInto: (T, CompoundTag) -> Unit,
        writeOut: (T) -> CompoundTag?,
    ): Supplier<AttachmentType<T>> = Supplier {
        val builder = AttachmentType.builder(Function<IAttachmentHolder, T> { holder -> create(holder as Player) })
            .serialize(TagSerializer(create, readInto, writeOut))
        if (copyOnDeath) builder.copyOnDeath()
        builder.build()
    }

    @JvmField
    val BOUND_STORAGE: Supplier<AttachmentType<BoundStorageData>> = ATTACHMENT_TYPES.register("bound_storage",
        serialised(true, { BoundStorageData() }, { d, t -> d.read(t) }, { it.write() }))

    @JvmField
    val WISP_CASTING_MANAGER: Supplier<AttachmentType<WispCastingManagerData>> = ATTACHMENT_TYPES.register("wisp_casting_manager",
        serialised(true, { WispCastingManagerData(it) }, { d, t -> d.read(t) }, { it.write() }))

    /** Not copied on death: the link store is bound to the old player instance. */
    @JvmField
    val PLAYER_LINKSTORE: Supplier<AttachmentType<PlayerLinkstoreData>> = ATTACHMENT_TYPES.register("player_linkstore",
        serialised(false, { PlayerLinkstoreData(it) }, { d, t -> d.read(t) }, { it.write() }))

    /**
     * Not serialised and not copied on death: the client owns the book on disk and re-uploads it whenever its
     * own player entity is replaced (join, respawn), so the server copy is rebuilt from the client.
     */
    @JvmField
    val EVERBOOK: Supplier<AttachmentType<EverbookData>> = ATTACHMENT_TYPES.register("everbook", Supplier {
        AttachmentType.builder(Function<IAttachmentHolder, EverbookData> { holder -> EverbookData(holder as Player) })
            .build()
    })

    @JvmStatic
    fun register(modBus: IEventBus) {
        ATTACHMENT_TYPES.register(modBus)
    }
}
