package ram.talia.hexal.neoforge.xplat

import ram.talia.hexal.common.items.ItemRelay
import ram.talia.hexal.xplat.IXplatAbstractions
import software.bernie.geckolib.animatable.GeoItem
import software.bernie.geckolib.animatable.client.GeoRenderProvider
import java.util.function.Consumer

class NeoForgeItemRelay(properties: Properties) : ItemRelay(properties), GeoItem {
    override fun createGeoRenderer(consumer: Consumer<GeoRenderProvider>) {
        consumer.accept(IXplatAbstractions.INSTANCE.itemRelayRenderProvider as GeoRenderProvider)
    }
}
