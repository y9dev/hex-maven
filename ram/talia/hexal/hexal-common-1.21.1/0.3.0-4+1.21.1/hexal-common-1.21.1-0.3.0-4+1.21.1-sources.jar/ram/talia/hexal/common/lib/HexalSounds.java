package ram.talia.hexal.common.lib;

import at.petrak.hexcasting.common.lib.HexSounds;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.jetbrains.annotations.NotNull;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import java.util.function.Supplier;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2382;
import net.minecraft.class_2405;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_7403;
import net.minecraft.class_7784;

import static ram.talia.hexal.api.HexalAPI.modLoc;

public class HexalSounds {
	public static void registerSounds(BiConsumer<class_3414, class_2960> r) {
		for (var e : SOUNDS.entrySet()) {
			e.getValue().register(r);
		}
	}
	
	private static final Map<class_2960, SoundEntry> SOUNDS = new LinkedHashMap<>();
	
	public static final SoundEntry WISP_CASTING_START = create("wisp_casting_start").subtitle("Wisp starts casting")
					.playExisting(HexSounds.CAST_NORMAL.comp_349(), 0.5f, 1)
					.category(class_3419.field_15248)
					.attenuationDistance(8)
					.build();
	
	public static final SoundEntry WISP_CASTING_CONTINUE = create("wisp_casting_continue").subtitle("Wisp continues casting")
					.category(class_3419.field_15248)
					.volume(0.5f)
					.attenuationDistance(8)
					.build();
	
	
	// Everything below here is from
	// https://github.com/Creators-of-Create/Create/blob/aeee9f8793c660e0a8f619f5bd2f8c52be55e4ce/src/main/java/com/simibubi/create/AllSoundEvents.java#L393
	
	public static SoundEntryBuilder create(String id) {
		return create(modLoc(id));
	}
	
	public static SoundEntryBuilder create(class_2960 id) {
		return new SoundEntryBuilder(id);
	}
	
	public static JsonObject provideLangEntries() {
		JsonObject object = new JsonObject();
		for (SoundEntry entry : SOUNDS.values())
			if (entry.hasSubtitle())
				object.addProperty(entry.getSubtitleKey(), entry.getSubtitle());
		return object;
	}
	
	public static SoundEntryProvider provider(class_7784 output) {
		return new SoundEntryProvider(output);
	}
	
	public record SoundEntryProvider(class_7784 output) implements class_2405 {
		
		@Override
		public CompletableFuture<?> method_10319(@NotNull class_7403 cache) {
			return generate(output.method_45971(), cache);
		}
			
		@Override
		public @NotNull String method_10321 () {
				return "Hexal's Custom Sounds";
			}
			
		public CompletableFuture<?> generate (Path path, class_7403 cache) {
//			Gson GSON = (new GsonBuilder()).setPrettyPrinting()
//																		 .disableHtmlEscaping()
//																		 .create();
			path = path.resolve("assets/hexal");

			JsonObject json = new JsonObject();
			SOUNDS.entrySet()
					.stream()
					.sorted(Map.Entry.comparingByKey())
					.forEach(entry -> entry.getValue().write(json));
			return class_2405.method_10320(cache, json, path.resolve("sounds.json"));
		}
			
	}
	
	public record ConfiguredSoundEvent(Supplier<class_3414> event, float volume, float pitch) {}
	
	public static class SoundEntryBuilder {
		
		protected class_2960 id;
		protected String subtitle = "unregistered";
		protected class_3419 category = class_3419.field_15245;
		protected List<ConfiguredSoundEvent> wrappedEvents;
		protected List<class_2960> variants;
		protected float volume;
		protected float pitch;
		protected int attenuationDistance;
		
		public SoundEntryBuilder (class_2960 id) {
			wrappedEvents = new ArrayList<>();
			variants = new ArrayList<>();
			this.id = id;
		}
		
		public SoundEntryBuilder subtitle (String subtitle) {
			this.subtitle = subtitle;
			return this;
		}
		
		public SoundEntryBuilder volume (float volume) {
			this.volume = volume;
			return this;
		}
		
		public SoundEntryBuilder pitch (float pitch) {
			this.pitch = pitch;
			return this;
		}
		
		public SoundEntryBuilder attenuationDistance (int distance) {
			this.attenuationDistance = distance;
			return this;
		}
		
		public SoundEntryBuilder noSubtitle () {
			this.subtitle = null;
			return this;
		}
		
		public SoundEntryBuilder category (class_3419 category) {
			this.category = category;
			return this;
		}
		
		public SoundEntryBuilder addVariant (String name) {
			return addVariant(modLoc(name));
		}
		
		public SoundEntryBuilder addVariant (class_2960 id) {
			variants.add(id);
			return this;
		}
		
		public SoundEntryBuilder playExisting (Supplier<class_3414> event, float volume, float pitch) {
			wrappedEvents.add(new ConfiguredSoundEvent(event, volume, pitch));
			return this;
		}
		
		public SoundEntryBuilder playExisting (class_3414 event, float volume, float pitch) {
			return playExisting(() -> event, volume, pitch);
		}
		
		public SoundEntryBuilder playExisting (class_3414 event) {
			return playExisting(event, 1, 1);
		}
		
		public SoundEntry build () {
			SoundEntry entry =
							wrappedEvents.isEmpty() ? new CustomSoundEntry(id, variants, subtitle, category, volume, pitch, attenuationDistance)
											: new WrappedSoundEntry(id, subtitle, wrappedEvents, category, attenuationDistance);
			SOUNDS.put(entry.getId(), entry);
			return entry;
		}
		
	}
	
	public static abstract class SoundEntry {
		
		protected class_2960 id;
		protected String subtitle;
		protected class_3419 category;
		protected int attenuationDistance;
		
		public SoundEntry (class_2960 id, String subtitle, class_3419 category, int attenuationDistance) {
			this.id = id;
			this.subtitle = subtitle;
			this.category = category;
			this.attenuationDistance = attenuationDistance;
		}
		
		public abstract void register (BiConsumer<class_3414, class_2960> registry);
		
		public abstract void write (JsonObject json);
		
		public abstract class_3414 getMainEvent ();
		
		public String getSubtitleKey () {
			return id.method_12836() + ".subtitle." + id.method_12832();
		}
		
		public class_2960 getId () {
			return id;
		}
		
		public boolean hasSubtitle () {
			return subtitle != null;
		}
		
		public String getSubtitle () {
			return subtitle;
		}
		
		public class_3419 getCategory () {
			return category;
		}
		
		public void playOnServer (class_1937 world, class_2382 pos) {
			playOnServer(world, pos, 1, 1);
		}
		
		public void playOnServer (class_1937 world, class_2382 pos, float volume, float pitch) {
			play(world, null, pos, volume, pitch);
		}
		
		public void play (class_1937 world, class_1657 entity, class_2382 pos) {
			play(world, entity, pos, 1, 1);
		}
		
		public void playFrom (class_1297 entity) {
			playFrom(entity, 1, 1);
		}
		
		public void playFrom (class_1297 entity, float volume, float pitch) {
			if (!entity.method_5701()) {play(entity.method_37908(), null, entity.method_24515(), volume, pitch);}
		}
		
		public void play (class_1937 world, class_1657 entity, class_2382 pos, float volume, float pitch) {
			play(world, entity, pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, volume, pitch);
		}
		
		public void play (class_1937 world, class_1657 entity, class_243 pos, float volume, float pitch) {
			play(world, entity, pos.method_10216(), pos.method_10214(), pos.method_10215(), volume, pitch);
		}
		
		public abstract void play (class_1937 world, class_1657 entity, double x, double y, double z, float volume, float pitch);
		
		public void playAt (class_1937 world, class_2382 pos, float volume, float pitch, boolean fade) {
			playAt(world, pos.method_10263() + .5, pos.method_10264() + .5, pos.method_10260() + .5, volume, pitch, fade);
		}
		
		public void playAt (class_1937 world, class_243 pos, float volume, float pitch, boolean fade) {
			playAt(world, pos.method_10216(), pos.method_10214(), pos.method_10215(), volume, pitch, fade);
		}
		
		public abstract void playAt (class_1937 world, double x, double y, double z, float volume, float pitch, boolean fade);
		
	}
	
	private static class WrappedSoundEntry extends SoundEntry {
		
		private final List<ConfiguredSoundEvent> wrappedEvents;

		public WrappedSoundEntry (class_2960 id, String subtitle,
															List<ConfiguredSoundEvent> wrappedEvents, class_3419 category, int attenuationDistance) {
			super(id, subtitle, category, attenuationDistance);
			this.wrappedEvents = wrappedEvents;
		}
		
		@Override
		public void register (BiConsumer<class_3414, class_2960> registry) {
			for (int i = 0; i < wrappedEvents.size(); i++) {
				ConfiguredSoundEvent wrapped = wrappedEvents.get(i);
				class_2960 location = getIdOf(i);
				registry.accept(class_3414.method_47908(location), location);
			}
		}
		
		@Override
		public class_3414 getMainEvent () {
			return wrappedEvents.get(0).event().get();
		}
		
		protected class_2960 getIdOf (int i) {
			return class_2960.method_60655(id.method_12836(), i == 0 ? id.method_12832() : id.method_12832() + "_compounded_" + i);
		}
		
		@Override
		public void write (JsonObject json) {
			for (int i = 0; i < wrappedEvents.size(); i++) {
				ConfiguredSoundEvent event = wrappedEvents.get(i);
				JsonObject entry = new JsonObject();
				JsonArray list = new JsonArray();
				JsonObject s = new JsonObject();
				s.addProperty("name", event.event()
																	 .get()
																	 .method_14833()
																	 .toString());
				s.addProperty("type", "event");
				if (attenuationDistance != 0) {s.addProperty("attenuation_distance", attenuationDistance);}
				list.add(s);
				entry.add("sounds", list);
				if (i == 0 && hasSubtitle()) {entry.addProperty("subtitle", getSubtitleKey());}
				json.add(getIdOf(i).method_12832(), entry);
			}
		}
		
		@Override
		public void play (class_1937 world, class_1657 entity, double x, double y, double z, float volume, float pitch) {
			for (ConfiguredSoundEvent event : wrappedEvents) {
				world.method_43128(entity, x, y, z, event.event().get(), category, event.volume() * volume, event.pitch() * pitch);
			}
		}
		
		@Override
		public void playAt (class_1937 world, double x, double y, double z, float volume, float pitch, boolean fade) {
			for (ConfiguredSoundEvent event : wrappedEvents) {
				world.method_8486(x, y, z, event.event().get(), category, event.volume() * volume,
														 event.pitch() * pitch, fade);
			}
		}
	}
	
	private static class CustomSoundEntry extends SoundEntry {
		
		protected List<class_2960> variants;
		protected class_3414 event;
		
		final protected float volume;
		final protected float pitch;
		
		public CustomSoundEntry (class_2960 id, List<class_2960> variants, String subtitle,
														 class_3419 category, float volume, float pitch, int attenuationDistance) {
			super(id, subtitle, category, attenuationDistance);
//			HexalAPI.LOGGER.info("custom sound entry created for id " + id);
			this.event = class_3414.method_47908(id);
			this.variants = variants;
			this.volume = volume;
			this.pitch = pitch;
		}
		
		@Override
		public void register (BiConsumer<class_3414, class_2960> registry) {
			registry.accept(event, id);
		}
		
		@Override
		public class_3414 getMainEvent () {
			return event;
		}
		
		@Override
		public void write (JsonObject json) {
			JsonObject entry = new JsonObject();
			JsonArray list = new JsonArray();
			
			JsonObject s = new JsonObject();
			s.addProperty("name", id.toString());
			s.addProperty("type", "file");
			if (volume != 0) s.addProperty("volume", volume);
			if (pitch != 0) s.addProperty("pitch", pitch);
			if (attenuationDistance != 0) s.addProperty("attenuation_distance", attenuationDistance);
			list.add(s);
			
			for (class_2960 variant : variants) {
				s = new JsonObject();
				s.addProperty("name", variant.toString());
				s.addProperty("type", "file");
				if (volume != 0) s.addProperty("volume", volume);
				if (pitch != 0) s.addProperty("pitch", pitch);
				if (attenuationDistance != 0) s.addProperty("attenuation_distance", attenuationDistance);
				list.add(s);
			}
			
			entry.add("sounds", list);
			if (hasSubtitle()) {entry.addProperty("subtitle", getSubtitleKey());}
			json.add(id.method_12832(), entry);
		}
		
		@Override
		public void play (class_1937 world, class_1657 entity, double x, double y, double z, float volume, float pitch) {
			world.method_43128(entity, x, y, z, event, category, volume, pitch);
		}
		
		@Override
		public void playAt (class_1937 world, double x, double y, double z, float volume, float pitch, boolean fade) {
			world.method_8486(x, y, z, event, category, volume, pitch, fade);
		}
	}
}
