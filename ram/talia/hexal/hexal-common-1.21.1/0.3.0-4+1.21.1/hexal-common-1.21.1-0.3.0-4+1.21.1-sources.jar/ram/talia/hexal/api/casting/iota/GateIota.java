package ram.talia.hexal.api.casting.iota;

import at.petrak.hexcasting.api.casting.eval.CastingEnvironment;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import kotlin.Pair;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_4844;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import ram.talia.hexal.api.gates.GateManager;
import ram.talia.hexal.common.lib.hex.HexalIotaTypes;

import java.util.HashSet;
import java.util.function.Function;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

public class GateIota extends Iota {

    public static String TAG_INDEX = "index";
    public static String TAG_TARGET = "target";
    public static String TAG_ANCHOR = "anchor";
    // legacy 1.20 tag names, kept so old world data can still be read by hand if needed
    public static String TAG_TARGET_TYPE = "target_type";
    public static String TAG_TARGET_X = "target_x";
    public static String TAG_TARGET_Y = "target_y";
    public static String TAG_TARGET_Z = "target_z";
    public static String TAG_TARGET_UUID = "target_uuid";
    public static String TAG_TARGET_NAME = "target_name";

    public static final class_9139<class_2540, class_243> VEC3_STREAM_CODEC = class_9139.method_56436(
            class_9135.field_48553, v -> v.field_1352,
            class_9135.field_48553, v -> v.field_1351,
            class_9135.field_48553, v -> v.field_1350,
            class_243::new);

    public record EntityAnchor(UUID uuid, String name, class_243 offset) {
        public static final Codec<EntityAnchor> CODEC = RecordCodecBuilder.create(inst -> inst.group(
                class_4844.field_25122.fieldOf("uuid").forGetter(EntityAnchor::uuid),
                Codec.STRING.fieldOf("name").forGetter(EntityAnchor::name),
                class_243.field_38277.fieldOf("offset").forGetter(EntityAnchor::offset)
        ).apply(inst, EntityAnchor::new));

        public static final class_9139<class_9129, EntityAnchor> STREAM_CODEC = class_9139.method_56436(
                class_4844.field_48453, EntityAnchor::uuid,
                class_9135.field_48554, EntityAnchor::name,
                VEC3_STREAM_CODEC, EntityAnchor::offset,
                EntityAnchor::new
        );
    }

    private final int index;
    @Nullable
    private final Either<class_243, EntityAnchor> target;

    public GateIota(int index, @Nullable Either<class_243, Pair<class_1297, class_243>> target) {
        this(index, target == null ? null : target.mapRight(pair ->
                new EntityAnchor(pair.getFirst().method_5667(), pair.getFirst().method_5477().getString(), pair.getSecond())), true);
    }

    private GateIota(int index, @Nullable Either<class_243, EntityAnchor> target, boolean raw) {
        super(() -> HexalIotaTypes.GATE);
        this.index = index;
        this.target = target;
    }

    public int getGateIndex() {
        return this.index;
    }

    public @Nullable Either<class_243, EntityAnchor> getTarget() {
        return this.target;
    }

    public @Nullable class_243 getTargetPos(class_3218 level) {
        var target = this.getTarget();

        if (target == null)
            return null;

        return target.map(vec3 -> vec3, entityAnchor -> {
            var entity = level.method_14190(entityAnchor.uuid());

            if (entity == null)
                return null;

            return entity.method_19538().method_1019(entityAnchor.offset());
        });
    }

    public boolean isDrifting() {
        return this.getTarget() == null;
    }

    public boolean isLocationAnchored() {
        var target = this.getTarget();
        return (target != null) && (target.left().isPresent());
    }

    public boolean isEntityAnchored() {
        var target = this.getTarget();
        return (target != null) && (target.right().isPresent());
    }

    public Set<class_1297> getMarked(class_3218 level) {
        var marked = GateManager.allMarked.getOrDefault(this.getGateIndex(), new HashSet<>());

        var out = new HashSet<class_1297>();
        for (var mark : marked) {
            var markEntity = level.method_8469(mark);
            if (markEntity != null)
                out.add(markEntity);
        }
        return out;
    }

    public boolean isMarked(class_1297 entity) {
        var marked = GateManager.allMarked.getOrDefault(this.getGateIndex(), new HashSet<>());
        return marked.contains(entity.method_5667());
    }

    public int getNumMarked() {
        return GateManager.allMarked.getOrDefault(this.getGateIndex(), new HashSet<>()).size();
    }

    public void mark(class_1297 entity) {
        GateManager.mark(this.getGateIndex(), entity);
    }

    public void unmark(@NotNull class_1297 entity) {
        GateManager.unmark(this.getGateIndex(), entity);
    }

    public void clearMarked() {
        GateManager.clearMarked(this.getGateIndex());
    }

    @Override
    protected boolean toleratesOther(Iota that) {
        return typesMatch(this, that) &&
                that instanceof GateIota gthat &&
                this.getGateIndex() == gthat.getGateIndex();
    }

    @Override
    public boolean isTruthy(@Nullable CastingEnvironment env) {
        return true;
    }

    @Override
    public @NotNull class_2561 display() {
        if (this.isDrifting()) {
            return class_2561.method_43469("hexal.spelldata.gate", this.getGateIndex()).method_27692(class_124.field_1076);
        }
        // if we get here then getTarget can't be null.
        //noinspection DataFlowIssue
        return this.getTarget().map(
                vec3 -> class_2561.method_43469("hexal.spelldata.gate", this.getGateIndex()).method_27693(String.format(" (%.2f, %.2f, %.2f)", vec3.field_1352, vec3.field_1351, vec3.field_1350)).method_27692(class_124.field_1076),
                entityAnchor -> {
                    var offsetStr = String.format("%.2f, %.2f, %.2f", entityAnchor.offset().field_1352, entityAnchor.offset().field_1351, entityAnchor.offset().field_1350);
                    var anchorStr = String.format(" (%s, %s)", entityAnchor.name(), offsetStr);

                    return class_2561.method_43469("hexal.spelldata.gate", this.getGateIndex()).method_27693(anchorStr).method_27692(class_124.field_1076);
                });
    }

    @Override
    public int hashCode() {
        return this.index;
    }

    public static IotaType<GateIota> TYPE = new IotaType<>() {
        public static final MapCodec<GateIota> CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
                Codec.INT.fieldOf(TAG_INDEX).forGetter(GateIota::getGateIndex),
                class_243.field_38277.optionalFieldOf(TAG_TARGET).forGetter(g -> Optional.ofNullable(g.target).flatMap(t -> t.left())),
                EntityAnchor.CODEC.optionalFieldOf(TAG_ANCHOR).forGetter(g -> Optional.ofNullable(g.target).flatMap(t -> t.right()))
        ).apply(inst, (index, target, anchor) -> {
            if (target.isPresent())
                return new GateIota(index, Either.left(target.get()), true);
            if (anchor.isPresent())
                return new GateIota(index, Either.right(anchor.get()), true);
            return new GateIota(index, null, true);
        }));

        public static final class_9139<class_9129, GateIota> STREAM_CODEC = class_9139.method_56436(
                class_9135.field_48550, GateIota::getGateIndex,
                class_9135.method_56382(VEC3_STREAM_CODEC), g -> Optional.ofNullable(g.target).flatMap(t -> t.left()),
                class_9135.method_56382(EntityAnchor.STREAM_CODEC), g -> Optional.ofNullable(g.target).flatMap(t -> t.right()),
                (index, target, anchor) -> {
                    if (target.isPresent())
                        return new GateIota(index, Either.left(target.get()), true);
                    if (anchor.isPresent())
                        return new GateIota(index, Either.right(anchor.get()), true);
                    return new GateIota(index, null, true);
                }
        );

        @Override
        public MapCodec<GateIota> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, GateIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xff_ff55ff;
        }
    };
}
