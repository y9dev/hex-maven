package ram.talia.hexal.api;

import com.google.common.base.Suppliers;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.function.Supplier;
import net.minecraft.class_2960;

public interface HexalAPI
{
	String MOD_ID = "hexal";
	Logger LOGGER = LogManager.getLogger(MOD_ID);
	
	Supplier<HexalAPI> INSTANCE = Suppliers.memoize(() -> {
		try {
			return (HexalAPI) Class.forName("ram.talia.hexal.common.impl.HexalAPIImpl")
								 .getDeclaredConstructor().newInstance();
		} catch (ReflectiveOperationException e) {
			LogManager.getLogger().warn("Unable to find HexalAPIImpl, using a dummy");
			return new HexalAPI() {
			};
		}
	});
	
	static HexalAPI instance() {
		return INSTANCE.get();
	}
	
	static class_2960 modLoc(String s) {
		return class_2960.method_60655(MOD_ID, s);
	}

	static boolean isValidResourceLocation(String s) {
		return class_2960.method_12829(s) != null;
	}
}
