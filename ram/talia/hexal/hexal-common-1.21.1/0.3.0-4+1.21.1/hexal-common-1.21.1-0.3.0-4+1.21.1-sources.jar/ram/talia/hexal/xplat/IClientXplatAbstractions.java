package ram.talia.hexal.xplat;

import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.common.msgs.IMessage;
import ram.talia.hexal.api.HexalAPI;

import javax.annotation.Nullable;
import net.minecraft.class_1044;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1800;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_4002;
import net.minecraft.class_5617;
import net.minecraft.class_707;
import java.util.ServiceLoader;
import java.util.function.Function;
import java.util.stream.Collectors;

public interface IClientXplatAbstractions {
	void sendPacketToServer(IMessage packet);
	
	void initPlatformSpecific();
	
	<T extends class_1297> void registerEntityRenderer(class_1299<? extends T> type, class_5617<T> renderer);
	
	<T extends class_2394> void registerParticleType(class_2396<T> type,
														  Function<class_4002, class_707<T>> factory);
	
	void registerItemProperty(class_1792 item, class_2960 id, class_1800 func);
	
	/**
	 * Gets the iota at the passed key in the client's Everbook.
	 */
	@Nullable
	class_2487 getClientEverbookIota(HexPattern key);
	
	/**
	 * Sets the client's everbook to contain the passed iota at the passed key.
	 */
	void setClientEverbookIota(HexPattern key, class_2487 iota);
	
	/**
	 * Removes the passed key from the client's everbook.
	 */
	void removeClientEverbookIota(HexPattern key);
	
	/**
	 * Returns the pattern at index in the client's Everbook (sorting the pattern keys alphabetically by their string representation).
	 */
	HexPattern getClientEverbookPattern(int index);
	
	/**
	 * Toggles whether the Everbook entry with the given key is a macro.
	 */
	void toggleClientEverbookMacro(HexPattern key);
	
	/**
	 * Returns true if the Everbook entry at the given key is a macro, and false otherwise.
	 */
	boolean isClientEverbookMacro(HexPattern key);
	
	// On Forge, these are already exposed; on Fabric we do a mixin
	void setFilterSave(class_1044 texture, boolean filter, boolean mipmap);
	
	void restoreLastFilter(class_1044 texture);
	
	IClientXplatAbstractions INSTANCE = find();
	
	private static IClientXplatAbstractions find() {
		var providers = ServiceLoader.load(IClientXplatAbstractions.class).stream().toList();
		if (providers.size() != 1) {
			var names = providers.stream().map(p -> p.type().getName()).collect(
							Collectors.joining(",", "[", "]"));
			throw new IllegalStateException(
							"There should be exactly one IClientXplatAbstractions implementation on the classpath. Found: " + names);
		} else {
			var provider = providers.get(0);
			HexalAPI.LOGGER.debug("Instantiating client xplat impl: " + provider.type().getName());
			return provider.get();
		}
	}
}
