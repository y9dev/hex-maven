package ram.talia.hexal.api.gates;

import net.minecraft.class_18;
import net.minecraft.class_2487;
import org.jetbrains.annotations.NotNull;

public class GateSavedData extends class_18 {
    public GateSavedData() {  }

    public GateSavedData(class_2487 tag) {
        GateManager.readFromNbt(tag);
    }

    @Override
    public @NotNull class_2487 method_75(@NotNull class_2487 tag, @NotNull net.minecraft.class_7225.class_7874 registries) {
        GateManager.writeToNbt(tag);

        return tag;
    }


}
