package ram.talia.hexal.common.lib;

import ram.talia.hexal.api.HexalAPI;
import ram.talia.hexal.common.levelgen.feature.SlipwayGeodeConfiguration;
import ram.talia.hexal.common.levelgen.feature.SlipwayGeodeFeature;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_2960;
import net.minecraft.class_3031;
import net.minecraft.class_3037;

import static ram.talia.hexal.api.HexalAPI.modLoc;

public class HexalFeatures {
	public static void registerFeatures (BiConsumer<class_3031<?>, class_2960> r) {
		HexalAPI.LOGGER.info("registering hexal features");
		for (var e : FEATURES.entrySet()) {
			r.accept(e.getValue(), e.getKey());
		}
	}
	
	private static final Map<class_2960, class_3031<?>> FEATURES = new LinkedHashMap<>();
	
	public static final class_3031<SlipwayGeodeConfiguration> SLIPWAY_GEODE = register("slipway_geode", new SlipwayGeodeFeature(SlipwayGeodeConfiguration.CODEC));
	
	private static <T extends class_3037> class_3031<T> register(String id, class_3031<T> feature) {
		var old = FEATURES.put(modLoc(id), feature);
		if (old != null) {
			throw new IllegalArgumentException("Typo? Duplicate id " + id);
		}
		return feature;
	}
}
