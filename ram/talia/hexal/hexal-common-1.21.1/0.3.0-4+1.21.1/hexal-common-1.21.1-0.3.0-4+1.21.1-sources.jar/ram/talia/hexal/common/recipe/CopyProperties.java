package ram.talia.hexal.common.recipe;

import net.minecraft.class_2680;
import net.minecraft.class_2769;

public class CopyProperties {
	// Because kotlin doesn't like doing raw, unchecked types
	// Can't blame it, but that's what we need to do
	@SuppressWarnings({"rawtypes", "unchecked"})
	public static class_2680 copyProperties(class_2680 original, class_2680 copyTo) {
		for (class_2769 prop : original.method_28501()) {
			if (copyTo.method_28498(prop)) {
				copyTo = copyTo.method_11657(prop, original.method_11654(prop));
			}
		}
		
		return copyTo;
	}
}
