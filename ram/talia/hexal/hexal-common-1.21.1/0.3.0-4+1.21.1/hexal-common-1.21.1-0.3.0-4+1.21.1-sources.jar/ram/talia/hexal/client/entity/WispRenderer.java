package ram.talia.hexal.client.entity;

import org.jetbrains.annotations.NotNull;
import ram.talia.hexal.common.entities.BaseCastingWisp;
import ram.talia.hexal.common.entities.BaseWisp;

import static ram.talia.hexal.api.HexalAPI.modLoc;

import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_897;

public class WispRenderer extends class_897<BaseWisp> {
	private static final class_2960 WISP = modLoc("textures/entity/wisp.png");
	
	public WispRenderer (class_5617.class_5618 context) {
		super(context);
	}
	
	@Override
	public @NotNull class_2960 getTextureLocation (@NotNull BaseWisp baseWisp) {
		return WISP;
	}
}
