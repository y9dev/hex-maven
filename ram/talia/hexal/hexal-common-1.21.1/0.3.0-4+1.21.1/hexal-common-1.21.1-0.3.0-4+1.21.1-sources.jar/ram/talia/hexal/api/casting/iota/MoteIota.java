package ram.talia.hexal.api.casting.iota;

import at.petrak.hexcasting.api.casting.eval.CastingEnvironment;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.api.casting.iota.NullIota;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import ram.talia.hexal.api.mediafieditems.ItemRecord;
import ram.talia.hexal.api.mediafieditems.MediafiedItemManager;
import ram.talia.hexal.common.lib.hex.HexalIotaTypes;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_4844;
import net.minecraft.class_9129;
import net.minecraft.class_9135;

/**
 * Similar to GateIotas, stores a reference to an item stored in the
 * media. When the item is used up, all references to it become null.
 */
public class MoteIota extends Iota {
    static final String TAG_INDEX_PAYLOAD = "index";
    static final String TAG_DISPLAY_NAME = "name";
    static final String TAG_COUNT = "count";

    /**
     * Used to get the UUID of the temporarily bound storage from the casting image's userdata, if one exists.
     */
    public static final String TAG_TEMP_STORAGE = "hexal:temp_storage";

    private final MediafiedItemManager.Index index;
    // display data captured at serialisation time; the client does not have the storage loaded, so display() has to
    // fall back to this instead of the live record
    @Nullable
    private final String cachedDisplayName;
    @Nullable
    private final Long cachedCount;

    public MoteIota(MediafiedItemManager.Index payload) {
        this(payload, null, null);
    }

    private MoteIota(MediafiedItemManager.Index payload, @Nullable String cachedDisplayName, @Nullable Long cachedCount) {
        super(() -> HexalIotaTypes.MOTE);
        this.index = payload;
        this.cachedDisplayName = cachedDisplayName;
        this.cachedCount = cachedCount;
    }

    public static @Nullable MoteIota makeIfStorageLoaded(class_1799 stack, UUID storageUUID) {
        var index = MediafiedItemManager.assignItem(stack, storageUUID);

        if (index != null)
            return new MoteIota(index);
        else
            return null;
    }

    public static @Nullable MoteIota makeIfStorageLoaded(ItemRecord record, UUID storageUUID) {
        var index = MediafiedItemManager.assignItem(record, storageUUID);

        if (index != null)
            return new MoteIota(index);
        else
            return null;
    }

    /**
     * Returns the MoteIota if its item still exists, or null otherwise. SHOULD ALWAYS
     * BE CALLED BEFORE MAKING USE OF AN ITEM IOTA {@literal (built into List<Iota>.getItem)}.
     */
    public @Nullable MoteIota selfOrNull() {
        if (MediafiedItemManager.contains(this.getItemIndex()))
            return this;
        return null;
    }

    public boolean isEmpty() {
        return MediafiedItemManager.isEmpty(this.getItemIndex());
    }

    public MediafiedItemManager.Index getItemIndex() {
        return this.index;
    }

    public @Nullable ItemRecord getRecord() {
        var record = MediafiedItemManager.getRecord(this.getItemIndex());
        if (record == null)
            return null;
        return record.get();
    }

    public class_1792 getItem() {
        return Objects.requireNonNull(MediafiedItemManager.getItem(this.getItemIndex()), "MediafiedItemManager returned null for Item that has existing MoteIota.");
    }

    public class_2487 getTag() {
        return MediafiedItemManager.getTag(this.getItemIndex());
    }

    public void setTag(class_2487 tag) {
        MediafiedItemManager.setTag(this.getItemIndex(), tag);
    }

    public long getCount() {
        return Objects.requireNonNull(MediafiedItemManager.getCount(this.getItemIndex()), "MediafiedItemManager returned null for Item that has existing MoteIota.");
    }

    public void absorb(MoteIota other) {
        MediafiedItemManager.merge(this.getItemIndex(), other.getItemIndex());
    }

    public int absorb(class_1799 other) {
        return MediafiedItemManager.merge(this.getItemIndex(), other);
    }

    public boolean typeMatches(MoteIota other) {
        return MediafiedItemManager.typeMatches(this.getItemIndex(), other.getItemIndex());
    }

    public boolean typeMatches(class_1799 other) {
        return MediafiedItemManager.typeMatches(this.getItemIndex(), other);
    }

    public @Nullable MoteIota splitOff(long amount, @Nullable UUID storage) {
        var newIndex = MediafiedItemManager.splitOff(this.getItemIndex(), amount, storage);
        if (newIndex == null)
            return null;

        return new MoteIota(newIndex);
    }

    public List<class_1799> getStacksToDrop(int count) {
        return MediafiedItemManager.getStacksToDrop(this.getItemIndex(), count);
    }

    public long removeItems(int count) {
        return removeItems((long) count);
    }

    public long removeItems(long count) {
        return MediafiedItemManager.removeItems(this.getItemIndex(), count);
    }

    /**
     * Takes a template ItemStack and sets the item and tag of the referenced ItemRecord to that item and tag, while leaving the count the same.
     */
    public void templateOff(@NotNull class_1799 template) {
        MediafiedItemManager.templateOff(this.getItemIndex(), template, null);
    }

    /**
     * Takes a template ItemStack and sets the item and tag of the referenced ItemRecord to that item and tag, as well as overriding the count to newCount.
     */
    public void templateOff(@NotNull class_1799 template, long newCount) {
        MediafiedItemManager.templateOff(this.getItemIndex(), template, newCount);
    }

    public MoteIota copy() {
        return new MoteIota(this.getItemIndex());
    }

    public @Nullable MoteIota setStorage(@NotNull UUID uuid) {
        var storageFull = MediafiedItemManager.isStorageFull(uuid);
        if (storageFull == null || storageFull) // isStorageFull can return null
            return null;

        var record = getRecord();
        MediafiedItemManager.removeRecord(this.getItemIndex());
        if (record == null)
            return null;

        var newIndex = MediafiedItemManager.assignItem(record, uuid);
        return new MoteIota(newIndex);
    }

    @Override
    protected boolean toleratesOther(Iota that) {
        return (typesMatch(this, that) &&
                that instanceof MoteIota ithat &&
                this.getItemIndex().equals(ithat.getItemIndex())) ||
                (this.isEmpty() && (that instanceof NullIota ||
                        (that instanceof MoteIota ithat2 &&
                                ithat2.isEmpty())));
    }

    @Override
    public boolean isTruthy(@Nullable CastingEnvironment env) {
        return !this.isEmpty();
    }

    @Override
    public @NotNull class_2561 display() {
        var record = this.getRecord();

        var name = record != null ? record.getDisplayName().getString() : this.cachedDisplayName;
        var count = record != null ? Long.valueOf(record.getCount()) : this.cachedCount;

        if (name == null || count == null)
            return class_2561.method_43471("hexcasting.tooltip.null_iota").method_27692(class_124.field_1080);

        return class_2561.method_43469("hexal.spelldata.mote", name, count)
                .method_27692(class_124.field_1054);
    }

    @Override
    public int hashCode() {
        return this.index.hashCode();
    }

    public static IotaType<MoteIota> TYPE = new IotaType<>() {
        public static final MapCodec<MoteIota> CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
                MediafiedItemManager.Index.CODEC.fieldOf(TAG_INDEX_PAYLOAD).forGetter(MoteIota::getItemIndex),
                Codec.STRING.optionalFieldOf(TAG_DISPLAY_NAME).forGetter(m -> {
                    var rec = m.getRecord();
                    return Optional.ofNullable(rec != null ? rec.getDisplayName().getString() : m.cachedDisplayName);
                }),
                Codec.LONG.optionalFieldOf(TAG_COUNT).forGetter(m -> {
                    var rec = m.getRecord();
                    return Optional.ofNullable(rec != null ? Long.valueOf(rec.getCount()) : m.cachedCount);
                })
        ).apply(inst, (index, name, count) -> new MoteIota(index, name.orElse(null), count.orElse(null))));

        public static final net.minecraft.class_9139<class_9129, MoteIota> STREAM_CODEC =
                net.minecraft.class_9139.method_56905(
                        class_4844.field_48453, m -> m.getItemIndex().getStorage(),
                        class_9135.field_48550, m -> m.getItemIndex().getIndex(),
                        class_9135.method_56382(class_9135.field_48554), m -> {
                            var rec = m.getRecord();
                            return Optional.ofNullable(rec != null ? rec.getDisplayName().getString() : m.cachedDisplayName);
                        },
                        class_9135.method_56382(class_9135.field_48551), m -> {
                            var rec = m.getRecord();
                            return Optional.ofNullable(rec != null ? Long.valueOf(rec.getCount()) : m.cachedCount);
                        },
                        (storage, idx, name, count) -> new MoteIota(new MediafiedItemManager.Index(storage, idx),
                                name.orElse(null), count.orElse(null))
                );

        @Override
        public MapCodec<MoteIota> codec() {
            return CODEC;
        }

        @Override
        public net.minecraft.class_9139<class_9129, MoteIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xff_ffff55;
        }
    };
}
