package ram.talia.hexal.common.lib;

import ram.talia.hexal.api.HexalAPI;
import ram.talia.hexal.common.entities.ProjectileWisp;
import ram.talia.hexal.common.entities.TickingWisp;
import ram.talia.hexal.common.entities.WanderingWisp;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2960;

import static ram.talia.hexal.api.HexalAPI.modLoc;

public class HexalEntities {
	public static void registerEntities (BiConsumer<class_1299<?>, class_2960> r) {
		for (var e : ENTITIES.entrySet()) {
			r.accept(e.getValue(), e.getKey());
		}
	}
	
	public static void registerEntityDataSerialisers () {
	
	}
	
	private static final Map<class_2960, class_1299<?>> ENTITIES = new LinkedHashMap<>();
	
	public static final class_1299<WanderingWisp> WANDERING_WISP  = register(
					"wisp/wandering",
					class_1299.class_1300.method_5903((class_1299.class_4049<WanderingWisp>) WanderingWisp::new, class_1311.field_17715)
														.sized(0.5f, 0.5f)
														.eyeHeight(0.25f)
														.clientTrackingRange(32)
														.updateInterval(1)
														.build(HexalAPI.MOD_ID + ":wisp/wandering"));
	
	public static final class_1299<ProjectileWisp> PROJECTILE_WISP = register(
					"wisp/projectile",
					class_1299.class_1300.method_5903((class_1299.class_4049<ProjectileWisp>) ProjectileWisp::new, class_1311.field_17715)
														.sized(0.5f, 0.5f)
														.eyeHeight(0.25f)
														.clientTrackingRange(32)
														.updateInterval(1)
														.build(HexalAPI.MOD_ID + ":wisp/projectile"));
	
	public static final class_1299<TickingWisp> TICKING_WISP = register(
					"wisp/ticking",
					class_1299.class_1300.method_5903((class_1299.class_4049<TickingWisp>) TickingWisp::new, class_1311.field_17715)
														.sized(0.5f, 0.5f)
														.eyeHeight(0.25f)
														.clientTrackingRange(32)
														.updateInterval(1)
														.build(HexalAPI.MOD_ID + ":wisp/ticking"));
	
	private static <T extends class_1297> class_1299<T> register (String id, class_1299<T> type) {
		var old = ENTITIES.put(modLoc(id), type);
		if (old != null) {
			throw new IllegalArgumentException("Typo? Duplicate id " + id);
		}
		return type;
	}
}
