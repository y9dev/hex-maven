package ram.talia.hexal.client;

import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_5614;
import org.jetbrains.annotations.NotNull;
import ram.talia.hexal.client.blocks.BlockEntityMediafiedStorageRenderer;
import ram.talia.hexal.client.entity.WispRenderer;
import ram.talia.hexal.common.lib.HexalBlockEntities;
import ram.talia.hexal.common.lib.HexalEntities;
import ram.talia.hexal.xplat.IClientXplatAbstractions;

public class RegisterClientStuff {
    public static void init() {
        var x = IClientXplatAbstractions.INSTANCE;

        x.registerEntityRenderer(HexalEntities.PROJECTILE_WISP, WispRenderer::new);
        x.registerEntityRenderer(HexalEntities.TICKING_WISP, WispRenderer::new);
        x.registerEntityRenderer(HexalEntities.WANDERING_WISP, WispRenderer::new);
    }

    public static void registerBlockEntityRenderers(@NotNull BlockEntityRendererRegisterer registerer) {
        registerer.registerBlockEntityRenderer(HexalBlockEntities.MEDIAFIED_STORAGE, ctx -> new BlockEntityMediafiedStorageRenderer());
    }

    @FunctionalInterface
    public interface BlockEntityRendererRegisterer {
        <T extends class_2586> void registerBlockEntityRenderer(class_2591<T> type, class_5614<? super T> berp);
    }
}
