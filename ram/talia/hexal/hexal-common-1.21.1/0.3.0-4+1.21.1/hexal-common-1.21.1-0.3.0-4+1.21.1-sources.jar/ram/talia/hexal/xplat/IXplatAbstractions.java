package ram.talia.hexal.xplat;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.common.msgs.IMessage;
import com.mojang.authlib.GameProfile;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import ram.talia.hexal.api.everbook.Everbook;
import ram.talia.hexal.api.linkable.ILinkable;
import ram.talia.hexal.api.linkable.PlayerLinkstore;
import ram.talia.hexal.api.casting.wisp.WispCastingManager;
import ram.talia.hexal.common.entities.BaseCastingWisp;
import ram.talia.hexal.common.items.ItemRelay;

import java.util.List;
import java.util.ServiceLoader;
import java.util.UUID;
import java.util.stream.Collectors;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public interface IXplatAbstractions {
//    Platform platform();
//
//    boolean isModPresent(String id);

    boolean isPhysicalClient();
//
//    void initPlatformSpecific();

    void sendPacketToPlayer(class_3222 target, IMessage packet);

    void sendPacketNear(class_243 pos, double radius, class_3218 dimension, IMessage packet);

    void sendPacketTracking(class_1297 entity, IMessage packet);
    void sendPacketTracking(class_2586 blockEntity, IMessage packet);
    void sendPacketTracking(class_2338 pos, class_3218 dimension, IMessage packet);
    void sendPacketTracking(class_1923 pos, class_3218 dimension, IMessage packet);


    // https://github.com/VazkiiMods/Botania/blob/13b7bcd9cbb6b1a418b0afe455662d29b46f1a7f/Xplat/src/main/java/vazkii/botania/xplat/IXplatAbstractions.java#L157
    class_2596<?> toVanillaClientboundPacket(IMessage message);

//    double getReachDistance(Player player);

    // Things that used to be caps

    boolean isInteractingAllowed(class_1937 level, class_2338 pos, class_2350 direction, class_1268 hand, class_1657 player);

    WispCastingManager getWispCastingManager(class_3222 caster);

    /**
     * Takes in a caster and wisp, and sets that caster's Seon (wisp that costs significantly less to maintain) to the
     * accepted wisp. The old Seon if one exists is unmarked.
     */
    void setSeon(class_3222 caster, @Nullable BaseCastingWisp wisp);

    @Nullable
    BaseCastingWisp getSeon(class_3222 caster);

    PlayerLinkstore getLinkstore(class_3222 player);

    PlayerLinkstore.RenderCentre getPlayerRenderCentre(class_1657 player);
    
    void syncAddRenderLink(ILinkable sourceLink, ILinkable sinkLink, class_3218 level);

    void syncRemoveRenderLink(ILinkable sourceLink, ILinkable sinkLink, class_3218 level);

    void syncSetRenderLinks(ILinkable sourceLink, List<ILinkable> sinks, class_3218 level);

    //region Transmission
    ILinkable getPlayerTransmittingTo (class_3222 player);
    void setPlayerTransmittingTo (class_3222 player, int to);
    void resetPlayerTransmittingTo (class_3222 player);
    //endregion

    //region Everbook
    Iota getEverbookIota(class_3222 player, HexPattern key);
    void setEverbookIota(class_3222 player, HexPattern key, Iota iota);
    
    void removeEverbookIota(class_3222 player, HexPattern key);
    
    void setFullEverbook(class_3222 player, Everbook everbook);
    
    List<Iota> getEverbookMacro (class_3222 player, HexPattern key);
    
    void toggleEverbookMacro (class_3222 player, HexPattern key);

    @Nullable UUID getBoundStorage(class_3222 player);

    void setBoundStorage(class_3222 player, @Nullable UUID storage);

    //endregion

    //region Geckolib
    @NotNull ItemRelay getItemRelay(class_1792.class_1793 properties);

    @NotNull Object getItemRelayRenderProvider();

    //endregion

    // Blocks

//    <T extends BlockEntity> BlockEntityType<T> createBlockEntityType(BiFunction<BlockPos, BlockState, T> func,
//        Block... blocks);
//
//    boolean tryPlaceFluid(Level level, InteractionHand hand, BlockPos pos, ItemStack stack, Fluid fluid);


    // misc


//    boolean isCorrectTierForDrops(Tier tier, BlockState bs);
//
//    ResourceLocation getID(Block block);
//
//    ResourceLocation getID(Item item);
//
//    ResourceLocation getID(VillagerProfession profession);
//
//    Ingredient getUnsealedIngredient(ItemStack stack);
//
//    IXplatTags tags();
//
//    LootItemCondition.Builder isShearsCondition();
//
//    String getModName(String namespace);
//
    class_3222 getFakePlayer(class_3218 level, UUID uuid);
    class_3222 getFakePlayer(class_3218 level, GameProfile profile);

    boolean isBreakingAllowed(class_3218 level, class_2338 pos, class_2680 state, @Nullable class_1657 player);

    boolean isPlacingAllowed(class_3218 level, class_2338 pos, class_1799 stack, @Nullable class_1657 player);

    // interop

//    PehkuiInterop.ApiAbstraction getPehkuiApi();

    ///

    IXplatAbstractions INSTANCE = find();

    private static IXplatAbstractions find() {
        var providers = ServiceLoader.load(IXplatAbstractions.class).stream().toList();
        if (providers.size() != 1) {
            var names = providers.stream().map(p -> p.type().getName()).collect(Collectors.joining(",", "[", "]"));
            throw new IllegalStateException(
                "There should be exactly one IXplatAbstractions implementation on the classpath. Found: " + names);
        } else {
            var provider = providers.get(0);
            HexAPI.LOGGER.debug("Instantiating xplat impl: " + provider.type().getName());
            return provider.get();
        }
    }
}
