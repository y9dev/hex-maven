package ram.talia.moreiotas.api;

import com.google.common.base.Suppliers;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.function.Supplier;
import net.minecraft.class_2960;

public interface MoreIotasAPI
{
	String MOD_ID = "moreiotas";
	Logger LOGGER = LogManager.getLogger(MOD_ID);
	
	Supplier<MoreIotasAPI> INSTANCE = Suppliers.memoize(() -> {
		try {
			return (MoreIotasAPI) Class.forName("com.talia.moreiotas.common.impl.MoreIotasAPIImpl")
								 .getDeclaredConstructor().newInstance();
		} catch (ReflectiveOperationException e) {
			LogManager.getLogger().warn("Unable to find MoreIotasAPIImpl, using a dummy");
			return new MoreIotasAPI() {
			};
		}
	});
	
	static MoreIotasAPI instance() {
		return INSTANCE.get();
	}
	
	static class_2960 modLoc(String s) {
		return class_2960.method_60655(MOD_ID, s);
	}
}
