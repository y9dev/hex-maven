package ram.talia.moreiotas.client;

import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_5614;
import org.jetbrains.annotations.NotNull;
import ram.talia.moreiotas.xplat.IClientXplatAbstractions;

public class RegisterClientStuff {
	public static void init () {
		var x = IClientXplatAbstractions.INSTANCE;
	}
	
	public static void registerBlockEntityRenderers(@NotNull BlockEntityRendererRegisterer registerer) {
	}
	
	@FunctionalInterface
	public interface BlockEntityRendererRegisterer {
		<T extends class_2586> void registerBlockEntityRenderer(class_2591<T> type, class_5614<? super T> berp);
	}
}
