package ram.talia.moreiotas.api.casting.iota;

import at.petrak.hexcasting.api.casting.eval.CastingEnvironment;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.common.lib.HexRegistries;
import at.petrak.hexcasting.common.lib.hex.HexIotaTypes;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static ram.talia.moreiotas.common.lib.hex.MoreIotasIotaTypes.IOTA_TYPE;

public class IotaTypeIota extends Iota {
    private final IotaType<?> iotaType;

    public IotaTypeIota(@NotNull IotaType<?> iotaType) {
        super(() -> IOTA_TYPE);
        this.iotaType = iotaType;
    }

    public IotaType<?> getIotaType() {
        return this.iotaType;
    }

    @Override
    protected boolean toleratesOther(Iota that) {
        return typesMatch(this, that) &&
                that instanceof IotaTypeIota dent &&
                this.getIotaType().equals(dent.getIotaType());
    }

    @Override
    public boolean isTruthy(@Nullable CastingEnvironment env) {
        return true;
    }

    @Override
    public @NotNull class_2561 display() {
        var location = HexIotaTypes.REGISTRY.method_10221(this.getIotaType());
        if (location == null)
            return class_2561.method_43471("hexcasting.spelldata.unknown");
        return class_2561.method_43471("hexcasting.iota.%s".formatted(location.toString()))
                .method_27692(class_124.field_1064);
    }

    @Override
    public int hashCode() {
        return this.getIotaType().hashCode();
    }

    public static IotaType<IotaTypeIota> TYPE = new IotaType<>() {
        @SuppressWarnings("unchecked")
        public static final MapCodec<IotaTypeIota> CODEC = Codec.lazyInitialized(
                        () -> (Codec<IotaType<?>>) (Codec<?>) HexIotaTypes.REGISTRY.method_39673())
                .comapFlatMap(t -> DataResult.success(new IotaTypeIota(t)), IotaTypeIota::getIotaType)
                .fieldOf("value");

        public static final class_9139<class_9129, IotaTypeIota> STREAM_CODEC =
                class_9135.method_56365(HexRegistries.IOTA_TYPE)
                        .method_56432(IotaTypeIota::new, IotaTypeIota::getIotaType);

        @Override
        public MapCodec<IotaTypeIota> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, IotaTypeIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xff_553355;
        }
    };
}
