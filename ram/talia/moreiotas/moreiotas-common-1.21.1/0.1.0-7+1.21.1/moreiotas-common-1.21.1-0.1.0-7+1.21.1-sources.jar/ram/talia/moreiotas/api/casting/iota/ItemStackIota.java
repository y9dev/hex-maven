package ram.talia.moreiotas.api.casting.iota;

import at.petrak.hexcasting.api.casting.eval.CastingEnvironment;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import com.mojang.serialization.MapCodec;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import java.util.ArrayList;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9276;
import net.minecraft.class_9288;
import net.minecraft.class_9334;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static ram.talia.moreiotas.common.lib.hex.MoreIotasIotaTypes.ITEM_STACK;

public class ItemStackIota extends Iota {
    private final class_1799 stack;

    private ItemStackIota(class_1799 stack) {
        super(() -> ITEM_STACK);
        this.stack = stack;
    }

    public class_1799 getItemStack() {
        return this.stack;
    }

    @Override
    protected boolean toleratesOther(Iota iota) {
        return iota instanceof ItemStackIota iiota && class_1799.method_7973(this.getItemStack(), iiota.getItemStack());
    }

    @Override
    public boolean isTruthy(@Nullable CastingEnvironment env) {
        return !this.getItemStack().method_7960();
    }

    @Override
    public @NotNull class_2561 display() {
        var stack = this.getItemStack();

        if (stack.method_7960())
            return class_2561.method_43471("moreiotas.tooltip.stack.empty").method_27696(class_2583.field_24360.method_36139(0x1E90FF));

        return class_2561.method_43469("moreiotas.tooltip.stack.format", stack.method_7947(), stack.method_7964())
                .method_27696(class_2583.field_24360.method_36139(0x1E90FF));
    }

    @Override
    public int hashCode() {
        return class_1799.method_57355(this.getItemStack());
    }

    /** Maximum depth of nested containers that is searched for iota-holding components. */
    private static final int MAX_FILTER_DEPTH = 8;

    /**
     * Creates an iota for the given stack.
     * <p>
     * Mirrors the 1.20.1 anti-dupe / anti-bloat guard: every component that embeds iotas (Hex iota holders,
     * hex patterns and spellbook pages) is stripped from the stack and from any stack nested in a container or
     * bundle, so an item stack iota can never contain further iotas.
     */
    public static ItemStackIota createFiltered(class_1799 originalStack) {
        var stack = originalStack.method_7972();
        filterIotaComponents(stack, 0);
        return new ItemStackIota(stack);
    }

    private static void filterIotaComponents(class_1799 stack, int depth) {
        if (stack.method_7960())
            return;

        stack.method_57381(HexDataComponents.IOTA_HOLDER_IOTA.get());
        stack.method_57381(HexDataComponents.HEX_HOLDER_PATTERNS.get());
        stack.method_57381(HexDataComponents.SPELLBOOK_PAGES.get());

        var container = stack.method_57824(class_9334.field_49622);
        var bundle = stack.method_57824(class_9334.field_49650);

        if (depth >= MAX_FILTER_DEPTH) {
            // Too deep to inspect safely; drop the nested contents altogether.
            if (container != null) stack.method_57381(class_9334.field_49622);
            if (bundle != null) stack.method_57381(class_9334.field_49650);
            return;
        }

        if (container != null && container != class_9288.field_49334) {
            var filtered = new ArrayList<class_1799>();
            container.method_59714().forEach(inner -> {
                var copy = inner.method_7972();
                filterIotaComponents(copy, depth + 1);
                filtered.add(copy);
            });
            stack.method_57379(class_9334.field_49622, class_9288.method_57493(filtered));
        }

        if (bundle != null && !bundle.method_57429()) {
            var filtered = new ArrayList<class_1799>();
            bundle.method_57421().forEach(inner -> {
                var copy = inner.method_7972();
                filterIotaComponents(copy, depth + 1);
                filtered.add(copy);
            });
            stack.method_57379(class_9334.field_49650, new class_9276(filtered));
        }
    }

    public static ItemStackIota of(class_1799 stack) {
        return new ItemStackIota(stack);
    }

    public static IotaType<ItemStackIota> TYPE = new IotaType<>() {
        public static final MapCodec<ItemStackIota> CODEC = class_1799.field_49266
                .xmap(ItemStackIota::createFiltered, ItemStackIota::getItemStack)
                .fieldOf("value");

        public static final class_9139<class_9129, ItemStackIota> STREAM_CODEC =
                class_1799.field_49268.method_56432(ItemStackIota::createFiltered, ItemStackIota::getItemStack);

        @Override
        public MapCodec<ItemStackIota> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, ItemStackIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xFF_1E90FF;
        }
    };
}
