package ram.talia.moreiotas.api.casting.iota;

import at.petrak.hexcasting.api.casting.eval.CastingEnvironment;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_124;
import net.minecraft.class_1299;
import net.minecraft.class_2561;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static ram.talia.moreiotas.common.lib.hex.MoreIotasIotaTypes.ENTITY_TYPE;

public class EntityTypeIota extends Iota {
    private final class_1299<?> entityType;

    public EntityTypeIota(@NotNull class_1299<?> entityType) {
        super(() -> ENTITY_TYPE);
        this.entityType = entityType;
    }

    public class_1299<?> getEntityType() {
        return this.entityType;
    }

    @Override
    protected boolean toleratesOther(Iota that) {
        return typesMatch(this, that) &&
                that instanceof EntityTypeIota dent &&
                this.getEntityType().equals(dent.getEntityType());
    }

    @Override
    public boolean isTruthy(@Nullable CastingEnvironment env) {
        return true;
    }

    @Override
    public @NotNull class_2561 display() {
        return this.getEntityType().method_5897().method_27661()
                .method_27693(" ")
                .method_10852(class_2561.method_43471("moreiotas.spelldata.entity_type"))
                .method_27692(class_124.field_1062);
    }

    @Override
    public int hashCode() {
        return this.getEntityType().hashCode();
    }

    public static IotaType<EntityTypeIota> TYPE = new IotaType<>() {
        @SuppressWarnings("unchecked")
        public static final MapCodec<EntityTypeIota> CODEC = Codec.lazyInitialized(
                        () -> (Codec<class_1299<?>>) (Codec<?>) class_7923.field_41177.method_39673())
                .xmap(EntityTypeIota::new, EntityTypeIota::getEntityType)
                .fieldOf("value");

        public static final class_9139<class_9129, EntityTypeIota> STREAM_CODEC =
                class_9135.method_56365(class_7924.field_41266)
                        .method_56432(EntityTypeIota::new, EntityTypeIota::getEntityType);

        @Override
        public MapCodec<EntityTypeIota> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, EntityTypeIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xff_5555ff;
        }
    };
}
