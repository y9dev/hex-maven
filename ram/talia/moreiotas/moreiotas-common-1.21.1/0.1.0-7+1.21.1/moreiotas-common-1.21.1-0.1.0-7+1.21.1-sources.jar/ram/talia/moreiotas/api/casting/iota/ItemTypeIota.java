package ram.talia.moreiotas.api.casting.iota;

import at.petrak.hexcasting.api.casting.eval.CastingEnvironment;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_124;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_7923;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static ram.talia.moreiotas.common.lib.hex.MoreIotasIotaTypes.ITEM_TYPE;

public class ItemTypeIota extends Iota {
    private final Either<class_1792, class_2248> either;

    public ItemTypeIota(@NotNull class_1792 item) {
        super(() -> ITEM_TYPE);
        this.either = Either.left(item);
    }

    public ItemTypeIota(@NotNull class_2248 block) {
        super(() -> ITEM_TYPE);
        this.either = Either.right(block);
    }

    public Either<class_1792, class_2248> getEither() {
        return this.either;
    }

    @Nullable
    public class_2248 getBlock() {
        return this.getEither().map(item -> {
            if (item instanceof class_1747 blockItem)
                return blockItem.method_7711();
            else return null;
        }, block -> block);
    }

    /**
     * If the block has no item form this returns Items.AIR
     */
    @Nullable
    public class_1792 getItem() {
        return this.getEither().map(item -> item, class_2248::method_8389);
    }

    @Override
    protected boolean toleratesOther(Iota that) {
        return typesMatch(this, that) &&
                that instanceof ItemTypeIota dent &&
                this.getEither().map(
                        itemThis -> dent.getEither().map(itemThis::equals,
                                blockThat -> {
                                    var itemThat = blockThat.method_8389();
                                    if (itemThat.equals(class_1802.field_8162) && !blockThat.equals(class_2246.field_10124))
                                        return false;
                                    return itemThis.equals(itemThat);
                                }),
                        blockThis -> dent.getEither().map(itemThat -> {
                                                              var itemThis = blockThis.method_8389();
                                                              if (itemThis.equals(class_1802.field_8162) && !blockThis.equals(class_2246.field_10124))
                                                                  return false;
                                                              return itemThis.equals(itemThat);
                                                          }, blockThis::equals));
    }

    @Override
    public boolean isTruthy(@Nullable CastingEnvironment env) {
        return this.getEither().map(item -> !item.equals(class_1802.field_8162), block -> !block.equals(class_2246.field_10124));
    }

    @Override
    public @NotNull class_2561 display() {
        return this.getEither().map(item -> (class_2561) item.method_7848().method_27661().method_27692(class_124.field_1065),
                block -> block.method_9518().method_27692(class_124.field_1065));
    }

    @Override
    public int hashCode() {
        return this.getEither().hashCode();
    }

    public static IotaType<ItemTypeIota> TYPE = new IotaType<>() {
        @SuppressWarnings("unchecked")
        public static final MapCodec<ItemTypeIota> CODEC = Codec.either(
                        (Codec<class_1792>) (Codec<?>) class_7923.field_41178.method_39673(),
                        (Codec<class_2248>) (Codec<?>) class_7923.field_41175.method_39673())
                .xmap(either -> either.map(item -> new ItemTypeIota(item), block -> new ItemTypeIota(block)),
                        ItemTypeIota::getEither)
                .fieldOf("value");

        public static final class_9139<class_9129, ItemTypeIota> STREAM_CODEC = new class_9139<>() {
            @Override
            public ItemTypeIota decode(class_9129 buf) {
                boolean isBlock = buf.readBoolean();
                var id = buf.method_10810();
                if (isBlock) {
                    return new ItemTypeIota(class_7923.field_41175.method_10223(id));
                } else {
                    return new ItemTypeIota(class_7923.field_41178.method_10223(id));
                }
            }

            @Override
            public void encode(class_9129 buf, ItemTypeIota iota) {
                var either = iota.getEither();
                if (either.left().isPresent()) {
                    buf.method_52964(false);
                    buf.method_10812(class_7923.field_41178.method_10221(either.left().get()));
                } else {
                    buf.method_52964(true);
                    buf.method_10812(class_7923.field_41175.method_10221(either.right().get()));
                }
            }
        };

        @Override
        public MapCodec<ItemTypeIota> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, ItemTypeIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xff_feaa01;
        }
    };
}
