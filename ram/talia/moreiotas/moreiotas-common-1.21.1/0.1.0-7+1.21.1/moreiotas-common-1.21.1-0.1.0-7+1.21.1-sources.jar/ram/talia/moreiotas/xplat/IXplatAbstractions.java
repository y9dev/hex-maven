package ram.talia.moreiotas.xplat;

import org.jetbrains.annotations.Nullable;

import java.util.ServiceLoader;
import java.util.stream.Collectors;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;

public interface IXplatAbstractions {
    boolean isPhysicalClient();

    void sendPacketToPlayer(class_3222 target, class_8710 packet);

    void sendPacketNear(class_243 pos, double radius, class_3218 dimension, class_8710 packet);

    class_2596<?> toVanillaClientboundPacket(class_8710 message);

    boolean isBreakingAllowed(class_1937 level, class_2338 pos, class_2680 state, class_1657 player);

    @Nullable String lastMessage(@Nullable class_1657 player);

    void setChatPrefix(class_1657 player, @Nullable String prefix);

    @Nullable String getChatPrefix(class_1657 player);

    ///

    IXplatAbstractions INSTANCE = find();

    private static IXplatAbstractions find() {
        var providers = ServiceLoader.load(IXplatAbstractions.class).stream().toList();
        if (providers.size() != 1) {
            var names = providers.stream().map(p -> p.type().getName()).collect(Collectors.joining(",", "[", "]"));
            throw new IllegalStateException(
                "There should be exactly one IXplatAbstractions implementation on the classpath. Found: " + names);
        } else {
            var provider = providers.get(0);
            return provider.get();
        }
    }
}
