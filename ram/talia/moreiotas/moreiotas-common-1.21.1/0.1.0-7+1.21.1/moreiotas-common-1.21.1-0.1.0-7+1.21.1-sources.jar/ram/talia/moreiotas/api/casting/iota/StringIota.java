package ram.talia.moreiotas.api.casting.iota;

import at.petrak.hexcasting.api.casting.eval.CastingEnvironment;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.api.casting.mishaps.MishapInvalidIota;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import ram.talia.moreiotas.api.mod.MoreIotasConfig;
import ram.talia.moreiotas.common.lib.hex.MoreIotasIotaTypes;

public class StringIota extends Iota {
    private final String string;

    private StringIota(@NotNull String string) {
        super(() -> MoreIotasIotaTypes.STRING);
        this.string = string;
    }

    public static StringIota make(@NotNull String string) throws MishapInvalidIota {
        if (string.length() > MoreIotasConfig.getServer().getMaxStringLength())
            throw MishapInvalidIota.of(new StringIota(string), 0, "string.max_size", MoreIotasConfig.getServer().getMaxStringLength(), string.length());
        return new StringIota(string);
    }

    public static StringIota makeUnchecked(@NotNull String string) {
        return new StringIota(string);
    }

    public String getString() {
        return this.string;
    }

    @Override
    protected boolean toleratesOther(Iota that) {
        return typesMatch(this, that)
                && that instanceof StringIota sthat
                && this.getString().equals(sthat.getString());
    }

    @Override
    public boolean isTruthy(@Nullable CastingEnvironment env) {
        return !this.getString().isEmpty();
    }

    @Override
    public @NotNull class_2561 display() {
        return class_2561.method_43469("moreiotas.tooltip.string", this.getString())
                .method_27692(class_124.field_1076);
    }

    @Override
    public int hashCode() {
        return this.getString().hashCode();
    }

    public static IotaType<StringIota> TYPE = new IotaType<>() {
        public static final MapCodec<StringIota> CODEC = com.mojang.serialization.Codec.STRING
                .comapFlatMap(
                        s -> {
                            try {
                                return DataResult.success(StringIota.make(s));
                            } catch (MishapInvalidIota e) {
                                return DataResult.error(e::getMessage);
                            }
                        },
                        StringIota::getString)
                .fieldOf("value");

        public static final class_9139<class_9129, StringIota> STREAM_CODEC =
                class_9135.field_48554.<class_9129>method_56439(buf -> buf).method_56432(StringIota::makeUnchecked, StringIota::getString);

        @Override
        public MapCodec<StringIota> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, StringIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xff_ff55ff;
        }
    };
}
