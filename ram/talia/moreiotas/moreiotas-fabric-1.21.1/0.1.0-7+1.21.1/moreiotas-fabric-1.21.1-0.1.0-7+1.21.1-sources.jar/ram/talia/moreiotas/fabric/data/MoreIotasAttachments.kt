package ram.talia.moreiotas.fabric.data

import com.mojang.serialization.Codec
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry
import net.fabricmc.fabric.api.attachment.v1.AttachmentType
import net.minecraft.world.entity.player.Player
import ram.talia.moreiotas.api.MoreIotasAPI.modLoc

/**
 * Player data formerly kept in a Cardinal Components component.
 * Hex 0.12 dropped CCA; Fabric data attachments cover the same use case.
 */
object MoreIotasAttachments {
    @JvmField
    val CHAT_PREFIX: AttachmentType<String> = AttachmentRegistry.create(modLoc("chat_prefix")) {
        it.persistent(Codec.STRING).copyOnDeath()
    }

    /** Called from the mod initializer so the attachment is registered before Fabric freezes the registry. */
    @JvmStatic
    fun init() {
        // Touching the object's members forces class initialisation, which registers CHAT_PREFIX.
        CHAT_PREFIX.hashCode()
    }

    @JvmStatic
    fun getChatPrefix(player: Player): String? = player.getAttached(CHAT_PREFIX)

    @JvmStatic
    fun setChatPrefix(player: Player, prefix: String?) {
        if (prefix == null) player.removeAttached(CHAT_PREFIX) else player.setAttached(CHAT_PREFIX, prefix)
    }
}
