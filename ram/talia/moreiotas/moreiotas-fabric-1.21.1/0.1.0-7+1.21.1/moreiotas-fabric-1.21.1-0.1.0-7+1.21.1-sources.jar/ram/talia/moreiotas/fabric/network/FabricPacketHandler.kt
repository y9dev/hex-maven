package ram.talia.moreiotas.fabric.network

/**
 * MoreIotas does not currently ship any custom payloads (the former message classes were already commented out in
 * the 1.20.1 tree). Kept as the hook where 1.21.1 [net.minecraft.network.protocol.common.custom.CustomPacketPayload]
 * receivers would be registered.
 *
 * TODO(port): re-add payloads here if MoreIotas gains networking.
 */
object FabricPacketHandler {
	/**
	 * For registering packets that are client -> server (called on the server)
	 */
	fun initServerBound() {
	}

	/**
	 * For registering packets that are server -> client (called on the client)
	 */
	fun initClientBound() {
	}
}
