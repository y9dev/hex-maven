package ram.talia.moreiotas.fabric.xplat;

import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import ram.talia.moreiotas.fabric.data.MoreIotasAttachments;
import ram.talia.moreiotas.fabric.eventhandlers.ChatEventHandler;
import ram.talia.moreiotas.xplat.IXplatAbstractions;

public class FabricXplatImpl implements IXplatAbstractions {

    @Override
    public boolean isPhysicalClient() {
        return FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT;
    }

    @Override
    public void sendPacketToPlayer(ServerPlayer target, CustomPacketPayload packet) {
        ServerPlayNetworking.send(target, packet);
    }

    @Override
    public void sendPacketNear(Vec3 pos, double radius, ServerLevel dimension, CustomPacketPayload packet) {
        var pkt = ServerPlayNetworking.createS2CPacket(packet);
        var nears = PlayerLookup.around(dimension, pos, radius);
        for (var p : nears) {
            p.connection.send(pkt);
        }
    }

    @Override
    public Packet<?> toVanillaClientboundPacket(CustomPacketPayload message) {
        return ServerPlayNetworking.createS2CPacket(message);
    }

    @Override
    public boolean isBreakingAllowed (Level level, BlockPos pos, BlockState state, Player player) {
        return PlayerBlockBreakEvents.BEFORE.invoker().beforeBlockBreak(level, player, pos, state, level.getBlockEntity(pos));
    }

    @Override
    public @Nullable String lastMessage(@Nullable Player player) {
        return ChatEventHandler.lastMessage(player);
    }

    @Override
    public void setChatPrefix(Player player, @Nullable String prefix) {
        MoreIotasAttachments.setChatPrefix(player, prefix);
    }

    @Override
    public @Nullable String getChatPrefix(Player player) {
        return MoreIotasAttachments.getChatPrefix(player);
    }
}
