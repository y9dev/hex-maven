package ram.talia.moreiotas.api.casting.iota;

import at.petrak.hexcasting.api.casting.eval.CastingEnvironment;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.api.casting.mishaps.MishapInvalidIota;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import ram.talia.moreiotas.api.mod.MoreIotasConfig;
import ram.talia.moreiotas.common.lib.hex.MoreIotasIotaTypes;

public class StringIota extends Iota {
    private final String string;

    private StringIota(@NotNull String string) {
        super(() -> MoreIotasIotaTypes.STRING);
        this.string = string;
    }

    public static StringIota make(@NotNull String string) throws MishapInvalidIota {
        if (string.length() > MoreIotasConfig.getServer().getMaxStringLength())
            throw MishapInvalidIota.of(new StringIota(string), 0, "string.max_size", MoreIotasConfig.getServer().getMaxStringLength(), string.length());
        return new StringIota(string);
    }

    public static StringIota makeUnchecked(@NotNull String string) {
        return new StringIota(string);
    }

    public String getString() {
        return this.string;
    }

    @Override
    protected boolean toleratesOther(Iota that) {
        return typesMatch(this, that)
                && that instanceof StringIota sthat
                && this.getString().equals(sthat.getString());
    }

    @Override
    public boolean isTruthy(@Nullable CastingEnvironment env) {
        return !this.getString().isEmpty();
    }

    @Override
    public @NotNull Component display() {
        return Component.translatable("moreiotas.tooltip.string", this.getString())
                .withStyle(ChatFormatting.LIGHT_PURPLE);
    }

    @Override
    public int hashCode() {
        return this.getString().hashCode();
    }

    public static IotaType<StringIota> TYPE = new IotaType<>() {
        public static final MapCodec<StringIota> CODEC = com.mojang.serialization.Codec.STRING
                .comapFlatMap(
                        s -> {
                            try {
                                return DataResult.success(StringIota.make(s));
                            } catch (MishapInvalidIota e) {
                                return DataResult.error(e::getMessage);
                            }
                        },
                        StringIota::getString)
                .fieldOf("value");

        public static final StreamCodec<RegistryFriendlyByteBuf, StringIota> STREAM_CODEC =
                ByteBufCodecs.STRING_UTF8.<RegistryFriendlyByteBuf>mapStream(buf -> buf).map(StringIota::makeUnchecked, StringIota::getString);

        @Override
        public MapCodec<StringIota> codec() {
            return CODEC;
        }

        @Override
        public StreamCodec<RegistryFriendlyByteBuf, StringIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xff_ff55ff;
        }
    };
}
