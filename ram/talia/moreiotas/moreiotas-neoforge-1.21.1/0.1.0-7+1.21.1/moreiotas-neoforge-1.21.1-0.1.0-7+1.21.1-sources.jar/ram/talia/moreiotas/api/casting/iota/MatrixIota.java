package ram.talia.moreiotas.api.casting.iota;

import at.petrak.hexcasting.api.casting.eval.CastingEnvironment;
import at.petrak.hexcasting.api.casting.iota.DoubleIota;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.api.casting.mishaps.MishapInvalidIota;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import io.netty.handler.codec.DecoderException;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.ChatFormatting;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import org.jblas.DoubleMatrix;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import ram.talia.moreiotas.common.lib.hex.MoreIotasIotaTypes;

import java.util.ArrayList;
import java.util.List;

public class MatrixIota extends Iota {
    private final DoubleMatrix matrix;

    public MatrixIota(@NotNull DoubleMatrix matrix) throws MishapInvalidIota {
        super(() -> MoreIotasIotaTypes.MATRIX);
        this.matrix = matrix;
        if (matrix.rows > MatrixLimits.maxDim() || matrix.columns > MatrixLimits.maxDim())
            throw MishapInvalidIota.of(this,
                    0,
                    "matrix.max_size",
                    MatrixLimits.maxDim(),
                    matrix.rows,
                    matrix.columns);
    }

    public DoubleMatrix getMatrix() {
        return this.matrix;
    }

    @Override
    protected boolean toleratesOther(Iota that) {
        return false;
    }

    @Override
    public boolean isTruthy(@Nullable CastingEnvironment env) {
        // is true if it has entries, and at least one has abs(entry)>0
        return !this.getMatrix().isEmpty() && this.getMatrix().norm1() > DoubleIota.TOLERANCE;
    }

    @Override
    public @NotNull Component display() {
        var mat = this.getMatrix();

        var out = Component.empty();

        out.append(String.format("(%d, %d)", mat.rows, mat.columns));
        if (!mat.isEmpty())
            out.append(" | ");

        for (int r = 0; r < mat.rows; r++) {
            for (int c = 0; c < mat.columns; c++) {
                out.append(Component.literal(String.format("%.2f", mat.get(r, c))).withStyle(ChatFormatting.GREEN));
                if (c < mat.columns - 1) {
                    out.append(", ");
                }
            }
            if (r < mat.rows - 1) {
                out.append("; ");
            }
        }

        return Component.translatable("hexcasting.tooltip.list_contents", out).withStyle(ChatFormatting.AQUA);
    }

    @Override
    public int hashCode() {
        return this.getMatrix().hashCode();
    }

    private static List<List<Double>> toRows(DoubleMatrix mat) {
        var rows = new ArrayList<List<Double>>(mat.rows);
        for (int i = 0; i < mat.rows; i++) {
            var row = new ArrayList<Double>(mat.columns);
            for (int j = 0; j < mat.columns; j++) {
                row.add(mat.get(i, j));
            }
            rows.add(row);
        }
        return rows;
    }

    private record RawMatrix(int rows, int cols, List<List<Double>> data) {}

    private static DataResult<MatrixIota> fromRaw(RawMatrix raw) {
        var err = MatrixLimits.validate(raw.rows(), raw.cols(), MatrixLimits.maxDim());
        if (err != null)
            return DataResult.error(() -> err);
        if (raw.data().size() != raw.rows())
            return DataResult.error(() -> "matrix has " + raw.data().size() + " rows of data, expected " + raw.rows());
        var mat = new DoubleMatrix(raw.rows(), raw.cols());
        for (int i = 0; i < raw.rows(); i++) {
            var row = raw.data().get(i);
            if (row.size() != raw.cols())
                return DataResult.error(() -> "matrix row has " + row.size() + " entries, expected " + raw.cols());
            for (int j = 0; j < raw.cols(); j++)
                mat.put(i, j, row.get(j));
        }
        try {
            return DataResult.success(new MatrixIota(mat));
        } catch (MishapInvalidIota e) {
            return DataResult.error(() -> "invalid matrix");
        }
    }

    public static IotaType<MatrixIota> TYPE = new IotaType<>() {
        public static final MapCodec<MatrixIota> CODEC = RecordCodecBuilder.<RawMatrix>mapCodec(inst -> inst.group(
                Codec.INT.fieldOf("rows").forGetter(RawMatrix::rows),
                Codec.INT.fieldOf("cols").forGetter(RawMatrix::cols),
                Codec.DOUBLE.listOf().listOf().fieldOf("mat").forGetter(RawMatrix::data)
        ).apply(inst, RawMatrix::new)).flatXmap(
                MatrixIota::fromRaw,
                iota -> DataResult.success(new RawMatrix(iota.getMatrix().rows, iota.getMatrix().columns, toRows(iota.getMatrix())))
        );

        public static final StreamCodec<RegistryFriendlyByteBuf, MatrixIota> STREAM_CODEC = new StreamCodec<>() {
            @Override
            public MatrixIota decode(RegistryFriendlyByteBuf buf) {
                int rows = buf.readVarInt();
                int cols = buf.readVarInt();
                var err = MatrixLimits.validate(rows, cols, MatrixLimits.maxDim());
                if (err != null)
                    throw new DecoderException(err);
                if ((long) rows * cols * Double.BYTES > buf.readableBytes())
                    throw new DecoderException("matrix data is truncated");
                var mat = new DoubleMatrix(rows, cols);
                for (int i = 0; i < rows; i++) {
                    for (int j = 0; j < cols; j++) {
                        mat.put(i, j, buf.readDouble());
                    }
                }
                return new MatrixIota(mat);
            }

            @Override
            public void encode(RegistryFriendlyByteBuf buf, MatrixIota iota) {
                var mat = iota.getMatrix();
                buf.writeVarInt(mat.rows);
                buf.writeVarInt(mat.columns);
                for (int i = 0; i < mat.rows; i++) {
                    for (int j = 0; j < mat.columns; j++) {
                        buf.writeDouble(mat.get(i, j));
                    }
                }
            }
        };

        @Override
        public MapCodec<MatrixIota> codec() {
            return CODEC;
        }

        @Override
        public StreamCodec<RegistryFriendlyByteBuf, MatrixIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xff_55ffff;
        }
    };
}
