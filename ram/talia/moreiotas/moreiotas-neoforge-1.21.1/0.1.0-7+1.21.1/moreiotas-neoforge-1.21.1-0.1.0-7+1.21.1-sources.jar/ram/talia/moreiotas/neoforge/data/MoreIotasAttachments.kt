package ram.talia.moreiotas.neoforge.data

import com.mojang.serialization.Codec
import net.minecraft.world.entity.player.Player
import net.neoforged.bus.api.IEventBus
import net.neoforged.neoforge.attachment.AttachmentType
import net.neoforged.neoforge.registries.DeferredRegister
import net.neoforged.neoforge.registries.NeoForgeRegistries
import ram.talia.moreiotas.api.MoreIotasAPI
import java.util.function.Supplier

/** Player data formerly kept in a Cardinal Components component; NeoForge data attachments cover it. */
object MoreIotasAttachments {
    private val ATTACHMENT_TYPES: DeferredRegister<AttachmentType<*>> =
        DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, MoreIotasAPI.MOD_ID)

    @JvmField
    val CHAT_PREFIX: Supplier<AttachmentType<String>> = ATTACHMENT_TYPES.register("chat_prefix", Supplier {
        AttachmentType.builder(Supplier { "" }).serialize(Codec.STRING).copyOnDeath().build()
    })

    @JvmStatic
    fun register(modBus: IEventBus) {
        ATTACHMENT_TYPES.register(modBus)
    }

    @JvmStatic
    fun getChatPrefix(player: Player): String? =
        if (player.hasData(CHAT_PREFIX)) player.getData(CHAT_PREFIX) else null

    @JvmStatic
    fun setChatPrefix(player: Player, prefix: String?) {
        if (prefix == null) player.removeData(CHAT_PREFIX) else player.setData(CHAT_PREFIX, prefix)
    }
}
