package ram.talia.moreiotas.api.casting.iota;

import at.petrak.hexcasting.api.casting.eval.CastingEnvironment;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.common.lib.HexRegistries;
import at.petrak.hexcasting.common.lib.hex.HexIotaTypes;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static ram.talia.moreiotas.common.lib.hex.MoreIotasIotaTypes.IOTA_TYPE;

public class IotaTypeIota extends Iota {
    private final IotaType<?> iotaType;

    public IotaTypeIota(@NotNull IotaType<?> iotaType) {
        super(() -> IOTA_TYPE);
        this.iotaType = iotaType;
    }

    public IotaType<?> getIotaType() {
        return this.iotaType;
    }

    @Override
    protected boolean toleratesOther(Iota that) {
        return typesMatch(this, that) &&
                that instanceof IotaTypeIota dent &&
                this.getIotaType().equals(dent.getIotaType());
    }

    @Override
    public boolean isTruthy(@Nullable CastingEnvironment env) {
        return true;
    }

    @Override
    public @NotNull Component display() {
        var location = HexIotaTypes.REGISTRY.getKey(this.getIotaType());
        if (location == null)
            return Component.translatable("hexcasting.spelldata.unknown");
        return Component.translatable("hexcasting.iota.%s".formatted(location.toString()))
                .withStyle(ChatFormatting.DARK_PURPLE);
    }

    @Override
    public int hashCode() {
        return this.getIotaType().hashCode();
    }

    public static IotaType<IotaTypeIota> TYPE = new IotaType<>() {
        @SuppressWarnings("unchecked")
        public static final MapCodec<IotaTypeIota> CODEC = Codec.lazyInitialized(
                        () -> (Codec<IotaType<?>>) (Codec<?>) HexIotaTypes.REGISTRY.byNameCodec())
                .comapFlatMap(t -> DataResult.success(new IotaTypeIota(t)), IotaTypeIota::getIotaType)
                .fieldOf("value");

        public static final StreamCodec<RegistryFriendlyByteBuf, IotaTypeIota> STREAM_CODEC =
                ByteBufCodecs.registry(HexRegistries.IOTA_TYPE)
                        .map(IotaTypeIota::new, IotaTypeIota::getIotaType);

        @Override
        public MapCodec<IotaTypeIota> codec() {
            return CODEC;
        }

        @Override
        public StreamCodec<RegistryFriendlyByteBuf, IotaTypeIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xff_553355;
        }
    };
}
