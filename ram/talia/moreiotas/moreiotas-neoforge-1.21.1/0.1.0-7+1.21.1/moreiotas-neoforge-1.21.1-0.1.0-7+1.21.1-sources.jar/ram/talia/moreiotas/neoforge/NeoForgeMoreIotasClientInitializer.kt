package ram.talia.moreiotas.neoforge

import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider
import net.minecraft.client.renderer.blockentity.BlockEntityRenderers
import net.minecraft.world.level.block.entity.BlockEntity
import net.minecraft.world.level.block.entity.BlockEntityType
import net.neoforged.bus.api.IEventBus
import net.neoforged.fml.ModContainer
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent
import net.neoforged.neoforge.client.gui.ConfigurationScreen
import net.neoforged.neoforge.client.gui.IConfigScreenFactory
import ram.talia.moreiotas.client.RegisterClientStuff

object NeoForgeMoreIotasClientInitializer {
    fun init(modBus: IEventBus, modContainer: ModContainer) {
        modContainer.registerExtensionPoint(IConfigScreenFactory::class.java,
            IConfigScreenFactory { container, parent -> ConfigurationScreen(container, parent) })

        modBus.addListener { event: FMLClientSetupEvent ->
            event.enqueueWork {
                RegisterClientStuff.init()

                RegisterClientStuff.registerBlockEntityRenderers(object : RegisterClientStuff.BlockEntityRendererRegisterer {
                    override fun <T : BlockEntity> registerBlockEntityRenderer(type: BlockEntityType<T>, berp: BlockEntityRendererProvider<in T>) {
                        BlockEntityRenderers.register(type, berp)
                    }
                })
            }
        }
    }
}
