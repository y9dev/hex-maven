package ram.talia.moreiotas.api.casting.iota;

import ram.talia.moreiotas.api.mod.MoreIotasConfig;

/**
 * Bounds checks for matrix dimensions that come from untrusted data (network, NBT, Everbooks).
 * Kept free of Minecraft classes so it can be unit tested.
 */
public final class MatrixLimits {
    private MatrixLimits() {}

    /** Absolute upper bound per dimension, used when no server config is available (e.g. on a client). */
    public static final int HARD_MAX_DIM = MoreIotasConfig.ServerConfigAccess.MAX_MAX_MATRIX_SIZE;

    /** The per-dimension limit currently in force: the server config, or the hard max if it is not loaded. */
    public static int maxDim() {
        try {
            return Math.min(MoreIotasConfig.getServer().getMaxMatrixSize(), HARD_MAX_DIM);
        } catch (IllegalStateException e) {
            return HARD_MAX_DIM;
        }
    }

    /** @return null if the dimensions are acceptable, else a description of the problem. */
    public static String validate(int rows, int cols, int maxDim) {
        if (rows < 0 || cols < 0)
            return "negative matrix dimensions " + rows + "x" + cols;
        if (rows > maxDim || cols > maxDim)
            return "matrix dimensions " + rows + "x" + cols + " exceed the maximum of " + maxDim;
        return null;
    }
}
