package ram.talia.moreiotas.api.casting.iota;

import at.petrak.hexcasting.api.casting.eval.CastingEnvironment;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static ram.talia.moreiotas.common.lib.hex.MoreIotasIotaTypes.ITEM_TYPE;

public class ItemTypeIota extends Iota {
    private final Either<Item, Block> either;

    public ItemTypeIota(@NotNull Item item) {
        super(() -> ITEM_TYPE);
        this.either = Either.left(item);
    }

    public ItemTypeIota(@NotNull Block block) {
        super(() -> ITEM_TYPE);
        this.either = Either.right(block);
    }

    public Either<Item, Block> getEither() {
        return this.either;
    }

    @Nullable
    public Block getBlock() {
        return this.getEither().map(item -> {
            if (item instanceof BlockItem blockItem)
                return blockItem.getBlock();
            else return null;
        }, block -> block);
    }

    /**
     * If the block has no item form this returns Items.AIR
     */
    @Nullable
    public Item getItem() {
        return this.getEither().map(item -> item, Block::asItem);
    }

    @Override
    protected boolean toleratesOther(Iota that) {
        return typesMatch(this, that) &&
                that instanceof ItemTypeIota dent &&
                this.getEither().map(
                        itemThis -> dent.getEither().map(itemThis::equals,
                                blockThat -> {
                                    var itemThat = blockThat.asItem();
                                    if (itemThat.equals(Items.AIR) && !blockThat.equals(Blocks.AIR))
                                        return false;
                                    return itemThis.equals(itemThat);
                                }),
                        blockThis -> dent.getEither().map(itemThat -> {
                                                              var itemThis = blockThis.asItem();
                                                              if (itemThis.equals(Items.AIR) && !blockThis.equals(Blocks.AIR))
                                                                  return false;
                                                              return itemThis.equals(itemThat);
                                                          }, blockThis::equals));
    }

    @Override
    public boolean isTruthy(@Nullable CastingEnvironment env) {
        return this.getEither().map(item -> !item.equals(Items.AIR), block -> !block.equals(Blocks.AIR));
    }

    @Override
    public @NotNull Component display() {
        return this.getEither().map(item -> (Component) item.getDescription().copy().withStyle(ChatFormatting.GOLD),
                block -> block.getName().withStyle(ChatFormatting.GOLD));
    }

    @Override
    public int hashCode() {
        return this.getEither().hashCode();
    }

    public static IotaType<ItemTypeIota> TYPE = new IotaType<>() {
        @SuppressWarnings("unchecked")
        public static final MapCodec<ItemTypeIota> CODEC = Codec.either(
                        (Codec<Item>) (Codec<?>) BuiltInRegistries.ITEM.byNameCodec(),
                        (Codec<Block>) (Codec<?>) BuiltInRegistries.BLOCK.byNameCodec())
                .xmap(either -> either.map(item -> new ItemTypeIota(item), block -> new ItemTypeIota(block)),
                        ItemTypeIota::getEither)
                .fieldOf("value");

        public static final StreamCodec<RegistryFriendlyByteBuf, ItemTypeIota> STREAM_CODEC = new StreamCodec<>() {
            @Override
            public ItemTypeIota decode(RegistryFriendlyByteBuf buf) {
                boolean isBlock = buf.readBoolean();
                var id = buf.readResourceLocation();
                if (isBlock) {
                    return new ItemTypeIota(BuiltInRegistries.BLOCK.get(id));
                } else {
                    return new ItemTypeIota(BuiltInRegistries.ITEM.get(id));
                }
            }

            @Override
            public void encode(RegistryFriendlyByteBuf buf, ItemTypeIota iota) {
                var either = iota.getEither();
                if (either.left().isPresent()) {
                    buf.writeBoolean(false);
                    buf.writeResourceLocation(BuiltInRegistries.ITEM.getKey(either.left().get()));
                } else {
                    buf.writeBoolean(true);
                    buf.writeResourceLocation(BuiltInRegistries.BLOCK.getKey(either.right().get()));
                }
            }
        };

        @Override
        public MapCodec<ItemTypeIota> codec() {
            return CODEC;
        }

        @Override
        public StreamCodec<RegistryFriendlyByteBuf, ItemTypeIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xff_feaa01;
        }
    };
}
