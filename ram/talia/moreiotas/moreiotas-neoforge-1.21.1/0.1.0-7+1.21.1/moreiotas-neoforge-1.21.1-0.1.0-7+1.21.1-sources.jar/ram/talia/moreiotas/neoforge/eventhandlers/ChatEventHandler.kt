package ram.talia.moreiotas.neoforge.eventhandlers

import net.minecraft.world.entity.player.Player
import net.neoforged.neoforge.event.ServerChatEvent
import ram.talia.moreiotas.neoforge.data.MoreIotasAttachments
import java.util.*

object ChatEventHandler {
    private val lastMessages: MutableMap<UUID, String?> = mutableMapOf()
    private var lastMessage: String? = null

    fun receiveChat(event: ServerChatEvent) {
        val player = event.player
        val text = event.rawText

        val prefix = MoreIotasAttachments.getChatPrefix(player)

        if (prefix == null) {
            lastMessages[player.uuid] = text
            lastMessage = text
            return
        }

        if (!text.startsWith(prefix))
            return

        lastMessages[player.uuid] = text.substring(prefix.length)

        // the message was meant for the iota, not for chat
        event.isCanceled = true
    }

    @JvmStatic
    fun lastMessage(player: Player?): String? = if (player != null) lastMessages[player.uuid] else lastMessage
}
