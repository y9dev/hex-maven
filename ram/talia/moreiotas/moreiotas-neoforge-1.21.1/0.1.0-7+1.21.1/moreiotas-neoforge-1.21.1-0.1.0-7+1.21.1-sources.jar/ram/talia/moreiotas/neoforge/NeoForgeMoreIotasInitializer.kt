package ram.talia.moreiotas.neoforge

import at.petrak.hexcasting.xplat.IXplatAbstractions
import net.minecraft.core.Registry
import net.minecraft.resources.ResourceLocation
import net.neoforged.api.distmarker.Dist
import net.neoforged.bus.api.IEventBus
import net.neoforged.fml.ModContainer
import net.neoforged.fml.common.Mod
import net.neoforged.fml.config.ModConfig
import net.neoforged.fml.loading.FMLEnvironment
import net.neoforged.neoforge.common.ModConfigSpec
import net.neoforged.neoforge.common.NeoForge
import net.neoforged.neoforge.event.ServerChatEvent
import net.neoforged.neoforge.registries.RegisterEvent
import ram.talia.moreiotas.api.MoreIotasAPI
import ram.talia.moreiotas.api.mod.MoreIotasConfig
import ram.talia.moreiotas.common.lib.hex.MoreIotasActions
import ram.talia.moreiotas.common.lib.hex.MoreIotasArithmetics
import ram.talia.moreiotas.common.lib.hex.MoreIotasIotaTypes
import ram.talia.moreiotas.neoforge.data.MoreIotasAttachments
import ram.talia.moreiotas.neoforge.eventhandlers.ChatEventHandler
import java.util.function.BiConsumer

@Mod(MoreIotasAPI.MOD_ID)
class NeoForgeMoreIotasInitializer(modBus: IEventBus, modContainer: ModContainer) {
    init {
        MoreIotasAPI.LOGGER.info("Hello NeoForge World!")
        bus = modBus

        initConfig(modContainer)
        MoreIotasAttachments.register(modBus)
        initRegistries(modBus)

        NeoForge.EVENT_BUS.addListener { event: ServerChatEvent -> ChatEventHandler.receiveChat(event) }

        if (FMLEnvironment.dist == Dist.CLIENT) {
            NeoForgeMoreIotasClientInitializer.init(modBus, modContainer)
        }
    }

    private fun initConfig(modContainer: ModContainer) {
        val common = ModConfigSpec.Builder().configure { NeoForgeMoreIotasConfig(it) }
        val client = ModConfigSpec.Builder().configure { NeoForgeMoreIotasConfig.Client(it) }
        val server = ModConfigSpec.Builder().configure { NeoForgeMoreIotasConfig.Server(it) }
        MoreIotasConfig.common = common.left
        MoreIotasConfig.client = client.left
        MoreIotasConfig.server = server.left
        modContainer.registerConfig(ModConfig.Type.COMMON, common.right)
        modContainer.registerConfig(ModConfig.Type.CLIENT, client.right)
        modContainer.registerConfig(ModConfig.Type.SERVER, server.right)
    }

    private fun initRegistries(modBus: IEventBus) {
        bind(modBus, IXplatAbstractions.INSTANCE.iotaTypeRegistry) { MoreIotasIotaTypes.registerTypes(it) }
        bind(modBus, IXplatAbstractions.INSTANCE.actionRegistry) { MoreIotasActions.register(it) }
        bind(modBus, IXplatAbstractions.INSTANCE.arithmeticRegistry) { MoreIotasArithmetics.register(it) }
    }

    private fun <T : Any> bind(modBus: IEventBus, registry: Registry<T>, source: (BiConsumer<T, ResourceLocation>) -> Unit) {
        modBus.addListener { event: RegisterEvent ->
            if (registry.key() == event.registryKey) {
                source(BiConsumer { t, id -> event.register(registry.key(), id) { t } })
            }
        }
    }

    companion object {
        private lateinit var bus: IEventBus

        @JvmStatic
        fun getModEventBus(): IEventBus = bus
    }
}
