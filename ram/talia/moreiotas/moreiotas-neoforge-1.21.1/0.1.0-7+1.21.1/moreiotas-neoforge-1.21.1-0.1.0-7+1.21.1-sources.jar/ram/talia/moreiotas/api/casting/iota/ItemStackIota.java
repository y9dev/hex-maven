package ram.talia.moreiotas.api.casting.iota;

import at.petrak.hexcasting.api.casting.eval.CastingEnvironment;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import com.mojang.serialization.MapCodec;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.codec.StreamCodec;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.BundleContents;
import net.minecraft.world.item.component.ItemContainerContents;
import java.util.ArrayList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static ram.talia.moreiotas.common.lib.hex.MoreIotasIotaTypes.ITEM_STACK;

public class ItemStackIota extends Iota {
    private final ItemStack stack;

    private ItemStackIota(ItemStack stack) {
        super(() -> ITEM_STACK);
        this.stack = stack;
    }

    public ItemStack getItemStack() {
        return this.stack;
    }

    @Override
    protected boolean toleratesOther(Iota iota) {
        return iota instanceof ItemStackIota iiota && ItemStack.matches(this.getItemStack(), iiota.getItemStack());
    }

    @Override
    public boolean isTruthy(@Nullable CastingEnvironment env) {
        return !this.getItemStack().isEmpty();
    }

    @Override
    public @NotNull Component display() {
        var stack = this.getItemStack();

        if (stack.isEmpty())
            return Component.translatable("moreiotas.tooltip.stack.empty").withStyle(Style.EMPTY.withColor(0x1E90FF));

        return Component.translatable("moreiotas.tooltip.stack.format", stack.getCount(), stack.getHoverName())
                .withStyle(Style.EMPTY.withColor(0x1E90FF));
    }

    @Override
    public int hashCode() {
        return ItemStack.hashItemAndComponents(this.getItemStack());
    }

    /** Maximum depth of nested containers that is searched for iota-holding components. */
    private static final int MAX_FILTER_DEPTH = 8;

    /**
     * Creates an iota for the given stack.
     * <p>
     * Mirrors the 1.20.1 anti-dupe / anti-bloat guard: every component that embeds iotas (Hex iota holders,
     * hex patterns and spellbook pages) is stripped from the stack and from any stack nested in a container or
     * bundle, so an item stack iota can never contain further iotas.
     */
    public static ItemStackIota createFiltered(ItemStack originalStack) {
        var stack = originalStack.copy();
        filterIotaComponents(stack, 0);
        return new ItemStackIota(stack);
    }

    private static void filterIotaComponents(ItemStack stack, int depth) {
        if (stack.isEmpty())
            return;

        stack.remove(HexDataComponents.IOTA_HOLDER_IOTA.get());
        stack.remove(HexDataComponents.HEX_HOLDER_PATTERNS.get());
        stack.remove(HexDataComponents.SPELLBOOK_PAGES.get());

        var container = stack.get(DataComponents.CONTAINER);
        var bundle = stack.get(DataComponents.BUNDLE_CONTENTS);

        if (depth >= MAX_FILTER_DEPTH) {
            // Too deep to inspect safely; drop the nested contents altogether.
            if (container != null) stack.remove(DataComponents.CONTAINER);
            if (bundle != null) stack.remove(DataComponents.BUNDLE_CONTENTS);
            return;
        }

        if (container != null && container != ItemContainerContents.EMPTY) {
            var filtered = new ArrayList<ItemStack>();
            container.nonEmptyItems().forEach(inner -> {
                var copy = inner.copy();
                filterIotaComponents(copy, depth + 1);
                filtered.add(copy);
            });
            stack.set(DataComponents.CONTAINER, ItemContainerContents.fromItems(filtered));
        }

        if (bundle != null && !bundle.isEmpty()) {
            var filtered = new ArrayList<ItemStack>();
            bundle.items().forEach(inner -> {
                var copy = inner.copy();
                filterIotaComponents(copy, depth + 1);
                filtered.add(copy);
            });
            stack.set(DataComponents.BUNDLE_CONTENTS, new BundleContents(filtered));
        }
    }

    public static ItemStackIota of(ItemStack stack) {
        return new ItemStackIota(stack);
    }

    public static IotaType<ItemStackIota> TYPE = new IotaType<>() {
        public static final MapCodec<ItemStackIota> CODEC = ItemStack.OPTIONAL_CODEC
                .xmap(ItemStackIota::createFiltered, ItemStackIota::getItemStack)
                .fieldOf("value");

        public static final StreamCodec<RegistryFriendlyByteBuf, ItemStackIota> STREAM_CODEC =
                ItemStack.OPTIONAL_STREAM_CODEC.map(ItemStackIota::createFiltered, ItemStackIota::getItemStack);

        @Override
        public MapCodec<ItemStackIota> codec() {
            return CODEC;
        }

        @Override
        public StreamCodec<RegistryFriendlyByteBuf, ItemStackIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xFF_1E90FF;
        }
    };
}
