package ram.talia.moreiotas.api.casting.iota;

import at.petrak.hexcasting.api.casting.eval.CastingEnvironment;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static ram.talia.moreiotas.common.lib.hex.MoreIotasIotaTypes.ENTITY_TYPE;

public class EntityTypeIota extends Iota {
    private final EntityType<?> entityType;

    public EntityTypeIota(@NotNull EntityType<?> entityType) {
        super(() -> ENTITY_TYPE);
        this.entityType = entityType;
    }

    public EntityType<?> getEntityType() {
        return this.entityType;
    }

    @Override
    protected boolean toleratesOther(Iota that) {
        return typesMatch(this, that) &&
                that instanceof EntityTypeIota dent &&
                this.getEntityType().equals(dent.getEntityType());
    }

    @Override
    public boolean isTruthy(@Nullable CastingEnvironment env) {
        return true;
    }

    @Override
    public @NotNull Component display() {
        return this.getEntityType().getDescription().copy()
                .append(" ")
                .append(Component.translatable("moreiotas.spelldata.entity_type"))
                .withStyle(ChatFormatting.DARK_AQUA);
    }

    @Override
    public int hashCode() {
        return this.getEntityType().hashCode();
    }

    public static IotaType<EntityTypeIota> TYPE = new IotaType<>() {
        @SuppressWarnings("unchecked")
        public static final MapCodec<EntityTypeIota> CODEC = Codec.lazyInitialized(
                        () -> (Codec<EntityType<?>>) (Codec<?>) BuiltInRegistries.ENTITY_TYPE.byNameCodec())
                .xmap(EntityTypeIota::new, EntityTypeIota::getEntityType)
                .fieldOf("value");

        public static final StreamCodec<RegistryFriendlyByteBuf, EntityTypeIota> STREAM_CODEC =
                ByteBufCodecs.registry(Registries.ENTITY_TYPE)
                        .map(EntityTypeIota::new, EntityTypeIota::getEntityType);

        @Override
        public MapCodec<EntityTypeIota> codec() {
            return CODEC;
        }

        @Override
        public StreamCodec<RegistryFriendlyByteBuf, EntityTypeIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xff_5555ff;
        }
    };
}
