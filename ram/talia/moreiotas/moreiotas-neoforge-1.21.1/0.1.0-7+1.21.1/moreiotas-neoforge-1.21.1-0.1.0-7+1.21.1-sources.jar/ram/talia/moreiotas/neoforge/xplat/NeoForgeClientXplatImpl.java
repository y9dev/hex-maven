package ram.talia.moreiotas.neoforge.xplat;

import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.client.renderer.item.ItemPropertyFunction;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import ram.talia.moreiotas.neoforge.NeoForgeMoreIotasInitializer;
import ram.talia.moreiotas.xplat.IClientXplatAbstractions;

import java.util.function.Function;

public class NeoForgeClientXplatImpl implements IClientXplatAbstractions {
    @Override
    public void sendPacketToServer(CustomPacketPayload packet) {
        PacketDistributor.sendToServer(packet);
    }

    @Override
    public void initPlatformSpecific() {
        // NO-OP
    }

    @Override
    public <T extends Entity> void registerEntityRenderer(EntityType<? extends T> type, EntityRendererProvider<T> renderer) {
        EntityRenderers.register(type, renderer);
    }

    @Override
    public <T extends ParticleOptions> void registerParticleType(ParticleType<T> type, Function<SpriteSet, ParticleProvider<T>> factory) {
        NeoForgeMoreIotasInitializer.getModEventBus().addListener(RegisterParticleProvidersEvent.class,
            evt -> evt.registerSpriteSet(type, factory::apply));
    }

    @Override
    public void registerItemProperty(Item item, ResourceLocation id, ItemPropertyFunction func) {
        ItemProperties.register(item, id, func);
    }
}
