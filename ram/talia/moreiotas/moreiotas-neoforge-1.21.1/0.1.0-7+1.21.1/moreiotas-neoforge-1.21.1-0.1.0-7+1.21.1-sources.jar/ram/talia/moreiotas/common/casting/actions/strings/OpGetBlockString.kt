package ram.talia.moreiotas.common.casting.actions.strings

import at.petrak.hexcasting.api.casting.asActionResult
import at.petrak.hexcasting.api.casting.castables.ConstMediaAction
import at.petrak.hexcasting.api.casting.eval.CastingEnvironment
import at.petrak.hexcasting.api.casting.getBlockPos
import at.petrak.hexcasting.api.casting.iota.Iota
import at.petrak.hexcasting.api.casting.iota.ListIota
import net.minecraft.core.component.DataComponents
import net.minecraft.world.level.block.entity.LecternBlockEntity
import net.minecraft.world.level.block.entity.SignBlockEntity
import net.minecraft.world.level.block.entity.SignText
import ram.talia.moreiotas.api.asActionResult
import ram.talia.moreiotas.api.casting.iota.StringIota

object OpGetBlockString : ConstMediaAction {
    override val argc = 1

    override fun execute(args: List<Iota>, env: CastingEnvironment): List<Iota> {
        val pos = args.getBlockPos(0, argc)

        env.assertVecInRange(pos.center)

        val blockEntity = env.world.getBlockEntity(pos)

        if (blockEntity is SignBlockEntity) {
            var string = blockEntity.getText(true).getMessage(0, false).string
            for (i in 1 until SignText.LINES) {
                string += "\n" + blockEntity.getText(true).getMessage(i, false).string
            }

            return string.asActionResult
        }
        if (blockEntity is LecternBlockEntity) {
            val book = blockEntity.book

            book.get(DataComponents.WRITABLE_BOOK_CONTENT)?.let { content ->
                return content.pages().map { StringIota.make(it.raw()) }.let { listOf(ListIota(it)) }
            }
            book.get(DataComponents.WRITTEN_BOOK_CONTENT)?.let { content ->
                return content.getPages(false).map { StringIota.make(it.string) }.let { listOf(ListIota(it)) }
            }
        }

        return null.asActionResult
    }
}
