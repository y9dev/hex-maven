package ram.talia.moreiotas.api.nbt

import at.petrak.hexcasting.api.casting.iota.Iota
import at.petrak.hexcasting.api.casting.iota.IotaType
import net.minecraft.nbt.CompoundTag
import net.minecraft.nbt.IntTag
import net.minecraft.nbt.ListTag
import net.minecraft.nbt.NbtOps
import net.minecraft.nbt.NbtUtils
import net.minecraft.nbt.NumericTag
import net.minecraft.nbt.Tag
import net.minecraft.server.level.ServerLevel
import net.minecraft.world.entity.Entity
import java.util.*

/**
 * Bridges Hex iotas to and from NBT. Hex 0.12 serialises iotas through [IotaType.TYPED_CODEC] rather than the old
 * `IotaType.serialize/deserialize` pair, so these helpers go through a [NbtOps] (with registry access when a level is
 * available).
 */
fun ListTag.toIotaList(level: ServerLevel): MutableList<Iota> {
	val out = ArrayList<Iota>()
	val ops = level.registryAccess().createSerializationContext(NbtOps.INSTANCE)
	for (iotaTag in this) {
		IotaType.TYPED_CODEC.parse(ops, iotaTag).result().ifPresent { out.add(it) }
	}
	return out
}

@JvmName("toNbtListSpellDatum")
fun List<Iota>.toNbtList(): ListTag {
	val patsTag = ListTag()
	for (iota in this) {
		IotaType.TYPED_CODEC.encodeStart(NbtOps.INSTANCE, iota).result().ifPresent { patsTag.add(it) }
	}
	return patsTag
}

inline fun <reified T : Entity> ListTag.toEntityList(level: ServerLevel): MutableList<T> {
	val out = ArrayList<T>()

	for (eTag in this) {
		val uuid = NbtUtils.loadUUID(eTag)
		val entity = level.getEntity(uuid)

		if (entity != null && entity.isAlive && entity is T)
			out.add(entity)
	}

	return out
}

@JvmName("toNbtListEntity")
fun List<Entity>.toNbtList(): ListTag {
	val listTag = ListTag()

	for (entity in this) {
		listTag.add(NbtUtils.createUUID(entity.uuid))
	}

	return listTag
}

fun ListTag.toIntList(): MutableList<Int> {
	val out = mutableListOf<Int>()

	for (idTag in this) {
		out.add((idTag as? NumericTag)?.asInt ?: 0)
	}

	return out
}

@JvmName("toNbtListInt")
fun List<Int>.toNbtList(): ListTag {
	val listTag = ListTag()

	this.forEach { listTag.add(IntTag.valueOf(it)) }

	return listTag
}

@JvmName("toNbtListTag")
fun List<Tag>.toNbtList(): ListTag {
	val listTag = ListTag()

	this.forEach { listTag.add(it) }

	return listTag
}

fun ListTag.toCompoundTagList(): MutableList<CompoundTag> {
	val tags = mutableListOf<Tag>()
	tags.addAll(this)
	return tags.map { it as CompoundTag } as MutableList<CompoundTag>
}
