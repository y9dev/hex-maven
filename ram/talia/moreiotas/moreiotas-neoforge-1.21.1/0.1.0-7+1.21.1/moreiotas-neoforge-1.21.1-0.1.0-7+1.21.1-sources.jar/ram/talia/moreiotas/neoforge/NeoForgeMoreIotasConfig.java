package ram.talia.moreiotas.neoforge;

import at.petrak.hexcasting.api.misc.MediaConstants;
import net.neoforged.neoforge.common.ModConfigSpec;
import ram.talia.moreiotas.api.mod.MoreIotasConfig;

public class NeoForgeMoreIotasConfig implements MoreIotasConfig.CommonConfigAccess {
    public NeoForgeMoreIotasConfig(ModConfigSpec.Builder builder) {
    }

    public static class Client implements MoreIotasConfig.ClientConfigAccess {
        public Client(ModConfigSpec.Builder builder) {
        }
    }

    public static class Server implements MoreIotasConfig.ServerConfigAccess {
        private final ModConfigSpec.IntValue maxMatrixSize;
        private final ModConfigSpec.IntValue maxStringLength;
        private final ModConfigSpec.DoubleValue setBlockStringCost;
        private final ModConfigSpec.DoubleValue nameCost;

        public Server(ModConfigSpec.Builder builder) {
            maxMatrixSize = builder.comment("The maximum size of a matrix (in either dimension).")
                .defineInRange("maxMatrixSize", DEFAULT_MAX_MATRIX_SIZE, MIN_MAX_MATRIX_SIZE, MAX_MAX_MATRIX_SIZE);
            maxStringLength = builder.comment("The maximum length of a string iota.")
                .defineInRange("maxStringLength", DEFAULT_MAX_STRING_LENGTH, MIN_MAX_STRING_LENGTH, MAX_MAX_STRING_LENGTH);
            setBlockStringCost = builder.comment("How much media (in dust) it costs to set the string of a block.")
                .defineInRange("setBlockStringCost", DEFAULT_SET_BLOCK_STRING_COST, DEF_MIN_COST, DEF_MAX_COST);
            nameCost = builder.comment("How much media (in dust) it costs to name an entity.")
                .defineInRange("nameCost", DEFAULT_NAME_COST, DEF_MIN_COST, DEF_MAX_COST);
        }

        @Override
        public int getMaxMatrixSize() {
            return maxMatrixSize.get();
        }

        @Override
        public int getMaxStringLength() {
            return maxStringLength.get();
        }

        @Override
        public long getSetBlockStringCost() {
            return (long) (setBlockStringCost.get() * MediaConstants.DUST_UNIT);
        }

        @Override
        public long getNameCost() {
            return (long) (nameCost.get() * MediaConstants.DUST_UNIT);
        }
    }
}
