package at.petrak.hexcasting.api.casting.eval.vm

import at.petrak.hexcasting.api.casting.iota.Iota
import at.petrak.hexcasting.api.casting.iota.IotaType
import at.petrak.hexcasting.api.utils.TreeList
import at.petrak.hexcasting.api.utils.CodecUtils
import com.mojang.serialization.Codec
import com.mojang.serialization.codecs.RecordCodecBuilder
import net.minecraft.network.codec.ByteBufCodecs
import net.minecraft.network.codec.StreamCodec
import java.util.*

/**
 * The state of a casting VM, containing the stack and all
 */
data class CastingImage(
    val stack: TreeList<Iota>,
    val parenCount: Int,
    val parenthesized: TreeList<ParenthesizedIota>,
    val escapeNext: Boolean,
    val simulateNext: Boolean,
    val opsConsumed: Long,
    val components: Map<ImageComponentType<*>, Any>
) {
    constructor() : this(TreeList.empty(), 0, TreeList.empty(), false, false, 0, emptyMap())

    /**
     * `escaped` is used by [OpUndo][at.petrak.hexcasting.common.casting.actions.escaping.OpUndo] to determine whether the paren count
     * needs to be adjusted when undoing an open or close paren pattern (if the pattern was escaped, no need to change anything).
     */
    data class ParenthesizedIota(val iota: Iota, val escaped: Boolean) {
        companion object {
            val CODEC = RecordCodecBuilder.create<ParenthesizedIota> { inst ->
                inst.group(
                    IotaType.TYPED_CODEC.fieldOf("iota").forGetter { it.iota },
                    Codec.BOOL.fieldOf("escaped").forGetter { it.escaped }
                ).apply(inst, ::ParenthesizedIota)
            }
            val STREAM_CODEC = StreamCodec.composite(
                IotaType.TYPED_STREAM_CODEC, ParenthesizedIota::iota,
                ByteBufCodecs.BOOL, ParenthesizedIota::escaped,
                ::ParenthesizedIota
            )
        }
    }

    /**
     * Return a copy of this with the given number of ops additionally exhausted
     */
    fun withUsedOps(count: Long) = this.copy(opsConsumed = this.opsConsumed + count)

    /**
     * Return a copy of this with 1 op used
     */
    fun withUsedOp() = this.withUsedOps(1)

    /**
     * Returns a copy of this with the [opsConsumed] replaced with [count].
     */
    fun withOverriddenUsedOps(count: Long) = this.copy(opsConsumed = count)

    /**
     * Returns a copy of this with escape/paren-related fields cleared.
     */
    fun withResetEscape() = this.copy(parenCount = 0, parenthesized = TreeList.empty(), escapeNext = false)

    /**
     * Returns a copy of this with the provided iota added to the parenthesized list. `escaped` is used by
     * [OpUndo][at.petrak.hexcasting.common.casting.actions.escaping.OpUndo] to determine whether undoing the
     * parenthesized iota should adjust the paren count (escaped parens do not affect the count).
     */
    fun withNewParenthesized(iota: Iota, escaped: Boolean = false): CastingImage {
        val newParens = this.parenthesized.appended(ParenthesizedIota(iota, escaped))
        return this.copy(parenthesized = newParens)
    }

    @Suppress("UNCHECKED_CAST")
    fun <T : Any> getComponent(type: ImageComponentType<T>): T? = this.components[type] as? T
    fun <T : Any> withComponent(type: ImageComponentType<T>, value: T): CastingImage = copy(components = this.components + (type to value))
    fun <T : Any> withoutComponent(type: ImageComponentType<T>): CastingImage = copy(components = this.components - type)
    fun removeTransientComponents(): CastingImage = copy(components = this.components.filterKeys { !it.transient })

    companion object {
        @JvmStatic
        val CODEC = RecordCodecBuilder.create<CastingImage> { inst ->
            inst.group(
                TreeList.codecOf(IotaType.TYPED_CODEC).fieldOf("stack").forGetter { it.stack },
                Codec.INT.fieldOf("open_parens").forGetter { it.parenCount },
                TreeList.codecOf(ParenthesizedIota.CODEC).fieldOf("parenthesized").forGetter { it.parenthesized },
                Codec.BOOL.fieldOf("escape_next").forGetter { it.escapeNext },
                Codec.BOOL.fieldOf("simulate_next").forGetter { it.simulateNext },
                Codec.LONG.fieldOf("ops_consumed").forGetter { it.opsConsumed },
                Codec.dispatchedMap(
                    ImageComponentType.CODEC, ImageComponentType<*>::dataCodec
                ).fieldOf("components").forGetter{ it.components }
            ).apply(inst) { a, b, c, d, e, f, g ->
                CastingImage(a, b, c, d, e, f, g)
            }
        }.orElseGet(::CastingImage)
        @JvmStatic
        val STREAM_CODEC = CodecUtils.compositeCodecSeven(
            IotaType.TYPED_STREAM_CODEC.apply(TreeList.streamCodecOp()), CastingImage::stack,
            ByteBufCodecs.VAR_INT, CastingImage::parenCount,
            ParenthesizedIota.STREAM_CODEC.apply(TreeList.streamCodecOp()), CastingImage::parenthesized,
            ByteBufCodecs.BOOL, CastingImage::escapeNext,
            ByteBufCodecs.BOOL, CastingImage::simulateNext,
            ByteBufCodecs.VAR_LONG, CastingImage::opsConsumed,
            CodecUtils.streamCodecDispatchedMap(::HashMap,
                ImageComponentType.STREAM_CODEC, ImageComponentType<*>::dataStreamCodec
            ), CastingImage::components,
            { a, b, c, d, e, f, g ->
                CastingImage(a, b, c, d, e, f, g)
            }
        )
    }
}
