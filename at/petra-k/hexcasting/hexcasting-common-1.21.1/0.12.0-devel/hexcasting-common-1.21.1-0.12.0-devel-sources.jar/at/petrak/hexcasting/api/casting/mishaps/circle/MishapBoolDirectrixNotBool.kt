package at.petrak.hexcasting.api.casting.mishaps.circle

import at.petrak.hexcasting.api.casting.eval.CastingEnvironment
import at.petrak.hexcasting.api.casting.iota.Iota
import at.petrak.hexcasting.api.casting.mishaps.Mishap
import at.petrak.hexcasting.api.pigment.FrozenPigment
import at.petrak.hexcasting.api.utils.TreeList
import net.minecraft.core.BlockPos
import net.minecraft.network.chat.Component
import net.minecraft.world.item.DyeColor

// what a mouthful
class MishapBoolDirectrixNotBool(
    val perpetrator: Iota,
    val pos: BlockPos,
) : Mishap() {
    override fun accentColor(env: CastingEnvironment, errorCtx: Context): FrozenPigment =
        dyeColor(DyeColor.GRAY)

    override fun execute(env: CastingEnvironment, errorCtx: Context, stack: TreeList<Iota>): TreeList<Iota> {
        env.world.destroyBlock(this.pos, true)
        return stack
    }

    override fun errorMessage(env: CastingEnvironment, errorCtx: Context): Component =
        error("circle.bool_directrix.no_bool", pos.toShortString(), perpetrator.display())
}